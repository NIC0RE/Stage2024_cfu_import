""" medlog is dedicated module to uniform logging of scripts at Median Technologies
    It uses 2 log files : one for errors only (warning/error/critical) and one for all activity depending on the level defined at init

    Usage:
    ======
        1) import medlog
        2) initialize logger objectas per sample: medlog.initialize_logger('./log/myprogram-activity-log',
                                                                            './log/myprogram-error-log',
                                                                            medlog.logging.INFO,
                                                                            ['txt', 'html'],
                                                                            'myprogram')
        3) use the log: medlog.logger.error('my message %s", message) => .error could be replaced by .info, .debug, .warning, .critical
        4) log result is:
            - one activity log using the log levl provided in arg #3
            - one error log including all warning/error/critical logs
            - DateTime (ISO format) | log level | [myprogram] message
        01.02: ensure log files are not read-only
    """
__authors__ = "Median Tehcnologies (SGR)"
__contact__ = "SGR"
__copyright__ = "MEDIAN Technologies"
__date__ = "2023-09-05"
__version__= "01.02"

import logging
import logging.handlers
import logging.config
import stat
import os

class CustomFormatterHtml(logging.Formatter):
    """ CustomFormatter corresponds to the object for logging in html files in a smart way """
    STD_STYLE = 'font-style:normal;font-family:arial;font-size:11;margin:2px;padding:2px;'
    ERROR_STYLE = 'font-style:bold;font-family:arial;font-size:12;margin:10px;padding:2px;'
    GREY = '<p style="color:#404040;' + STD_STYLE + '">'
    YELLOW = '<p style="color:#FF6A00;' + STD_STYLE + '">'
    RED = '<p style="color:red;' + ERROR_STYLE + '">'
    RESET = '</p>'

    def __init__(self, prefix):
        """ constructeur for the formatter """
        # Formatter constructor args = (fmt=None, datefmt=None, style='%', validate=True, *, defaults=None)
        super().__init__()
        if len(prefix) > 0:
            prefix = prefix + ' '
        self.formatlog = '%(asctime)s.%(msecs)03dZ | %(levelname)s | ' + prefix + '%(message)s'
        self.formats = {
                logging.DEBUG: self.GREY + self.formatlog + self.RESET,
                logging.INFO: self.GREY + self.formatlog + self.RESET,
                logging.WARNING: self.YELLOW + self.formatlog + self.RESET,
                logging.ERROR: self.RED + self.formatlog + self.RESET,
                logging.CRITICAL: self.RED + self.formatlog + self.RESET
            }

    def format(self, record):
        log_fmt = self.formats.get(record.levelno)
        formatter = logging.Formatter(log_fmt, datefmt="%Y-%m-%dT%H:%M:%S") #, datefmt='%d-%b-%Y %I:%M:%S %p')
        return formatter.format(record)


class CustomFormatterTxt(logging.Formatter):
    """ CustomFormatter corresponds to the object for logging in txt files (basic style) """
    def __init__(self, prefix):
        """ constructeur for the formatter """
        # Formatter constructor args = (fmt=None, datefmt=None, style='%', validate=True, *, defaults=None)
        super().__init__()
        if len(prefix) > 0:
            prefix = prefix + ' '
        self.formatlog = '%(asctime)s.%(msecs)03dZ | %(levelname)s | ' + prefix + '%(message)s'
        self.formats = {
                logging.DEBUG: self.formatlog,
                logging.INFO: self.formatlog,
                logging.WARNING: self.formatlog,
                logging.ERROR: self.formatlog,
                logging.CRITICAL: self.formatlog
            }

    def format(self, record):
        log_fmt = self.formats.get(record.levelno)
        formatter = logging.Formatter(log_fmt, datefmt="%Y-%m-%dT%H:%M:%S") #, datefmt='%d-%b-%Y %I:%M:%S %p')
        return formatter.format(record)


logger = logging.getLogger(__name__)

def initialize_logger(activity_root_file_log, error_root_file_log, log_mode, lst_file_type, prefix=''):
    """ initialize logging
    - Log path are full path to activity and error logs
    - log_mode should be a value from : logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL
    - list of file type should include only html or txt : ['txt'] or ['html'] or ['txt', 'html'] """
    activity_file_log_html = activity_root_file_log + '.html'
    activity_file_log_txt = activity_root_file_log + '.txt'
    error_file_log_html = error_root_file_log + '.html'
    error_file_log_txt = error_root_file_log + '.txt'
    if len(prefix) > 0:
        prefix = '[' + prefix + ']'

    if not log_mode in [logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL]:
        log_mode = logging.INFO

    logger.setLevel(log_mode)
    directory = ""

    try:
        directory = os.path.dirname(os.path.abspath(activity_file_log_html))
        # define rwx access to the file
        add_rwxu_permissions(activity_file_log_html)
        add_rwxu_permissions(error_file_log_html)
        add_rwxu_permissions(activity_file_log_txt)
        add_rwxu_permissions(error_file_log_txt)
    except (FileNotFoundError, PermissionError) as error_perm:
        print(f'failed to change permissions on log files {directory} - {error_perm}')
        return

    # Parcourir le répertoire contenant le fichier et mettre chaque fichier et sous-répertoire en mode rwx
    for foldername, subfolders, filenames in os.walk(directory):
        for subfolder in subfolders:
            add_rwxu_permissions(os.path.join(foldername, subfolder))
        for file in filenames:
            add_rwxu_permissions(os.path.join(foldername, file))


    if 'html' in lst_file_type:
        fhandhtml = logging.handlers.RotatingFileHandler(filename = activity_file_log_html, maxBytes=500000, backupCount=10, encoding='utf-8')
        fhandhtml.setLevel(log_mode)
        fhandhtml.setFormatter(CustomFormatterHtml(prefix))
        logger.addHandler(fhandhtml)

        fhandhtml_error = logging.handlers.RotatingFileHandler(filename = error_file_log_html, maxBytes=500000, backupCount=10, encoding='utf-8')
        fhandhtml_error.setLevel(logging.WARNING)
        fhandhtml_error.setFormatter(CustomFormatterHtml(prefix))
        logger.addHandler(fhandhtml_error)

    if 'txt' in lst_file_type or lst_file_type == []:
        fhandtxt = logging.handlers.RotatingFileHandler(filename = activity_file_log_txt, maxBytes=500000, backupCount=10, encoding='utf-8')
        fhandtxt.setLevel(log_mode)
        fhandtxt.setFormatter(CustomFormatterTxt(prefix))
        logger.addHandler(fhandtxt)

        fhandtxt_error = logging.handlers.RotatingFileHandler(filename = error_file_log_txt, maxBytes=500000, backupCount=10, encoding='utf-8')
        fhandtxt_error.setLevel(logging.WARNING)
        fhandtxt_error.setFormatter(CustomFormatterTxt(prefix))
        logger.addHandler(fhandtxt_error)


def add_rwxu_permissions(path):
    """ define permissions to r, w and x """
    if os.path.exists(path):
        os.chmod(path, stat.S_IRWXU)

if __name__ == '__main__':
    print('medlog.py is to be imported from your programs and not started directly')
