""" test module for iMetrics
        --project (-j) = (ARTE-PH-007/...)
        --log (-g) = (debug/info/none)      
        --db_name (-d) = (PMDB/file)
        --qcindex_loc (-q) = (file/DB)
        --priorities_loc (-p) = (file/DB)
        --results_loc (-r) = (PMDB-Dev/file) 
        --log_folder (-l) = './log'
        --irlist_loc (-w) = (PMDB-Dev/file)
        --temp_working_folder (-t) = folder path
        --forecast_loc (-f) = forecast file path
        --rawdata_loc (-n) = file
        --webresult_loc (x) = fodler path
"""

import os
import gc
import pytest
import pandas as pd
import imetrics as im
import medlog
import imetrics_inputs as imi

# 1) Test arguments
# 2) test logger initiation
# 5) load_input_to_objects(dict_args, dict_projects, dict_df)
# 5.1) obj_project.load_images_from_df(df_images[df_images['PROJECTCODE']==obj_project.project_id])
# 5.2) obj_project.load_reads_from_df(df_queries[df_queries['PROJECTCODE']==obj_project.project_id])
# 5.3) obj_project.load_queries_from_df(df_reads[df_reads['PROJECTCODE']==obj_project.project_id])
# 5.4) obj_project.load_rawdata_notverified(df_rawdata_notverified[df_rawdata_notverified['PROJECTCODE']==obj_project.project_id])
# 5.5) obj_project.calculate_images_variables()
# 5.6) obj_project.calculate_reads_variables()
# 5.7) obj_project.calculate_updated_read_status()
# 6) calculate_monitoring_metrics(dict_projects)
# 7) startall()

# used for dict_args tests only
test_arguments = [
                    ['-j', 'ALL', '-g', 'debug', '-d', 'DSDB',
                     '-q', './tests/data/qc_index.xlsx', '-p', './tests/data/iCRO_Priorities.xlsx', '-r', './tests/results',
                     '-l', './log', '-w', 'DSDB', '-t', './tests/data/working',
                     '-f','./tests/data/iCRO_ActivityForecasts_Current_New.xlsx', '-n', './tests/data/iCRO_ReadsNotVerified_Current.xlsx'],
                    ['-j', 'ROCH-PH-014', '-g', 'debug', '-d', 'DSDB',
                     '-q', './tests/data/qc_index.xlsx', '-p', './tests/data/iCRO_Priorities.xlsx', '-r', './tests/results',
                     '-l', './log', '-w', 'DSDB', '-t', './tests/data/working',
                     '-f','./tests/data/iCRO_ActivityForecasts_Current_New.xlsx', '-n', './tests/data/iCRO_ReadsNotVerified_Current.xlsx']
                ]

# used for dict_args tests only
test_wrong_arguments = [
                   ['-j', 'ALL', '-g', 'debug', '-d', 'DSDB',
                     '-p', './tests/data/iCRO_Priorities.xlsx', '-r', './tests/results',
                     '-l', './log', '-w', 'DSDB', '-t', './tests/data/working',
                     '-f','./tests/data/iCRO_ActivityForecasts_Current_New.xlsx', '-n', './tests/data/iCRO_ReadsNotVerified_Current.xlsx'],
                    ['-j', 'ALL', '-g', 'debug', '-d', 'DSDB',
                     '-q', './tests/data/qc_index.xlsx', '-p', './tests/data/iCRO_Priorities.xlsx',
                     '-l', './log', '-w', 'DSDB', '-t', './tests/data/working',
                     '-f','./tests/data/iCRO_ActivityForecasts_Current_New.xlsx', '-n', './tests/data/iCRO_ReadsNotVerified_Current.xlsx'],
                    ['-j', 'ALL', '-g', 'debug', '-d', 'DSDB',
                     '-q', './tests/data/qc_index.xlsx', '-p', './tests/data/iCRO_Priorities.xlsx', '-r', './tests/results',
                     '-l', './log', '-t', './tests/data/working',
                     '-f','./tests/data/iCRO_ActivityForecasts_Current_New.xlsx', '-n', './tests/data/iCRO_ReadsNotVerified_Current.xlsx'],
                    ['-j', 'ALL', '-g', 'debug', '-d', 'DSDB',
                     '-q', './tests/data/qc_index.xlsx', '-p', './tests/data/iCRO_Priorities.xlsx', '-r', './tests/results',
                     '-l', './log', '-w', 'DSDB', 
                     '-f','./tests/data/iCRO_ActivityForecasts_Current_New.xlsx', '-n', './tests/data/iCRO_ReadsNotVerified_Current.xlsx']
                    ]

# ----------------------------------------------------------------------------
# 1) Test arguments                ]
# ----------------------------------------------------------------------------
@pytest.mark.parametrize('argument_list', test_arguments)
def test_create_dict_args(argument_list):
    """ use multiple args to test """
    dict_args = {}
    dict_args = im.get_args_to_dict(argument_list)
    assert dict_args is not None

@pytest.mark.parametrize('argument_list', test_wrong_arguments)
def test_create_dict_args_failures(argument_list):
    """ use multiple args to test """
    dict_args = {}
    dict_args = im.get_args_to_dict(argument_list)
    assert dict_args is None

# ----------------------------------------------------------------------------
# 2) test logger initiation
# ----------------------------------------------------------------------------
@pytest.mark.parametrize('argument_list', test_arguments)
def test_create_dict_args_and_init_logger(argument_list):
    """ use multiple args to test """
    dict_args = {}
    dict_args = im.get_args_to_dict(argument_list)
    try:
        if os.path.exists(str(dict_args['LOG_PATH']) + '.html'):
            os.remove(str(dict_args['LOG_PATH'])+'.html')
    except OSError as error:
        print('log file cannot be removed %s', error)

    medlog.initialize_logger(str(dict_args['LOG_PATH']), str(dict_args['LOG_PATH_ERROR']), dict_args['LOG_MODE'], ['txt', 'html'], 'imetrics')
    medlog.logger.info('-- test_create_dict_args_and_init_logger --')
    assert dict_args is not None and os.path.exists(str(dict_args['LOG_PATH'])+'.html') is True

# ----------------------------------------------------------------------------
# 3) test loading of data inside objects
# ----------------------------------------------------------------------------
def test_load_images_to_dict_objects(fixt_init_args_only):
    """ test how df_images is loaded to dict_objects """
    dict_args = fixt_init_args_only
    # 1 - initialize the logger + copy useful files to working folder (if not db usage)
    if not im.initialize_logger_and_temp_folder(dict_args):
        assert False

    # 2 - initialize DB engine
    engine_input = imi.dbconnect(database=dict_args['DB_NAME'])

    # 3 - read datasources (files & db) to dataframes
    dict_df = im.initialize_dataframes_from_sources(dict_args, engine_input)
    assert dict_df is not None

    medlog.logger.info('3 - read list of projects')
    dict_projects = {}
    dict_projects = im.get_project_list_and_mapping(dict_df['df_qc_index'], dict_df['df_project_list'], dict_args)
    if len(dict_projects) <= 0:
        medlog.logger.error('Process stopped trying to create dictioonnary of projects (qc_index & synonyms)')
        assert False

    # 4 - apply synonyms & exceptions
    if not im.apply_synonyms_to_all_df(dict_args, dict_df):
        assert False

    gc.collect()

    # test is here !
    for obj_project in dict_projects.values():
        obj_project.load_images_from_df(dict_df['df_images'][dict_df['df_images']['PROJECTCODE'] == obj_project.project_id])

    assert True

def test_load_reads_to_dict_objects(fixt_init_args_only):
    """ test how df_images is loaded to dict_objects """
    dict_args = fixt_init_args_only
    # 1 - initialize the logger + copy useful files to working folder (if not db usage)
    if not im.initialize_logger_and_temp_folder(dict_args):
        assert False

    # 2 - initialize DB engine
    engine_input = imi.dbconnect(database=dict_args['DB_NAME'])

    # 3 - read datasources (files & db) to dataframes
    dict_df = im.initialize_dataframes_from_sources(dict_args, engine_input)
    assert dict_df is not None

    medlog.logger.info('3 - read list of projects')
    dict_projects = {}
    dict_projects = im.get_project_list_and_mapping(dict_df['df_qc_index'], dict_df['df_project_list'] , dict_args)
    if len(dict_projects) <= 0:
        medlog.logger.error('Process stopped trying to create dictioonnary of projects (qc_index & synonyms)')
        assert False

    # 4 - apply synonyms & exceptions
    if not im.apply_synonyms_to_all_df(dict_args, dict_df):
        assert False
    gc.collect()

    # test is here ! mainly to ensure the program is running without exceptions
    lst_tp_reads_not_in_img = []
    for obj_project in dict_projects.values():
        obj_project.load_images_from_df(dict_df['df_images'][dict_df['df_images']['PROJECTCODE'] == obj_project.project_id])
        obj_project.load_reads_from_df(dict_df['df_reads'][dict_df['df_reads']['PROJECTCODE'] == obj_project.project_id], lst_tp_reads_not_in_img)

    assert True

def test_load_queries_to_dict_objects(fixt_init_args_only):
    """ test how df_queries is loaded to dict_objects """
    dict_args = fixt_init_args_only
    # 1 - initialize the logger + copy useful files to working folder (if not db usage)
    if not im.initialize_logger_and_temp_folder(dict_args):
        assert False

    # 2 - initialize DB engine
    engine_input = imi.dbconnect(database=dict_args['DB_NAME'])

    # 3 - read datasources (files & db) to dataframes
    dict_df = im.initialize_dataframes_from_sources(dict_args, engine_input)
    assert dict_df is not None

    medlog.logger.info('3 - read list of projects')
    dict_projects = {}
    dict_projects = im.get_project_list_and_mapping(dict_df['df_qc_index'], dict_df['df_project_list'] , dict_args)
    if len(dict_projects) <= 0:
        medlog.logger.error('Process stopped trying to create dictioonnary of projects (qc_index & synonyms)')
        assert False

    # 4 - apply synonyms & exceptions
    if not im.apply_synonyms_to_all_df(dict_args, dict_df):
        assert False
    gc.collect()

    # test is here ! mainly to ensure the program is running without exceptions
    lst_tp_not_in_img = []
    for obj_project in dict_projects.values():
        obj_project.load_images_from_df(dict_df['df_images'][dict_df['df_images']['PROJECTCODE'] == obj_project.project_id])
        obj_project.load_queries_from_df(dict_df['df_queries'][dict_df['df_queries']['PROJECTCODE'] == obj_project.project_id], lst_tp_not_in_img)
    assert True


def test_load_rawdata_notverified_to_dict_objects(fixt_init_args_only):
    """ test how df_rawdata_notverified is loaded to dict_objects """
    dict_args = fixt_init_args_only
    # 1 - initialize the logger + copy useful files to working folder (if not db usage)
    if not im.initialize_logger_and_temp_folder(dict_args):
        assert False

    # 2 - initialize DB engine
    engine_input = imi.dbconnect(database=dict_args['DB_NAME'])

    # 3 - read datasources (files & db) to dataframes
    dict_df = im.initialize_dataframes_from_sources(dict_args, engine_input)
    assert dict_df is not None

    medlog.logger.info('3 - read list of projects')
    dict_projects = {}
    dict_projects = im.get_project_list_and_mapping(dict_df['df_qc_index'], dict_df['df_project_list'], dict_args)
    if len(dict_projects) <= 0:
        medlog.logger.error('Process stopped trying to create dictioonnary of projects (qc_index & synonyms)')
        assert False

    # 4 - apply synonyms & exceptions
    if not im.apply_synonyms_to_all_df(dict_args, dict_df):
        assert False
    gc.collect()

    # test is here ! mainly to ensure the program is running without exceptions
    lst_rawdata_warnings = []
    lst_tp_reads_not_in_img = []
    for obj_project in dict_projects.values():
        obj_project.load_images_from_df(dict_df['df_images'][dict_df['df_images']['PROJECTCODE'] == obj_project.project_id])
        obj_project.load_reads_from_df(dict_df['df_reads'][dict_df['df_reads']['PROJECTCODE'] == obj_project.project_id], lst_tp_reads_not_in_img)
        obj_project.load_rawdata_notverified(dict_df['df_rawdata_notverified'][dict_df['df_rawdata_notverified']['PROJECTCODE'] \
                                                                               == obj_project.project_id], lst_rawdata_warnings)
    assert True

def test_load_priorities_to_dict_objects(fixt_init_args_only):
    """ test how df_priorities is loaded to dict_objects """
    dict_args = fixt_init_args_only
    # 1 - initialize the logger + copy useful files to working folder (if not db usage)
    if not im.initialize_logger_and_temp_folder(dict_args):
        assert False

    # 2 - initialize DB engine
    engine_input = imi.dbconnect(database=dict_args['DB_NAME'])

    # 3 - read datasources (files & db) to dataframes
    dict_df = im.initialize_dataframes_from_sources(dict_args, engine_input)
    assert dict_df is not None

    medlog.logger.info('3 - read list of projects')
    dict_projects = {}
    dict_projects = im.get_project_list_and_mapping(dict_df['df_qc_index'], dict_df['df_project_list'], dict_args)
    if len(dict_projects) <= 0:
        medlog.logger.error('Process stopped trying to create dictioonnary of projects (qc_index & synonyms)')
        assert False

    # 4 - apply synonyms & exceptions
    if not im.apply_synonyms_to_all_df(dict_args, dict_df):
        assert False
    gc.collect()

    # test is here ! mainly to ensure the program is running without exceptions
    lst_tp_reads_not_in_img = []
    for obj_project in dict_projects.values():
        obj_project.load_images_from_df(dict_df['df_images'][dict_df['df_images']['PROJECTCODE'] == obj_project.project_id])
        obj_project.load_reads_from_df(dict_df['df_reads'][dict_df['df_reads']['PROJECTCODE'] == obj_project.project_id], lst_tp_reads_not_in_img)
        obj_project.load_priorities(dict_df['df_priorities'][dict_df['df_priorities']['PROJECTCODE'] == obj_project.project_id])
    assert True


def test_calculate_metrics_in_dict_objects(fixt_init_args_only):
    """ test how calculaation of images complex variables is working """
    dict_args = fixt_init_args_only
    # 1 - initialize the logger + copy useful files to working folder (if not db usage)
    if not im.initialize_logger_and_temp_folder(dict_args):
        assert False

    # 2 - initialize DB engine
    engine_input = imi.dbconnect(database=dict_args['DB_NAME'])

    # 3 - read datasources (files & db) to dataframes
    dict_df = im.initialize_dataframes_from_sources(dict_args, engine_input)
    assert dict_df is not None

    medlog.logger.info('3 - read list of projects')
    dict_projects = {}
    dict_projects = im.get_project_list_and_mapping(dict_df['df_qc_index'], dict_df['df_project_list'], dict_args)
    if len(dict_projects) <= 0:
        medlog.logger.error('Process stopped trying to create dictioonnary of projects (qc_index & synonyms)')
        assert False

    # 4 - apply synonyms & exceptions
    if not im.apply_synonyms_to_all_df(dict_args, dict_df):
        assert False
    gc.collect()

    # test is here ! mainly to ensure the program is running without exceptions
    lst_tp_reads_not_in_img = []
    lst_query_tp_not_in_img = []
    lst_rawdata_warnings = []
    for obj_project in dict_projects.values():
        obj_project.load_images_from_df(dict_df['df_images'][dict_df['df_images']['PROJECTCODE'] == obj_project.project_id])
        obj_project.load_reads_from_df(dict_df['df_reads'][dict_df['df_reads']['PROJECTCODE'] == obj_project.project_id], lst_tp_reads_not_in_img)
        obj_project.load_queries_from_df(dict_df['df_queries'][dict_df['df_queries']['PROJECTCODE'] == obj_project.project_id],
                                         lst_query_tp_not_in_img)
        obj_project.load_rawdata_notverified(dict_df['df_rawdata_notverified'][dict_df['df_rawdata_notverified']['PROJECTCODE'] \
                                                                               == obj_project.project_id], lst_rawdata_warnings)
        obj_project.load_priorities(dict_df['df_priorities'][dict_df['df_priorities']['PROJECTCODE'] == obj_project.project_id])

        obj_project.calculate_images_variables()
        obj_project.calculate_reads_variables()
        obj_project.calculate_updated_read_status()
    assert True


def test_compute_df_results_for_exports_and_metrics(fixt_init_args_only):
    """ test computation of the 2 main df for next steps : df_computed_images and reads """
    dict_args = fixt_init_args_only
    # 1 - initialize the logger + copy useful files to working folder (if not db usage)
    if not im.initialize_logger_and_temp_folder(dict_args):
        assert False

    # 2 - initialize DB engine
    engine_input = imi.dbconnect(database=dict_args['DB_NAME'])

    # 3 - read datasources (files & db) to dataframes
    dict_df = im.initialize_dataframes_from_sources(dict_args, engine_input)
    assert dict_df is not None

    medlog.logger.info('3 - read list of projects')
    dict_projects = {}
    dict_projects = im.get_project_list_and_mapping(dict_df['df_qc_index'], dict_df['df_project_list'], dict_args)
    if len(dict_projects) <= 0:
        medlog.logger.error('Process stopped trying to create dictioonnary of projects (qc_index & synonyms)')
        assert False

    # 4 - apply synonyms & exceptions
    if not im.apply_synonyms_to_all_df(dict_args, dict_df):
        assert False
    gc.collect()

    # 5 - load all to objects
    medlog.logger.info('5 - Load and organize data')
    dict_projects =im. load_input_to_objects(dict_args, dict_projects, dict_df)
    if dict_projects is None:
        return

    # clean dataframes (do not free these one as re-used later : df_irlist, df_imqc_forecast, df_rm_forecast)
    try:
        keys_to_delete = ['df_images', 'df_queries', 'df_reads', 'df_qc_index', 'df_synonym', 'df_priorities', 'df_rawdata_notverified']
        for key in keys_to_delete:
            if key in dict_df:
                del dict_df[key]
        gc.collect()    # force garbage collector
    except (NameError, UnboundLocalError) as error_name:
        medlog.logger.error('Issue with memory optimization %s', error_name)

    # 6 - Extract dataframes df_computed_Images and df_computed_read
    medlog.logger.info('6 - Extract dataframes df_computed_Images and df_computed_read')
    df_computed_images, df_computed_reads = im.compute_df_results_for_exports_and_metrics(dict_projects,dict_args)

    assert isinstance(df_computed_images, pd.DataFrame) is True, isinstance(df_computed_reads, pd.DataFrame) is True
    assert len(df_computed_images)>0,  len(df_computed_reads)>0

def test_start_all_small():
    """ test the whole process """
    argument = ['--project', 'ALL', '--mode', 'default', '--log', 'debug', '--db_name', 'DSDB',
                '--results_loc', 'c:\\icro_metrics\\iMetrics\\results',
                '--log_folder', 'c:\\icro_metrics\\iMetrics\\log',
                '--qc_index_loc', './tests/data/qc_index-small.xlsx',
                '--priorities_loc', 'I:\\Project_Management\\Metrics\\iCRO_Priorities.xlsx',
                '--irlist_loc', 'I:\\Procurement\\Direct\\Readers Management\\PROC_PRJ_085_IndependentReviewersList.xlsm',
                '--temp_working_folder', 'c:\\icro_metrics\\iMetrics\\working',
                '--forecast_loc','I:\\Project_management\\Metrics\\iCRO_ActivityForecasts_Current_New.xlsx',
                '--rawdata_loc', 'I:\\Project_management\\Metrics\\Reads\\iCRO_ReadsNotVerified_Current.xlsx',
                '--webresult_loc', 'c:\\icro_metrics\\Web_Outputs', 
                '--agmednet_loc', './tests/data/Median-transfer-report.csv',
                '--autoevalqc_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\Reads\\rawdata_index.xlsx']
    im.start_all(argument)
    assert True


def test_start_all():
    """ test the whole process """
    argument = ['--project', 'ALL', '--mode', 'default', '--log', 'debug', '--db_name', 'DSDB',
                 '--results_loc', 'c:\\icro_metrics\\iMetrics\\results',
                '--log_folder', 'c:\\icro_metrics\\iMetrics\\log',
                '--qc_index_loc', 'I:\\Project_Management\\Metrics\\PH_PRJ_2656_PrepareOperationalMetrics.xlsm',
                '--priorities_loc', 'I:\\Project_Management\\Metrics\\iCRO_Priorities.xlsx',
                '--irlist_loc', 'I:\\Procurement\\Direct\\Readers Management\\PROC_PRJ_085_IndependentReviewersList.xlsm',
                '--temp_working_folder', 'c:\\icro_metrics\\iMetrics\\working',
                '--forecast_loc','I:\\Project_management\\Metrics\\iCRO_ActivityForecasts_Current_New.xlsx',
                '--rawdata_loc', 'I:\\Project_management\\Metrics\\Reads\\iCRO_ReadsNotVerified_Current.xlsx',
                '--webresult_loc', 'c:\\icro_metrics\\Web_Outputs',
                '--agmednet_loc', './tests/data/Median-transfer-report.csv',
                '--autoevalqc_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\Reads\\rawdata_index.xlsx']
    im.start_all(argument)
    assert True


def test_start_all_prod():
    """ test the whole process with production input parameters """
    argument = ['--project', 'ALL', '--log', 'debug', '--db_name', 'DSDB',
            '--results_loc', 'c:\\icro_metrics\\iMetrics\\results',
            '--log_folder', 'c:\\icro_metrics\\iMetrics\\log',
            '--qc_index_loc', 'I:\\Project_management\\Metrics\\PH_PRJ_2656_PrepareOperationalMetrics.xlsm',
            '--priorities_loc','I:\\Project_management\\Metrics\\iCRO_Priorities.xlsx',
            '--irlist_loc', 'DSDB',
            '--temp_working_folder', 'c:\\icro_metrics\\iMetrics\\working',
            '--forecast_loc','I:\\Project_management\\Metrics\\iCRO_ActivityForecasts_Current_New.xlsx',
            '--rawdata_loc', 'I:\\Project_management\\Metrics\\Reads\\iCRO_ReadsNotVerified_Current.xlsx',
            '--webresult_loc', 'c:\\icro_metrics\\Web_Outputs',
            '--agmednet_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\AGMednet\\Median-transfer-report.csv',
            '--autoevalqc_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\Reads\\rawdata_index.xlsx']
    assert im.start_all(argument)


def test_start_unique_project_prod():
    """ test the whole process with production input parameters """
    argument = ['--project', 'ROCH-PH-046', '--log', 'debug', '--db_name', 'DSDB',
            '--results_loc', 'c:\\icro_metrics\\iMetrics\\results',
            '--log_folder', 'c:\\icro_metrics\\iMetrics\\log',
            '--qc_index_loc', 'I:\\Project_management\\Metrics\\PH_PRJ_2656_PrepareOperationalMetrics.xlsm',
            '--priorities_loc','I:\\Project_management\\Metrics\\iCRO_Priorities.xlsx',
            '--irlist_loc', 'DSDB',
            '--temp_working_folder', 'c:\\icro_metrics\\iMetrics\\working',
            '--forecast_loc','I:\\Project_management\\Metrics\\iCRO_ActivityForecasts_Current_New.xlsx',
            '--rawdata_loc', 'I:\\Project_management\\Metrics\\Reads\\iCRO_ReadsNotVerified_Current.xlsx',
            '--webresult_loc', 'c:\\icro_metrics\\Web_Outputs',
            '--agmednet_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\AGMednet\\Median-transfer-report.csv',
            '--autoevalqc_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\Reads\\rawdata_index.xlsx']
    assert im.start_all(argument)
