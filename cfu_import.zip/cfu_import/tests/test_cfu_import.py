""" test module for cfu_import """
from datetime import datetime, timedelta
import os
from pathlib import Path
import pandas as pd
import pytest
import medlog
import cfu_import as cfu

# Liste d'arguments pour effectuer plusieurs tests à la suite
test_arguments = [
                    ["./BO29554-ROCH_CostFollowUp.xlsx"],
                    ["./BO29554-ROCH_CostFollowUpV2.xlsx"],
                    ["./D1553-102-IVTB-CostFollowUp.xlsx"]
                ]

test_arguments_path_type = [
                './tests/data/BO29554-ROCH_CostFollowUp.xlsx',
                './tests/data/BO29554-ROCH_CostFollowUpV2.xlsx',
                './tests/data/D1553-102-IVTB-CostFollowUp.xlsx']
# 'C:\\Users\\sebastien\\OneDrive - Median Technologies SA\\Devs\\Python\\cfu_import\\tests\\data\\BO29554-ROCH_CostFollowUp.xlsx',

@pytest.mark.parametrize('argument_list', test_arguments_path_type)
def test_initialize_dataframes_from_excel(fixt_initlogger_debug, argument_list):
    """ test the initialization of dataframes from an excel file """
    # Initialize logger
    assert fixt_initlogger_debug is True
    test_file_name = Path(argument_list)
    medlog.logger.info('Test file name: %s', test_file_name)
    sheets_to_load = ["Qty Forecast", "Revenus Forecast"]

    # Test
    df_dict, error_message, user_message = cfu.initialize_dataframes_from_excel(test_file_name)

    if df_dict is None:
        medlog.logger.error('Error initializing dataframes from excel: %s', error_message)
        pytest.fail(f"Failed to initialize dataframes: {user_message}")

    # Vérification que les clés existent dans le dictionnaire
    assert all(sheet in df_dict for sheet in sheets_to_load)
    assert len(df_dict) == 2  # Il y a 2 feuilles spécifiques à charger
    assert isinstance(df_dict[sheets_to_load[0]], pd.DataFrame)
    assert isinstance(df_dict[sheets_to_load[1]], pd.DataFrame)

    df_dict[sheets_to_load[0]].to_csv('./tests/results/df_qty_BO29554.csv', index=False)
    df_dict[sheets_to_load[1]].to_csv('./tests/results/df_rev_BO29554.csv', index=False)

    medlog.logger.info('test_initialize_dataframes_from_excel completed')

def test_product_category_column_presence(fixt_load_test_data, fixt_initlogger_debug):
    """ test the get_product_category_position"""
    # Initialize logger
    assert fixt_initlogger_debug is True

    # Load test data
    df_dict, error_message, user_message, file_name = fixt_load_test_data

    if df_dict is None:
        medlog.logger.error('Error loading test data: %s', error_message)
        pytest.fail(f"Failed to load test data: {user_message}")

    for sheet_name, df in df_dict.items():
        product_category_location, error_message, user_message = cfu.get_product_category_position(df)

        assert product_category_location is not None, f"Product_category column not found in sheet '{sheet_name}': {user_message}"
        medlog.logger.info("Product_category column found in sheet %s at location: %s", sheet_name, product_category_location)
    medlog.logger.info('test_product_category_column_presence completed')



def test_date_columns_presence(fixt_load_test_data):
    """ test the get_product_category_position"""
    df_dict, error_message, user_message, file_name = fixt_load_test_data
    for sheet_name, df in df_dict.items():
        product_category_location = cfu.get_product_category_position(df)
        if product_category_location:
            product_category_row = product_category_location[0]
            date_columns = cfu.get_date_columns(df, product_category_row)
            assert date_columns is not None, f"Date columns not found in sheet '{sheet_name}'"
            assert len(date_columns) > 0, f"No date columns found in sheet '{sheet_name}'"


def test_activity_forecast_column_presence(fixt_load_test_data, fixt_initlogger_debug):
    """ test the get_product_category_position"""
    #initialize logger
    assert fixt_initlogger_debug is True

    # Path('./tests/data/BO29554-ROCH_CostFollowUp.xlsx')
    df_dict, error_message, user_message, file_name = fixt_load_test_data

    for sheet_name, df in df_dict.items():
        activity_forecast_location = cfu.get_activity_forecast(df)

        assert activity_forecast_location is not None, f"ActivityForecast column not found in sheet '{sheet_name}'"
        medlog.logger.info("ActivityForecast column found in sheet %s at location: %s", sheet_name, activity_forecast_location)
    medlog.logger.info('test_activity_forecast_column_presence completed')


# def test_create_qty_forecast_df(fixt_load_test_data, fixt_initlogger_debug):
#     """ test function create_qty_forecast_dfs """
#     #initialize logger
#     assert fixt_initlogger_debug is True

#     df_dict, error_message, user_message, file_path = fixt_load_test_data

#     for sheet_name, df in df_dict.items():
#         if sheet_name == "Qty Forecast":
#             product_category_location = cfu.get_product_category_position(df)
#             medlog.logger.debug("Feuille %s Emplacement de la catégorie de produit : %s", sheet_name,  product_category_location)
#             product_category_column_name = product_category_location[1]
#             date_columns = cfu.get_date_columns(df, product_category_location[0])
#             medlog.logger.debug("Feuille %s: Colonnes de dates trouvées : %s", sheet_name, date_columns)
#             new_qty_forecast_df, new_qty_forecast_df_filtered, error_concatenate, error_concatenate_desc = cfu.create_qty_forecast_dfs(df, product_category_column_name, date_columns, file_path)
#             medlog.logger.info("Processed sheet: %s, created dataframes.", sheet_name)
#             assert not new_qty_forecast_df.empty, "Qty Forecast DataFrame was not created"
#             assert not new_qty_forecast_df_filtered.empty, "Qty Forecast Filtered DataFrame was not created"


def test_create_qty_forecast_df(fixt_load_test_data, fixt_initlogger_debug):
    """Test function create_qty_forecast_dfs"""
    # Initialize logger
    assert fixt_initlogger_debug is True

    df_dict, error_message, user_message, file_path = fixt_load_test_data

    if df_dict is None:
        medlog.logger.error('Error loading test data: %s', error_message)
        pytest.fail(f"Failed to load test data: {user_message}")

    for sheet_name, df in df_dict.items():
        if sheet_name == "Qty Forecast":
            product_category_location, error_message, user_message = cfu.get_product_category_position(df)
            medlog.logger.debug("Feuille %s Emplacement de la catégorie de produit : %s", sheet_name,  product_category_location)

            if product_category_location is None:
                medlog.logger.error('Product category location not found: %s', error_message)
                pytest.fail(f"Product category column not found: {user_message}")

            product_category_column_name = product_category_location[1]
            date_columns, error_date_msg, error_date_desc = cfu.get_date_columns(df, product_category_location[0])
            medlog.logger.debug("Feuille %s: Colonnes de dates trouvées : %s", sheet_name, date_columns)

            new_qty_forecast_df, new_qty_forecast_df_filtered, error_concatenate, error_concatenate_desc = cfu.create_qty_forecast_dfs(df, product_category_column_name, date_columns, file_path)

            if new_qty_forecast_df is None or new_qty_forecast_df_filtered is None:
                medlog.logger.error('Error creating quantity forecast DataFrames: %s', error_concatenate)
                pytest.fail(f"Failed to create quantity forecast DataFrames: {error_concatenate_desc}")

            assert not new_qty_forecast_df.empty, "Qty Forecast DataFrame was not created"
            assert not new_qty_forecast_df_filtered.empty, "Qty Forecast Filtered DataFrame was not created"

            medlog.logger.info("Processed sheet: %s, created dataframes.", sheet_name)


def test_create_revenue_forecast_df(fixt_load_test_data, fixt_initlogger_debug):
    """Test function create_revenue_forecast_df"""
    # Initialize logger
    assert fixt_initlogger_debug is True

    df_dict, error_message, user_message, file_path = fixt_load_test_data

    if df_dict is None:
        medlog.logger.error('Error loading test data: %s', error_message)
        pytest.fail(f"Failed to load test data: {user_message}")

    for sheet_name, df in df_dict.items():
        if sheet_name == "Revenus Forecast":
            product_category_location, error_message, user_message = cfu.get_product_category_position(df)
            medlog.logger.debug("Feuille %s Emplacement de la catégorie de produit : %s", sheet_name, product_category_location)

            if product_category_location is None:
                medlog.logger.error('Product category location not found: %s', error_message)
                pytest.fail(f"Product category column not found: {user_message}")

            product_category_column_name = product_category_location[1]
            date_columns, error_date_msg, error_date_desc = cfu.get_date_columns(df, product_category_location[0])
            medlog.logger.debug("Feuille %s: Colonnes de dates trouvées : %s", sheet_name, date_columns)

            new_revenue_forecast_df, error_revenu = cfu.create_revenue_forecast_df(df, product_category_column_name, date_columns, file_path)

            if new_revenue_forecast_df is None:
                medlog.logger.error('Error creating revenue forecast DataFrame: %s', error_revenu)
                pytest.fail("Failed to create revenue forecast DataFrame")

            assert not new_revenue_forecast_df.empty, "New Revenue Forecast DataFrame is empty"

            medlog.logger.info("Processed sheet: %s, created revenue forecast dataframe.", sheet_name)



# def test_merge_dataframes(fixt_load_test_data, fixt_initlogger_debug):
#     """ test merge of dataframes qty and revenues """
#     #initialize logger
#     assert fixt_initlogger_debug is True
#     df_dict, file_path = fixt_load_test_data

#     qty_forecast_df, qty_forecast_df_filtered, revenue_forecast_df = None, None, None
#     for sheet_name, df in df_dict.items():
#         product_category_location = cfu.get_product_category_position(df)
#         medlog.logger.debug("Feuille %s Emplacement de la catégorie de produit : %s", sheet_name, product_category_location)
#         product_category_column_name = product_category_location[1]
#         date_columns = cfu.get_date_columns(df, product_category_location[0])
#         medlog.logger.debug("Feuille %s Colonnes de dates trouvées : %s", sheet_name, date_columns)
#         if sheet_name == "Qty Forecast":
#             qty_forecast_df, qty_forecast_df_filtered, error_concatenate, error_concatenate_desc = cfu.create_qty_forecast_dfs(df, product_category_column_name, date_columns, file_path)
#         elif sheet_name == "Revenus Forecast":
#             revenue_forecast_df = cfu.create_revenue_forecast_df(df, product_category_column_name, date_columns, file_path)
#     final_merged_df, final_merged_df_outer = cfu.merge_dataframes(qty_forecast_df, qty_forecast_df_filtered, revenue_forecast_df)
#     medlog.logger.info("Merged dataframes.")
#     assert not final_merged_df.empty, "Final merged DataFrame is empty. Fusion may have not happened."
#     assert not final_merged_df_outer.empty, "Final (complete) merged DataFrame is empty. Fusion may have not happened"
#     assert 'Amount_quantity' in final_merged_df.columns, "Column 'Amount_quantity' not found in final merged DataFrame"
#     assert 'Amount_revenue' in final_merged_df.columns, "Column 'Amount_revenue' not found in final merged DataFrame"

def test_merge_dataframes(fixt_load_test_data, fixt_initlogger_debug):
    """Test merge of dataframes qty and revenues"""
    # Initialize logger
    assert fixt_initlogger_debug is True

    df_dict, error_message, user_message, file_path = fixt_load_test_data

    if df_dict is None:
        medlog.logger.error('Error loading test data: %s', error_message)
        pytest.fail(f"Failed to load test data: {user_message}")

    qty_forecast_df, qty_forecast_df_filtered, revenue_forecast_df = None, None, None
    for sheet_name, df in df_dict.items():
        product_category_location, error_message, user_message = cfu.get_product_category_position(df)
        medlog.logger.debug("Feuille %s Emplacement de la catégorie de produit : %s", sheet_name, product_category_location)

        if product_category_location is None:
            medlog.logger.error('Product category location not found: %s', error_message)
            pytest.fail(f"Product category column not found: {user_message}")

        product_category_column_name = product_category_location[1]
        date_columns, error_date_msg, error_date_desc = cfu.get_date_columns(df, product_category_location[0])
        medlog.logger.debug("Feuille %s Colonnes de dates trouvées : %s", sheet_name, date_columns)

        if sheet_name == "Qty Forecast":
            qty_forecast_df, qty_forecast_df_filtered, error_concatenate, error_concatenate_desc = cfu.create_qty_forecast_dfs(df, product_category_column_name, date_columns, file_path)

            if qty_forecast_df is None or qty_forecast_df_filtered is None:
                medlog.logger.error('Error creating quantity forecast DataFrames: %s', error_concatenate)
                pytest.fail(f"Failed to create quantity forecast DataFrames: {error_concatenate_desc}")

        elif sheet_name == "Revenus Forecast":
            revenue_forecast_df, error_revenue_msg = cfu.create_revenue_forecast_df(df, product_category_column_name, date_columns, file_path)

            if revenue_forecast_df is None:
                medlog.logger.error('Error creating revenue forecast DataFrame: %s', error_revenue_msg)
                pytest.fail("Failed to create revenue forecast DataFrame")

    final_merged_df, final_merged_df_outer = cfu.merge_dataframes(qty_forecast_df, qty_forecast_df_filtered, revenue_forecast_df)
    medlog.logger.info("Merged dataframes.")

    assert final_merged_df is not None, "Final merged DataFrame is None. Fusion may have failed."
    assert final_merged_df_outer is not None, "Final (complete) merged DataFrame is None. Fusion may have failed."
    assert not final_merged_df.empty, "Final merged DataFrame is empty. Fusion may have not happened."
    assert not final_merged_df_outer.empty, "Final (complete) merged DataFrame is empty. Fusion may have not happened."
    assert 'Amount_quantity' in final_merged_df.columns, "Column 'Amount_quantity' not found in final merged DataFrame"
    assert 'Amount_revenue' in final_merged_df.columns, "Column 'Amount_revenue' not found in final merged DataFrame"


def test_export_to_csv(fixt_load_test_data, fixt_initlogger_debug):
    """Test final extract of results to csv"""
    # Initialize logger
    assert fixt_initlogger_debug is True

    df_dict, error_message, user_message, file_path = fixt_load_test_data

    if df_dict is None:
        medlog.logger.error('Error loading test data: %s', error_message)
        pytest.fail(f"Failed to load test data: {user_message}")

    qty_forecast_df, qty_forecast_df_filtered, revenue_forecast_df = None, None, None
    for sheet_name, df in df_dict.items():
        product_category_location, error_message, user_message = cfu.get_product_category_position(df)
        if product_category_location is None:
            medlog.logger.error('Product category location not found: %s', error_message)
            pytest.fail(f"Product category column not found: {user_message}")

        product_category_column_name = product_category_location[1]
        date_columns, error_date_msg, error_date_desc = cfu.get_date_columns(df, product_category_location[0])
        if date_columns is None:
            medlog.logger.error('Date columns not found: %s', error_date_msg)
            pytest.fail(f"Date columns not found: {error_date_desc}")

        if sheet_name == "Qty Forecast":
            qty_forecast_df, qty_forecast_df_filtered, error_concatenate, error_concatenate_desc = cfu.create_qty_forecast_dfs(df, product_category_column_name, date_columns, file_path)
            if qty_forecast_df is None or qty_forecast_df_filtered is None:
                medlog.logger.error('Error creating quantity forecast DataFrames: %s', error_concatenate)
                pytest.fail(f"Failed to create quantity forecast DataFrames: {error_concatenate_desc}")

        elif sheet_name == "Revenus Forecast":
            revenue_forecast_df, error_revenue_msg = cfu.create_revenue_forecast_df(df, product_category_column_name, date_columns, file_path)
            if revenue_forecast_df is None:
                medlog.logger.error('Error creating revenue forecast DataFrame: %s', error_revenue_msg)
                pytest.fail("Failed to create revenue forecast DataFrame")

    final_merged_df, final_merged_df_outer = cfu.merge_dataframes(qty_forecast_df, qty_forecast_df_filtered, revenue_forecast_df)
    if final_merged_df is None or final_merged_df_outer is None:
        medlog.logger.error('Merging of dataframes failed')
        pytest.fail("Failed to merge DataFrames")

    # Utiliser file_path pour nommer les fichiers CSV
    base_name = os.path.splitext(os.path.basename(file_path))[0]
    output_csv_path = f'{base_name}_final_merged_data.csv'
    output_csv_path_complete = f'{base_name}_final_merged_data_complete.csv'

    # Exporte les DataFrames fusionnés au format CSV
    export_success = cfu.export_to_csv(final_merged_df, final_merged_df_outer, file_path)
    if not export_success:
        pytest.fail("Failed to export DataFrames to CSV")

    medlog.logger.info("Exported merged dataframes to CSV.")

    # Vérifie que les fichiers CSV existent
    assert os.path.exists(output_csv_path), f"File {output_csv_path} was not created"
    assert os.path.exists(output_csv_path_complete), f"File {output_csv_path_complete} was not created"

    # Charge les fichiers CSV exportés pour vérifier qu'ils ne sont pas vides
    df1 = pd.read_csv(output_csv_path, sep=';')
    df2 = pd.read_csv(output_csv_path_complete, sep=';')
    assert not df1.empty, f"Exported CSV {output_csv_path} is empty"
    assert not df2.empty, f"Exported CSV {output_csv_path_complete} is empty"

def test_extract_version_history(fixt_load_test_data):
    df_dict, error_message, user_message, file_path = fixt_load_test_data
    
    # Appeler la fonction
    df_version, error_msg, error_desc, validation_status = cfu.extract_version_history(file_path)
    
    # Vérifier qu'aucune erreur ne s'est produite
    assert df_version is not None, f"DataFrame is None: {error_msg} - {error_desc}"
    assert error_msg == "", f"Error occurred: {error_msg} - {error_desc}"
    
    # Vérifier que le DataFrame n'est pas vide
    assert not df_version.empty, "Version history DataFrame is empty"
    
    # Vérifier que les colonnes attendues sont présentes
    expected_columns = [
        'Histo_Date', 'Histo_Version', 'Histo_Description', 'Histo_Author', 'Histo_Modified', 'Month_Validated',
        'Quart_Forecast_Value', 'Quart_Difference', 'Quart_Rational', 'Quart_Comment', 'Budget_Forecast_Value',
        'Budget_Difference', 'Budget_Rational', 'Budget_Comments', 'Final_Difference_Value', 'Final_Rational',
        'Final_Comments', 'FAE_Total_Amount', 'FAE_Quote_Number', 'FAE_Quote_Status', 'FAE_Quote_Request_Date',
        'FAE_Formal_Approval_Sponsor', 'FAE_Formal_Approval_Median', 'FAE_Estimated_Date_Fix', 'FAE_Additional_Comments'
    ]
    assert list(df_version.columns) == expected_columns, "Column names do not match expected names"

    # Vérifier le statut de validation du mois
    today = datetime.today()
    first_day_of_current_month = datetime(today.year, today.month, 1)
    last_month = first_day_of_current_month - timedelta(days=30)
    first_day_of_last_month = datetime(last_month.year, last_month.month, 1)
    last_month_str = first_day_of_last_month.strftime("%d-%b-%y")
    
    if (df_version['Month_Validated'] == last_month_str).any():
        assert validation_status == "", "Expected validation status to be empty but got 'not_validated'"
    else:
        assert validation_status == "not_validated", "Expected validation status to be 'not_validated'"

def test_extract_version_history2(fixt_load_test_data_2):
    df_dict, error_message, user_message, file_path = fixt_load_test_data_2
    
    # Appeler la fonction
    df_version, error_msg, error_desc, validation_status = cfu.extract_version_history(file_path)
    
    # Vérifier qu'aucune erreur ne s'est produite
    assert df_version is None, f"DataFrame is None: {error_msg} - {error_desc}"
    assert error_msg == "Sheet not found", f"Error occurred: {error_msg} - {error_desc}"
    
    if df_version is not None:

        # Vérifier que le DataFrame n'est pas vide
        assert df_version.empty, "Version history DataFrame is empty"
        
        # Vérifier que les colonnes attendues sont présentes
        expected_columns = [
            'Histo_Date', 'Histo_Version', 'Histo_Description', 'Histo_Author', 'Histo_Modified', 'Month_Validated',
            'Quart_Forecast_Value', 'Quart_Difference', 'Quart_Rational', 'Quart_Comment', 'Budget_Forecast_Value',
            'Budget_Difference', 'Budget_Rational', 'Budget_Comments', 'Final_Difference_Value', 'Final_Rational',
            'Final_Comments', 'FAE_Total_Amount', 'FAE_Quote_Number', 'FAE_Quote_Status', 'FAE_Quote_Request_Date',
            'FAE_Formal_Approval_Sponsor', 'FAE_Formal_Approval_Median', 'FAE_Estimated_Date_Fix', 'FAE_Additional_Comments'
        ]
        assert list(df_version.columns) == expected_columns, "Column names do not match expected names"

        # Vérifier le statut de validation du mois
        today = datetime.today()
        first_day_of_current_month = datetime(today.year, today.month, 1)
        last_month = first_day_of_current_month - timedelta(days=30)
        first_day_of_last_month = datetime(last_month.year, last_month.month, 1)
        last_month_str = first_day_of_last_month.strftime("%d-%b-%y")
        
        if (df_version['Month_Validated'] == last_month_str).any():
            assert validation_status == "", "Expected validation status to be empty but got 'not_validated'"
        else:
            assert validation_status == "not_validated", "Expected validation status to be 'not_validated'"

@pytest.mark.parametrize('argument_list', test_arguments_path_type)
def test_extract_cfu_data_for_bi(argument_list, fixt_initlogger_debug):
    """Test MAIN function of cfu_import : Extract_cfu_data_for_bi"""
    # Initialize logger
    assert fixt_initlogger_debug is True

    result, error_msg, error_desc, user_message = cfu.extract_cfu_data_for_bi(argument_list)
    
    # Vérifier les erreurs
    if result is None:
        medlog.logger.error('Error in extract_cfu_data_for_bi: %s', error_msg)
        pytest.fail(f"extract_cfu_data_for_bi failed: {error_desc}")

    df1, df2 = result

    # Vérifier les types des DataFrames retournés
    assert isinstance(df1, pd.DataFrame), "First returned object is not a DataFrame"
    assert isinstance(df2, pd.DataFrame), "Second returned object is not a DataFrame"

    # Vérifier que les DataFrames ne sont pas vides
    assert not df1.empty, "First DataFrame is empty"
    assert not df2.empty, "Second DataFrame is empty"

    project_code = os.path.splitext(os.path.basename(argument_list))[0]

    # Vérifier que le code projet est correct dans les DataFrames
    assert all(df1['Project_code'] == project_code), f"Project code mismatch in df1 for file {argument_list}"
    assert all(df2['Project_code'] == project_code), f"Project code mismatch in df2 for file {argument_list}"

    output_csv_path = f'{project_code}_final_merged_data.csv'
    output_csv_path_complete = f'{project_code}_final_merged_data_complete.csv'

    # Vérifier que les fichiers CSV ont été créés
    assert os.path.exists(output_csv_path), f"File {output_csv_path} was not created"
    assert os.path.exists(output_csv_path_complete), f"File {output_csv_path_complete} was not created"

    # Charger les fichiers CSV exportés pour vérifier qu'ils ne sont pas vides
    df1_csv = pd.read_csv(output_csv_path, sep=';')
    df2_csv = pd.read_csv(output_csv_path_complete, sep=';')
    assert not df1_csv.empty, f"Exported CSV {output_csv_path} is empty"
    assert not df2_csv.empty, f"Exported CSV {output_csv_path_complete} is empty"


@pytest.mark.parametrize('argument_list', test_arguments_path_type)
def test_extract_cfu_data_for_bi2(argument_list, fixt_initlogger_debug):
    """ test MAIN function of cfu_import : Extract_cfu_data_for_bi WITHOUT csv export"""
    #initialize logger
    assert fixt_initlogger_debug is True
    result, error_msg, error_desc, user_message = cfu.extract_cfu_data_for_bi(argument_list)

    if result is None:
        medlog.logger.error('Error in extract_cfu_data_for_bi: %s', error_msg)
        pytest.fail(f"extract_cfu_data_for_bi failed: {error_desc}")

    df1, df2 = result

    assert isinstance(df1,pd.DataFrame) is True, isinstance(df2,pd.DataFrame) is True
    assert len(df1)>0, len(df2)>0
    project_code = os.path.splitext(os.path.basename(argument_list))[0]
    assert all(df1['Project_code'] == project_code), f"Project code mismatch in df1 for file {argument_list}"
    assert all(df2['Project_code'] == project_code), f"Project code mismatch in df2 for file {argument_list}"

    output_csv_path = f'{project_code}_final_merged_data.csv'
    output_csv_path_complete = f'{project_code}_final_merged_data_complete.csv'
    assert os.path.exists(output_csv_path), f"File {output_csv_path} was not created"
    assert os.path.exists(output_csv_path_complete), f"File {output_csv_path_complete} was not created"

    # Clean up created files for next test
    os.remove(output_csv_path)
    os.remove(output_csv_path_complete)

    result, error_msg, error_desc, user_message = cfu.extract_cfu_data_for_bi(argument_list, export_csv=False)
    
    df1, df2 = result
    assert isinstance(df1, pd.DataFrame) is True
    assert isinstance(df2, pd.DataFrame) is True
    assert len(df1) > 0
    assert len(df2) > 0

    # Check that the files were not created
    assert not os.path.exists(output_csv_path), f"File {output_csv_path} should not have been created"
    assert not os.path.exists(output_csv_path_complete), f"File {output_csv_path_complete} should not have been created"


if __name__ == "__main__":
    pytest.main()
