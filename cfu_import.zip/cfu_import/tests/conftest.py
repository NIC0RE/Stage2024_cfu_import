""" conftest.py module is dedicated to fixtures """

import os
from pathlib import Path
import pytest
import medlog
import cfu_import as cfu

# @pytest.fixture
# def fixt_load_test_data():
#     """ fixture to init """
#     test_file_name = Path('./tests/data/BO29554-ROCH_CostFollowUp.xlsx')
#     os.makedirs('./tests/results', exist_ok = True)
#     # test_file_path = Path('./tests/data' #cfu.find_file_in_parents(test_file_name)

#     df_dict = cfu.initialize_dataframes_from_excel(test_file_name)
#     return df_dict, test_file_name

@pytest.fixture
def fixt_load_test_data():
    """Fixture to load test data from Excel files."""
    try:
        test_file_name = Path('./tests/data/BO29554-ROCH_CostFollowUp.xlsx')
        df_dict, error_message, user_message = cfu.initialize_dataframes_from_excel(test_file_name)
        if df_dict is None:
            return None, error_message, user_message, None
        return df_dict, "", "", test_file_name
    except Exception as e:
        return None, str(e), "Unexpected error while loading test data", None
    
@pytest.fixture
def fixt_load_test_data_2():
    """Fixture to load test data from Excel files."""
    try:
        test_file_name = Path('./tests/data/HS-10296-302-JHSO-Cost_Follow_Up.xlsx')
        df_dict, error_message, user_message = cfu.initialize_dataframes_from_excel(test_file_name)
        if df_dict is None:
            return None, error_message, user_message, None
        return df_dict, "", "", test_file_name
    except Exception as e:
        return None, str(e), "Unexpected error while loading test data", None


@pytest.fixture
def fixt_initlogger_debug():
    """ initialize logging for tests sessions if applicable """
    # Initialize the logger
    log_path = Path('./log/cfu_import_log')
    medlog.initialize_logger(str(log_path), str(log_path) + '_error', medlog.logging.DEBUG, ['html'], 'cfu_import')
    medlog.logger.info("-------------------------------------------------")
    medlog.logger.info("-- DEBUG test session")
    return True


def fixt_initlogger_info():
    """ initialize logging for tests sessions if applicable """
    # Initialize the logger
    log_path = Path('./log/cfu_import_log')
    medlog.initialize_logger(str(log_path), str(log_path) + '_error', medlog.logging.INFO, ['html'], 'cfu_import')
    medlog.logger.info("-------------------------------------------------")
    medlog.logger.info("-- INFO test session")
    return True
