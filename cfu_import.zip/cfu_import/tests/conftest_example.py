""" conftest.py module is dedicated to fixtures """
import pytest
import medlog
import imetrics as im

@pytest.fixture
def fixt_initlogger_and_args():
    """ initialize logging for tests sessions if applicable """
    argument = ['--project', 'ALL', '--log', 'debug', '--db_name', 'DSDB',
                '--results_loc', 'c:\\icro_metrics\\iMetrics\\results',
                '--log_folder', 'c:\\icro_metrics\\iMetrics\\log',
                '--qc_index_loc', './tests/data/PH_PRJ_2656_PrepareOperationalMetrics.xlsm',
                '--priorities_loc','./tests/data/iCRO_Priorities.xlsx',
                '--irlist_loc', './tests/data/PROC_PRJ_085_IndependentReviewersList.xlsm',
                '--temp_working_folder', 'c:\\icro_metrics\\iMetrics\\working',
                '--forecast_loc','./tests/data/iCRO_ActivityForecasts_Current_New.xlsx',
                '--rawdata_loc', './tests/data/iCRO_ReadsNotVerified_Current.xlsx',
                '--webresult_loc', 'c:\\icro_metrics\\Web_Outputs',
                '--agmednet_loc', './tests/data/Median-transfer-report.csv',
                '--autoevalqc_loc', 'I:\\Project_management\\Metrics\\Reads\\rawdata_index.xlsx']

    dict_args = {}
    dict_args = im.get_args_to_dict(argument)
    medlog.initialize_logger(str(dict_args['LOG_PATH']), str(dict_args['LOG_PATH_ERROR']), medlog.logging.DEBUG, ['txt', 'html'], 'imetrics')
    medlog.logger.info('-------------------------------------------------------------------')
    medlog.logger.info('Start test session')
    medlog.logger.info('-------------------------------------------------------------------')

    return dict_args

@pytest.fixture
def fixt_initlogger_and_args_and_working_folder():
    """ initialize logging for tests sessions if applicable """
    argument = ['--project', 'ALL', '--log', 'debug', '--db_name', 'DSDB',
                '--results_loc', 'c:\\icro_metrics\\iMetrics\\results',
                '--log_folder', 'c:\\icro_metrics\\iMetrics\\log',
                '--qc_index_loc', './tests/data/PH_PRJ_2656_PrepareOperationalMetrics.xlsm',
                '--priorities_loc','./tests/data/iCRO_Priorities.xlsx',
                '--irlist_loc', './tests/data/PROC_PRJ_085_IndependentReviewersList.xlsm',
                '--temp_working_folder', 'c:\\icro_metrics\\iMetrics\\working',
                '--forecast_loc','./tests/data/iCRO_ActivityForecasts_Current_New.xlsx',
                '--rawdata_loc', './tests/data/iCRO_ReadsNotVerified_Current.xlsx',
                '--webresult_loc', 'c:\\icro_metrics\\Web_Outputs',
                '--agmednet_loc', './tests/data/Median-transfer-report.csv',
                '--autoevalqc_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\Reads\\rawdata_index.xlsx']

    dict_args = {}
    dict_args = im.get_args_to_dict(argument)
    if not im.initialize_logger_and_temp_folder(dict_args):
        return None
    return dict_args


@pytest.fixture
def fixt_prod_initlogger_and_args():
    """ initialize logging for tests sessions if applicable """
    argument = ['--project', 'ALL', '--log', 'debug', '--db_name', 'DSDB',
                '--results_loc', 'c:\\icro_metrics\\iMetrics\\results',
                '--log_folder', 'c:\\icro_metrics\\iMetrics\\log',
                '--qc_index_loc', 'I:\\Project_management\\Metrics\\PH_PRJ_2656_PrepareOperationalMetrics.xlsm',
                '--priorities_loc','I:\\Project_management\\Metrics\\iCRO_Priorities.xlsx',
                '--irlist_loc', 'DSDB',
                '--temp_working_folder', 'c:\\icro_metrics\\iMetrics\\working',
                '--forecast_loc','I:\\Project_management\\Metrics\\/iCRO_ActivityForecasts_Current_New.xlsx',
                '--rawdata_loc', 'I:\\Project_management\\Metrics\\iCRO_ReadsNotVerified_Current.xlsx',
                '--webresult_loc', 'c:\\icro_metrics\\Web_Outputs',
                '--agmednet_loc', 'I:\\Project_management\\Metrics\\AGMednet\\Median-transfer-report.csv',
                '--autoevalqc_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\Reads\\rawdata_index.xlsx']

    dict_args = {}
    dict_args = im.get_args_to_dict(argument)

    if not im.initialize_logger_and_temp_folder(dict_args):
        return None

    return dict_args


@pytest.fixture
def fixt_prod_init_args_only():
    """ initialize logging for tests sessions if applicable """
    argument = ['--project', 'ALL', '--log', 'debug', '--db_name', 'DSDB',
                '--results_loc', 'c:\\icro_metrics\\iMetrics\\results',
                '--log_folder', 'c:\\icro_metrics\\iMetrics\\log',
                '--qc_index_loc', 'I:\\Project_management\\Metrics\\PH_PRJ_2656_PrepareOperationalMetrics.xlsm',
                '--priorities_loc','I:\\Project_management\\Metrics\\iCRO_Priorities.xlsx',
                '--irlist_loc', 'DSDB',
                '--temp_working_folder', 'c:\\icro_metrics\\iMetrics\\working',
                '--forecast_loc','I:\\Project_management\\Metrics\\iCRO_ActivityForecasts_Current_New.xlsx',
                '--rawdata_loc', 'I:\\Project_management\\Metrics\\Reads\\iCRO_ReadsNotVerified_Current.xlsx',
                '--webresult_loc', 'c:\\icro_metrics\\Web_Outputs',
                '--agmednet_loc', './tests/data/Median-transfer-report.csv',
                '--autoevalqc_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\Reads\\rawdata_index.xlsx']
    dict_args = {}
    dict_args = im.get_args_to_dict(argument)
    return dict_args


@pytest.fixture
def fixt_init_args_only():
    """ initialize logging for tests sessions if applicable """
    argument = ['--project', 'ALL', '--log', 'debug', '--db_name', 'DSDB',
                '--results_loc', 'c:\\icro_metrics\\iMetrics\\results',
                '--log_folder', 'c:\\icro_metrics\\iMetrics\\log',
                '--qc_index_loc', './tests/data/PH_PRJ_2656_PrepareOperationalMetrics.xlsm',
                '--priorities_loc','./tests/data/iCRO_Priorities.xlsx',
                '--irlist_loc', 'DSDB',
                '--temp_working_folder', 'c:\\icro_metrics\\iMetrics\\working',
                '--forecast_loc','./tests/data/iCRO_ActivityForecasts_Current_New.xlsx',
                '--rawdata_loc', './tests/data/iCRO_ReadsNotVerified_Current.xlsx',
                '--webresult_loc', 'c:\\icro_metrics\\Web_Outputs',
                '--agmednet_loc', './tests/data/Median-transfer-report.csv',
                '--autoevalqc_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\Reads\\rawdata_index.xlsx']
    dict_args = {}
    dict_args = im.get_args_to_dict(argument)
    return dict_args


@pytest.fixture
def fixt_initlogger_and_args_missing_synonyms():
    """ initialize logging for tests sessions if applicable """
    argument = ['--project', 'ALL', '--log', 'debug', '--db_name', 'DSDB',
                '--results_loc', 'c:\\icro_metrics\\iMetrics\\results',
                '--log_folder', 'c:\\icro_metrics\\iMetrics\\log',
                '--qc_index_loc', './tests/data/QC_index - missing synonyms.xlsx',
                '--priorities_loc','./tests/data/iCRO_Priorities.xlsx',
                '--irlist_loc', './tests/data/PROC_PRJ_085_IndependentReviewersList.xlsm',
                '--temp_working_folder', 'c:\\icro_metrics\\iMetrics\\working',
                '--forecast_loc','./tests/data/iCRO_ActivityForecasts_Current_New.xlsx',
                '--rawdata_loc', './tests/data/iCRO_ReadsNotVerified_Current.xlsx',
                '--webresult_loc', 'c:\\icro_metrics\\Web_Outputs',
                '--agmednet_loc', './tests/data/Median-transfer-report.csv',
                '--autoevalqc_loc', '\\\\median.cad\\prod\\intranet\\Project_management\\Metrics\\Reads\\rawdata_index.xlsx']
    dict_args = {}
    dict_args = im.get_args_to_dict(argument)
    medlog.initialize_logger(str(dict_args['LOG_PATH']), str(dict_args['LOG_PATH_ERROR']), medlog.logging.DEBUG, ['txt', 'html'], 'imetrics')
    medlog.logger.info('-------------------------------------------------------------------')
    medlog.logger.info('Start test session')
    medlog.logger.info('-------------------------------------------------------------------')

    return dict_args
