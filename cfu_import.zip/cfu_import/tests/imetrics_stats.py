""" this module is responsible to calculate all is required for the icro_project_current_metrics file usinf df_computed_reads

1) start the function with a df or with a path to the file including the df
2) exprot all"""

from pathlib import Path
import datetime as dt
import calendar
import numpy as np
import pandas as pd
import medlog
import imodifxlsx as imx
import cfu_import_all as cfu
# from memory_profiler import profile

def compute_operational_metrics(df_computed_images, df_computed_reads, df_project_list, df_reads_monitoring,
                                df_imqc_forecast, df_rm_forecast, df_initial_reads, current_scope, dict_args):
    """ this function is the main one to calculate metrics """
    try:
        medlog.logger.debug('11.0.1 - optimize df_compute_images')
        df_computed_images = optimize_dtypes(df_computed_images)

        medlog.logger.debug('11.0.2 - optimize df_compute_images')
        df_computed_reads = optimize_dtypes(df_computed_reads)

        ratio_in_the_month = get_current_nb_working_days_ratio()
        df_computed_images.rename(columns={'study_id': 'project_code'}, inplace=True)
        df_computed_reads.rename(columns={'study_id': 'project_code'}, inplace=True)
        df_project_list.columns = df_project_list.columns.str.lower()
        df_project_list.rename(columns={'projectcode': 'project_code'}, inplace=True)

        current_date = dt.datetime.now()
        formatted_target_date = current_date.strftime('%Y-%m').lower()

        # Step 1 : Filter df_imqc_forecast & df_rm_forecast to get all project codes still 'alive'
        df_imqc_forecast_filtered = df_imqc_forecast.dropna(subset=[formatted_target_date])
        df_imqc_forecast_filtered = df_imqc_forecast_filtered[df_imqc_forecast_filtered[formatted_target_date] > 0]

        df_rm_forecast_filtered = df_rm_forecast.dropna(subset=[formatted_target_date])
        df_rm_forecast_filtered = df_rm_forecast_filtered[df_rm_forecast_filtered[formatted_target_date] > 0]

        # Step 2 : Récupérer les valeurs uniques de project_code de df_forecast
        unique_imqc_forecast_project_codes = df_imqc_forecast_filtered['project_code'].unique()
        unique_rm_forecast_project_codes = df_rm_forecast_filtered['project_code'].unique()

        # Step 3 : Récupérer les valeurs uniques de project_code de df_computed_reads
        unique_computed_images_project_codes = df_computed_images['project_code'].unique()
        unique_computed_reads_project_codes = df_computed_reads['project_code'].unique()

        # Step 4 : Combiner les deux ensembles de valeurs uniques
        all_unique_project_codes = pd.unique(np.concatenate((unique_computed_images_project_codes,
                                                            unique_computed_reads_project_codes,
                                                            unique_imqc_forecast_project_codes,
                                                            unique_rm_forecast_project_codes)))

        # Step 5 : Créer un nouveau DataFrame avec toutes les valeurs uniques
        df_metrics_res = pd.DataFrame(all_unique_project_codes, columns=['project_code'])
        df_metrics_res.sort_values(by='project_code', inplace=True)
        df_metrics_res.reset_index(drop=True, inplace=True)

        # Step 6 : project basic parameters
        squad_dict = dict(zip(df_project_list['project_code'], df_project_list['squadid']))
        location_dict = dict(zip(df_project_list['project_code'], df_project_list['location']))
        pm_dict = dict(zip(df_project_list['project_code'], df_project_list['pm']))
        im_dict = dict(zip(df_project_list['project_code'], df_project_list['im']))
        df_metrics_res['squad'] = df_metrics_res['project_code'].map(squad_dict)
        df_metrics_res['location'] = df_metrics_res['project_code'].map(location_dict)
        df_metrics_res['pm'] = df_metrics_res['project_code'].map(pm_dict)
        df_metrics_res['im'] = df_metrics_res['project_code'].map(im_dict)

        # filtered on squad when applicable
        if current_scope != 'all':
            df_metrics_res = df_metrics_res[df_metrics_res['squad']==current_scope]

        # display forecast column for image QC
        # pm_dict = dict(zip(df_imqc_forecast['project_code'], df_imqc_forecast['pm']))
        # df_metrics_res['pm'] = df_metrics_res['project_code'].map(pm_dict)
        current_date_column = get_current_month_column_name()
        imqc_forecast_dict = dict(zip(df_imqc_forecast['project_code'], df_imqc_forecast[current_date_column]))
        df_metrics_res['imqc_forecast'] = df_metrics_res['project_code'].map(imqc_forecast_dict)

        start_date, end_date = get_current_month_start_end_dates()
        calcul_images_nb_received(df_computed_images, df_metrics_res, start_date, end_date)
        df_metrics_res['%_images_received_from_forecast'] = (df_metrics_res['images_nb_received']/df_metrics_res['imqc_forecast']).round(2)
        calcul_images_nb_received_wo_status_received(df_computed_images, df_metrics_res)
        calcul_images_tat_in_progress(df_computed_images, df_metrics_res)
        calcul_images_tat_late(df_computed_images, df_metrics_res)
        calcul_images_in_tracking(df_computed_images, df_metrics_res)
        calcul_images_pending_randomization(df_computed_images, df_metrics_res)

        # TODO trend_images_received_previous_30d
        df_metrics_res['trend_images_received_previous_30d'] = ''

        calcul_images_qc_started(df_computed_images, df_metrics_res, start_date, end_date)
        df_metrics_res['%_images_qc_started'] = (df_metrics_res['images_qc_started']/df_metrics_res['imqc_forecast']).round(2)
        df_metrics_res['%_images_qc_started_current'] = df_metrics_res['%_images_qc_started']/ratio_in_the_month

        # TODO trend_images_qc_done_previous_30d
        df_metrics_res['trend_images_qc_done_previous_30d'] = ''

        calcul_images_action_query(df_computed_images, df_metrics_res)
        calcul_images_qc_pending(df_computed_images, df_metrics_res)
        calcul_images_qc_pending_ecrf_complete(df_computed_images, df_metrics_res)
        calcul_images_qc_pending_between_2_3(df_computed_images, df_metrics_res)
        calcul_images_qc_pending_more_3(df_computed_images, df_metrics_res)

        # add forecast for reads
        rm_forecast_dict = dict(zip(df_rm_forecast['project_code'], df_rm_forecast[current_date_column]))
        df_metrics_res['rm_forecast'] = df_metrics_res['project_code'].map(rm_forecast_dict)

        # calculation metrics for reads
        calcul_reads_qced(df_computed_reads, df_metrics_res, start_date, end_date)
        calcul_initial_reads(df_initial_reads, df_metrics_res)

        # df_metrics_res['%_reads_done'] = (df_metrics_res['reads_qced']/df_metrics_res['rm_forecast']).round(2)
        df_metrics_res['%_reads_done'] = (df_metrics_res['reads_from_initial_rereads']/df_metrics_res['rm_forecast']).round(2)
        df_metrics_res['%_reads_done_current'] = df_metrics_res['%_reads_done']/ratio_in_the_month
        # depreciated : calcul_reads_done_from_reread(df_initial_reads, df_metrics_res)
        # depreciated :  calcul_reads_primary_qced(df_computed_reads, df_metrics_res, start_date, end_date)
        # depreciated :  calcul_reads_adj_qced(df_computed_reads, df_metrics_res, start_date, end_date)

        # TODO trend_reads_done_previous_30d
        df_metrics_res['trend_reads_done_previous_30d'] = ''

        calcul_reads_submitted_notread(df_computed_reads, df_metrics_res)
        calcul_reads_submitted_primary_notread(df_computed_reads, df_metrics_res)
        calcul_reads_submitted_adj_notread(df_computed_reads, df_metrics_res)
        calcul_reads_submitted_pendingqc(df_computed_reads, df_metrics_res)
        calcul_reads_submitted_primary_pendingqc(df_computed_reads, df_metrics_res)
        calcul_reads_submitted_pendingqc_autoqc_ok(df_computed_reads, df_metrics_res)
        calcul_reads_submitted_adj_pendingqc(df_computed_reads, df_metrics_res)
        calcul_reads_submitted_query(df_computed_reads, df_metrics_res)
        calcul_reads_submitted_between_7_10(df_computed_reads, df_metrics_res)
        calcul_reads_submitted_more_10(df_computed_reads, df_metrics_res)
        calcul_reads_notsubmitted(df_computed_reads, df_metrics_res)
        calcul_reads_primary_notsubmitted(df_computed_reads, df_metrics_res)
        calcul_reads_adj_notsubmitted(df_computed_reads, df_metrics_res)
        calcul_reads_pendingqcverif(df_computed_reads, df_metrics_res)
        calcul_reads_auto_qced(df_computed_reads, df_metrics_res, start_date, end_date)
        calcul_reads_auto_qced_screening(df_computed_reads, df_metrics_res)
        calcul_reads_pending_querycheck(df_computed_reads, df_metrics_res)

        if dict_args['LOG_MODE'] == medlog.logging.DEBUG:
            medlog.logger.debug('8.1 - calculate sum for df_metrics_res')

        # sum().to_frame().T transforme la série des sommes en DataFrame (une ligne) et transpose result to have sums in line and not column
        sum_row = df_metrics_res[['imqc_forecast', 'images_nb_received', 'images_tat_in_progress', 'images_tat_late', 'images_in_tracking',
                          'images_pending_randomization', 'images_qc_started', 'images_nb_received_wo_status_received', 'images_action_query',
                          'images_qc_pending', 'images_qc_pending_ecrf_complete', 'images_qc_pending_between_2_3', 'images_qc_pending_more_3',
                          'rm_forecast', 'reads_qced', 'reads_from_initial_rereads', 'reads_primary_done', 'reads_adj_done', 'reads_gr_done',
                          'submitted_notread', 'submitted_prim_notread', 'submitted_adj_notread', 'reads_qc_pending',
                          'reads_primary_qc_pending', 'reads_qc_pending_autoqcok', 'reads_adj_qc_pending',
                          'reads_query',
                          'reads_submitted_between_7_10', 'reads_submitted_more_10',
                          'reads_not_submitted', 'reads_primary_not_submitted', 'reads_adj_not_submitted',
                          'reads_qc_pending_verif',
                          'reads_autoqced', 'reads_autoqced_screening', 'reads_pending_querycheck']].sum().to_frame().T
        sum_row.index = ['Sum'] # Donner un nom à l'index de la ligne de somme
        df_metrics_res = pd.concat([sum_row, df_metrics_res], ignore_index=False) # Concaténer la ligne de somme avec le DataFrame original

        # calculate total for %_images_received_from_forecast
        calculate_total_of_line_percentage(df_metrics_res, '%_images_received_from_forecast', 'images_nb_received','imqc_forecast', 'Sum', False)
        calculate_total_of_line_percentage(df_metrics_res, '%_images_qc_started', 'images_qc_started','imqc_forecast', 'Sum', False)
        calculate_total_of_line_percentage(df_metrics_res,'%_images_qc_started_current', 'images_qc_started','imqc_forecast', 'Sum', True)
        calculate_total_of_line_percentage(df_metrics_res, '%_reads_done', 'reads_qced','rm_forecast', 'Sum', False)
        calculate_total_of_line_percentage(df_metrics_res, '%_reads_done_current', 'reads_qced','rm_forecast', 'Sum', True)

        df_metrics_res = df_metrics_res[['project_code', 'squad', 'location', 'pm', 'im',
                                         'imqc_forecast', 'images_nb_received', '%_images_received_from_forecast',
                                         'images_tat_in_progress', 'images_tat_late', 'images_in_tracking', 'images_pending_randomization',
                                         'trend_images_received_previous_30d', 'images_qc_started',
                                         '%_images_qc_started_current', '%_images_qc_started', 'trend_images_qc_done_previous_30d',
                                         'images_nb_received_wo_status_received', 'images_action_query',
                                         'images_qc_pending', 'images_qc_pending_ecrf_complete', 
                                         'images_qc_pending_between_2_3', 'images_qc_pending_more_3',
                                         'rm_forecast', 'reads_qced', 
                                         'reads_from_initial_rereads', 'reads_primary_done', 'reads_adj_done', 'reads_gr_done',
                                         '%_reads_done_current',  '%_reads_done', 'trend_reads_done_previous_30d',
                                         'submitted_notread', 'submitted_prim_notread', 'submitted_adj_notread',
                                         'reads_qc_pending', 'reads_primary_qc_pending', 'reads_qc_pending_autoqcok', 'reads_adj_qc_pending',
                                         'reads_query',
                                         'reads_submitted_between_7_10', 'reads_submitted_more_10',
                                         'reads_not_submitted', 'reads_primary_not_submitted', 'reads_adj_not_submitted',
                                         'reads_qc_pending_verif',
                                         'reads_autoqced', 'reads_autoqced_screening', 'reads_pending_querycheck']]
        # TODO: perf TAT : TAT Succeed	/ TAT Failed / % during period / % since project is started
    except (KeyError, IndexError, ValueError, TypeError, AttributeError, PermissionError) as error_key:
        medlog.logger.error('Error during preparation of iCRO_Projects_Metrics_Current.xlsx (df_metrics_res): %s', error_key)
        return False

    # prepare wig sheet of the file. Scope is passed through filtered df (images, reads and projectlist)
    df_metrics_wig_res = compute_wigs(df_computed_images, df_computed_reads, df_project_list, all_unique_project_codes, current_scope)

    # prepare wig sheet of the file. Scope is passed through filtered df (images, reads and projectlist)
    df_metrics_monitoring_res = compute_monitoring(df_computed_reads, df_reads_monitoring, df_project_list)

    try:
        if dict_args['LOG_MODE'] == medlog.logging.DEBUG:
            if current_scope == 'all':
                csv_filename = dict_args['RESULTS_LOC'] / 'iCRO_Projects_Metrics_Current.csv'
            else:
                new_scope = current_scope.replace(' ', '')
                csv_filename = dict_args['RESULTS_LOC'] / f'iCRO_Projects_Metrics_{new_scope}_Current.csv'
            df_metrics_res.to_csv(csv_filename, index=False)

        if current_scope == 'all':
            xlsx_name = 'iCRO_Projects_Metrics_Current.xlsx'
        else:
            new_scope = current_scope.replace(' ', '')
            xlsx_name = f'iCRO_Projects_Metrics_{new_scope}_Current.xlsx'

        xlsx_filename_tmpl =  Path('./iCRO_Projects_Metrics_Current_model.xlsx')
        xlsx_result_filename = dict_args['RESULTS_LOC'] / xlsx_name

        sheet_name1 = 'ActivityMetrics'
        columns_to_hide1 = ['M', 'Q', 'AF']
        sheet_name2 = 'wig'
        columns_to_hide2 = []
        sheet_name3 = 'monitoring'
        columns_to_hide3 = []
        imx.copy_3_df_to_formatted_excel(df_metrics_res, df_metrics_wig_res, df_metrics_monitoring_res,
                                         xlsx_filename_tmpl, sheet_name1, sheet_name2, sheet_name3, 3, 3, 3,
                                         xlsx_result_filename, columns_to_hide1, columns_to_hide2, columns_to_hide3)
    except (KeyError, IndexError, ValueError, TypeError, AttributeError, PermissionError) as error_key:
        medlog.logger.warning('df_metrics_res writing failed to file iCRO_Projects_Metrics_Current.xlsx (probably open): %s', error_key)
    try:
        del df_computed_images, df_computed_reads, df_metrics_res, df_metrics_wig_res, df_metrics_monitoring_res
    except (KeyError, IndexError, ValueError, TypeError, AttributeError, PermissionError) as error_key:
        medlog.logger.warning('Issue while closing program (dataframe memory): %s', error_key)
    return True


def compute_wigs(df_computed_images, df_computed_reads, df_project_list, all_unique_project_codes, current_scope):
    """ this function is the main one to calculate WIGS for Image QC and reads """
    try:
        medlog.logger.debug('11.2 - calculate wigs')
        # Step 1 : Créer un nouveau DataFrame avec toutes les valeurs uniques
        df_metrics_wig_res = pd.DataFrame(all_unique_project_codes, columns=['project_code'])
        df_metrics_wig_res.sort_values(by='project_code', inplace=True)
        df_metrics_wig_res.reset_index(drop=True, inplace=True)

        # Step 2 : project basic parameters
        squad_dict = dict(zip(df_project_list['project_code'], df_project_list['squadid']))
        location_dict = dict(zip(df_project_list['project_code'], df_project_list['location']))
        pm_dict = dict(zip(df_project_list['project_code'], df_project_list['pm']))
        im_dict = dict(zip(df_project_list['project_code'], df_project_list['im']))
        df_metrics_wig_res['squad'] = df_metrics_wig_res['project_code'].map(squad_dict)
        df_metrics_wig_res['location'] = df_metrics_wig_res['project_code'].map(location_dict)
        df_metrics_wig_res['pm'] = df_metrics_wig_res['project_code'].map(pm_dict)
        df_metrics_wig_res['im'] = df_metrics_wig_res['project_code'].map(im_dict)

        # Step 3 : wig images
        start_wig_image_date, end_wig_image_date = get_current_wig_images_dates()
        calcul_images_qc_wig(df_computed_images, df_metrics_wig_res, start_wig_image_date, end_wig_image_date)

        # Step 4 : wig reads
        start_wig_reads_date, end_wig_reads_date = get_current_wig_reads_dates()
        calcul_reads_qc_wig(df_computed_reads, df_metrics_wig_res, start_wig_reads_date, end_wig_reads_date)

        # should be done BEFORE the sum else it will remove it !
        if current_scope != 'all':
            df_metrics_wig_res = df_metrics_wig_res[df_metrics_wig_res['squad']==current_scope]

        # sum().to_frame().T transforme la série des sommes en DataFrame (une ligne) et transpose result to have sums in line and not column
        sum_row = df_metrics_wig_res[['imqc_received_during_period', 'imqc_done_within_3wd_during_period',
                                        'reads_submitted_during_period', 'reads_done_within_10wd_during_period']].sum().to_frame().T
        sum_row.index = ['Sum'] # Donner un nom à l'index de la ligne de somme
        df_metrics_wig_res = pd.concat([sum_row, df_metrics_wig_res], ignore_index=False) # Concaténer la ligne de somme avec le DataFrame original

        # calculate total for %_images_received_from_forecast
        calculate_total_of_line_percentage(df_metrics_wig_res, '%_imqc_done_within_3wd_during_period',
                                           'imqc_done_within_3wd_during_period','imqc_received_during_period', 'Sum', False)
        calculate_total_of_line_percentage(df_metrics_wig_res, '%_reads_done_within_10wd_during_period',
                                           'reads_done_within_10wd_during_period','reads_submitted_during_period', 'Sum', False)

        df_metrics_wig_res = df_metrics_wig_res[['project_code', 'squad', 'location', 'pm', 'im',
                                                 'imqc_start_date', 'imqc_end_date',
                                                 'imqc_received_during_period', 'imqc_done_within_3wd_during_period',
                                                 '%_imqc_done_within_3wd_during_period',
                                                 'reads_start_date', 'reads_end_date',
                                                 'reads_submitted_during_period', 'reads_done_within_10wd_during_period',
                                                 '%_reads_done_within_10wd_during_period']]



    except (KeyError, IndexError, ValueError, TypeError, AttributeError, PermissionError) as error_key:
        medlog.logger.warning('Error during preparation of iCRO_Projects_Metrics_Current.xlsx (wig part): %s', error_key)
        return None
    return df_metrics_wig_res

def compute_monitoring(df_computed_reads, df_reads_monitoring, df_project_list):
    """ this function is calculating monitoring metrics reads. 2 use case: 
        - case 1 (current) = IR1 +IR2 are eval_qc_status (not real read) == done* AND screening are excluded ! => tp is counted
        - case 2 (old projects) not supported because 'not required' are filtered from df_computed_reads. 
        Support would be possible with idec but not available on 'old' projects... 
        df_reads_monitoring : project_code, criteria, sop_revision, total_expected 
        project_code, eval_blinded_subjectid, timepoint_name, eval_ir_criteria, eval_ir_type, eval_qc_status
    """
    medlog.logger.debug('11.3 - calculate monitoring metrics')
    # df_metrics_mon_res = df_reads_monitoring.copy()
    df_computed_reads_reduced = df_computed_reads[['project_code', 'eval_blinded_subjectid', 'timepoint_name', 'eval_qc_status',
                                                   'eval_ir_type', 'eval_ir_criteria']]

    unique_project_codes = df_computed_reads_reduced['project_code'].unique()
    df_metrics_mon_all = pd.DataFrame(columns=['project_code', 'squad', 'location', 'pm', 'im',
                                                 'eval_ir_criteria', 'sop_revision',
                                                 'nb_reads_done_case1', 'total_expected', '%_reads_done'])
    for project_code in unique_project_codes:
        try:
            df_temp_computed_reads = df_computed_reads_reduced[df_computed_reads_reduced['project_code']==project_code].copy()
            df_temp_reads_monitoring = df_reads_monitoring[df_reads_monitoring['project_code']==project_code].copy()
            df_temp_project_list = df_project_list[df_project_list['project_code']==project_code].copy()

            df_metrics_mon_inter = compute_monitoring_project(df_temp_computed_reads,
                                                              df_temp_reads_monitoring,
                                                              df_temp_project_list)
            df_metrics_mon_all = pd.concat([df_metrics_mon_all, df_metrics_mon_inter], axis=0, ignore_index=True)

            del df_temp_computed_reads, df_temp_reads_monitoring, df_temp_project_list
        except (KeyError, IndexError, ValueError, TypeError, AttributeError, PermissionError) as error_concat:
            medlog.logger.error('Issue while concatenating monitoring metrics from project : %s : %s', project_code, error_concat)
            continue
    try:
        df_metrics_mon_all.sort_values(by='project_code', inplace=True)
        df_metrics_mon_all.reset_index(drop=True, inplace=True)

    except (KeyError, IndexError, ValueError, TypeError, AttributeError, PermissionError) as error_sort:
        medlog.logger.warning('Failed to sort the monitoring metrics by project code: %s', error_sort)

    return df_metrics_mon_all if not df_metrics_mon_all.empty else None



def compute_monitoring_project(df_computed_reads, df_reads_monitoring, df_project_list):
    """ this function is calculating monitoring metrics reads for 1 project (memory issues)
        df_reads_monitoring : project_code, criteria, sop_revision, total_expected 
        project_code, eval_blinded_subjectid, timepoint_name, eval_ir_criteria, eval_ir_type, eval_qc_status
    """
    try:
        df_computed_reads = reset_categories(df_computed_reads)
        df_reads_monitoring = reset_categories(df_reads_monitoring)
        df_project_list = reset_categories(df_project_list)

        # Filtrer les lignes avec eval_ir_type 'IR1', 'IR2', 'IR3' et (eval_qc_status 'done' ou 'qc_pending_verif') et tp <> 'screening'
        mask_done = df_computed_reads['eval_qc_status'].str[:4].str.lower() == 'done'
        mask_pending = df_computed_reads['eval_qc_status'].str.lower() == 'qc_pending_verif'
        mask_types = df_computed_reads['eval_ir_type'].isin(['IR1', 'IR2', 'IR3'])
        # mask_screening = df_computed_reads['timepoint_name'].str.lower() != 'screening'
        filtered_df_case1 = df_computed_reads[mask_types & (mask_done | mask_pending)] #  & mask_screening

        # Grouper par les colonnes spécifiées et compter les eval_ir_type distincts qui sont 'done'
        grouped_case1 = filtered_df_case1.groupby(['project_code', 'eval_blinded_subjectid', 'eval_ir_criteria', 'timepoint_name'])\
                                                  .agg(count_eval_ir_done=('eval_ir_type', 'count'))\
                                                  .reset_index()

        # # Conserver les groupes où au moins deux eval_ir_type sont 'done'
        valid_groups_case1 = grouped_case1[grouped_case1['count_eval_ir_done'] >= 2]

       # Rejoindre avec le DataFrame initial pour obtenir les lignes complètes
        df_reads_res_case1 = pd.merge(valid_groups_case1, df_computed_reads, on=['project_code', 'eval_blinded_subjectid',
                                                                                 'eval_ir_criteria', 'timepoint_name'])

        # Suppression des doublons basés sur les colonnes d'intérêt
        df_reads_res_case1_unique = df_reads_res_case1.drop_duplicates(subset=['project_code', 'eval_ir_criteria',
                                                                               'eval_blinded_subjectid', 'timepoint_name'])

        # Compter le nombre de lignes dans df_reads_res_case1_unique par (project_code, eval_ir_criteria)
        count_df_case1 = df_reads_res_case1_unique.groupby(['project_code', 'eval_ir_criteria']).size().reset_index(name='nb_reads_done_case1')

        # Fusionner avec df_metrics_mon_res pour ajouter la colonne nb_reads_done_case1
        df_metrics_mon_res = df_reads_monitoring.merge(count_df_case1, on=['project_code', 'eval_ir_criteria'], how='left')

        # Remplacer les valeurs NaN par 0 dans la colonne nb_reads_done_case1
        df_metrics_mon_res['nb_reads_done_case1'] = df_metrics_mon_res['nb_reads_done_case1'].fillna(0)

        # Ajouter la colonne '%_reads_done' en fonction de 'sop_revision'
        df_metrics_mon_res['%_reads_done'] = (df_metrics_mon_res['nb_reads_done_case1'] / df_metrics_mon_res['total_expected']).round(2)

        # Ajouter des informations supplémentaires à partir de df_project_list
        df_project_list = df_project_list.set_index('project_code')
        df_metrics_mon_res['squad'] = df_metrics_mon_res['project_code'].map(df_project_list['squadid'])
        df_metrics_mon_res['location'] = df_metrics_mon_res['project_code'].map(df_project_list['location'])
        df_metrics_mon_res['pm'] = df_metrics_mon_res['project_code'].map(df_project_list['pm'])
        df_metrics_mon_res['im'] = df_metrics_mon_res['project_code'].map(df_project_list['im'])

        df_metrics_mon_res = df_metrics_mon_res[['project_code', 'squad', 'location', 'pm', 'im',
                                                 'eval_ir_criteria', 'sop_revision',
                                                 'nb_reads_done_case1', 'total_expected', '%_reads_done']]

    except (KeyError, IndexError, ValueError, TypeError, AttributeError, PermissionError) as error_key:
        medlog.logger.warning('Error during preparation of iCRO_Projects_Metrics_Current.xlsx (monitoring part): %s', error_key)
        return None
    return df_metrics_mon_res if not df_metrics_mon_res.empty else None


def optimize_dtypes(df_to_optimize):
    """ optimize memory allocation by using category dtype"""
    try:
        for col in df_to_optimize.select_dtypes(include=['object']).columns:
            try:
                if col in ('subject_id', 'eval_blinded_subjectid'):
                    continue
                num_unique_values = len(df_to_optimize[col].unique())
                num_total_values = len(df_to_optimize[col])
                if num_total_values == 0:
                    continue
                if num_unique_values / num_total_values < 0.5:
                    df_to_optimize[col] = df_to_optimize[col].astype('category')
            except (TypeError, ValueError) as error_conv:
                medlog.logger.warning('Error converting column %s to category: %s', col, error_conv)
                continue
        return df_to_optimize
    except Exception as error_conv_glb:
        medlog.logger.warning('Error optimizing dtypes: %s ', error_conv_glb)
        return df_to_optimize


def reset_categories(df_to_optimize):
    """
    Réinitialiser les catégories pour les colonnes de type 'category' dans le DataFrame.
    """
    for col in df_to_optimize.select_dtypes(include=['category']).columns:
        df_to_optimize[col] = df_to_optimize[col].cat.remove_unused_categories()
    return optimize_dtypes(df_to_optimize)


def get_current_month_column_name():
    """ return the current month using format Sep-2023"""
    current_date = dt.datetime.now()
    # Formater la date au format souhaité
    formatted_target_date = current_date.strftime('%Y-%m').lower()
    return formatted_target_date


def get_current_month_start_end_dates():
    """ return the current month using format Sep-2023"""
    current_date = dt.datetime.now()
    start_date = current_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    # Trouver le premier jour du mois suivant
    if current_date.month == 12:  # si c'est décembre
        first_day_next_month = dt.datetime(current_date.year + 1, 1, 1)
    else:
        first_day_next_month = dt.datetime(current_date.year, current_date.month + 1, 1)

    # Soustraire une seconde pour obtenir la dernière seconde du mois actuel
    end_date = first_day_next_month - dt.timedelta(seconds=1)
    return start_date, end_date


def get_current_wig_images_dates():
    """ get dates used for WIGS images: within 30d last calcul-able days (let 3wd) """
    current_date = dt.datetime.now()
    start_date = current_date - dt.timedelta(days=33)
    end_date = current_date - dt.timedelta(days=3)
    return start_date, end_date


def get_current_wig_reads_dates():
    """ get dates used for WIGS reads: within 30d last calcul-able days (let 10wd) """
    current_date = dt.datetime.now()
    start_date = current_date - dt.timedelta(days=44)
    end_date = current_date - dt.timedelta(days=14)
    return start_date, end_date


def get_current_nb_working_days_ratio():
    """ get_current_nb_working_days_ratio : calcul where we are in the month (ratio of nb working days )"""
    start_date, end_date = get_current_month_start_end_dates()

    current_date = dt.datetime.now()

    current_wd = np.busday_count(start_date.date(), current_date.date())
    total_wd = np.busday_count(start_date.date(), end_date.date())

    return float(current_wd/total_wd)


def calcul_images_nb_received(df_computed_images, df_metrics_res, start_date, end_date):
    """Images received during current month """
    try:
        df_computed_images['filter'] = (df_computed_images['img_first_receiveddate']>=start_date) &\
                                        (df_computed_images['img_first_receiveddate']<= end_date)
        df_computed_images['images_nb_received'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_nb_received']))
        df_metrics_res['images_nb_received'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_nb_received']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_nb_received failed: %s', error_read)
    return True


def calcul_images_nb_received_wo_status_received(df_computed_images, df_metrics_res):
    """Images received during current month """
    try:
        df_computed_images['filter'] = ((df_computed_images['img_qc_status'].str[:8].str.lower() == 'tracking') |\
                                        (df_computed_images['img_qc_status'].str[:9].str.lower() == 'undefined')) &\
                                        (df_computed_images['img_reception_status'].str.lower() == 'received nqc')

        df_computed_images['images_nb_received_wo_status_received'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_nb_received_wo_status_received']))
        df_metrics_res['images_nb_received_wo_status_received'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_nb_received_wo_status_received']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_nb_received but not identified as received failed: %s', error_read)
    return True

def calcul_images_tat_in_progress(df_computed_images, df_metrics_res):
    """Images received during current month """
    try:
        df_computed_images['filter'] = df_computed_images['tat_status'].isin(['in progress', 'pending img qc'])
        df_computed_images['images_tat_in_progress'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_tat_in_progress']))
        df_metrics_res['images_tat_in_progress'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_tat_in_progress']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_tat_in_progress failed: %s', error_read)
    return True


def calcul_images_tat_late(df_computed_images, df_metrics_res):
    """calcul_images_tat_late """
    try:
        df_computed_images['filter'] = df_computed_images['tat_status'].str.lower()=='late'
        df_computed_images['images_tat_late'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_tat_late']))
        df_metrics_res['images_tat_late'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_tat_late']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_tat_late failed: %s', error_read)
    return True


def calcul_images_in_tracking(df_computed_images, df_metrics_res):
    """calcul_images_in_tracking """
    try:
        df_computed_images['filter'] = df_computed_images['img_qc_status'].str[:8].str.lower() == 'tracking'
        df_computed_images['images_in_tracking'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_in_tracking']))
        df_metrics_res['images_in_tracking'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_in_tracking']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_in_tracking failed: %s', error_read)
    return True


def calcul_images_pending_randomization(df_computed_images, df_metrics_res):
    """calcul_images_pending_randomization """
    try:
        df_computed_images['filter'] =df_computed_images['img_qc_status'].str[:13].str.lower()=='pending rando'
        df_computed_images['images_pending_randomization'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_pending_randomization']))
        df_metrics_res['images_pending_randomization'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_pending_randomization']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_pending_randomization failed: %s', error_read)
    return True


def calcul_images_qc_started(df_computed_images, df_metrics_res, start_date, end_date):
    """ Images qc-ed this month (qc started) """
    try:
        df_computed_images['filter'] = ( ((df_computed_images['img_qc_status'].str[:4].str.lower()=='done') | \
                                          (df_computed_images['img_qc_status'].str[:5].str.lower()=='query')) &\
                                         (df_computed_images['img_qc_firstdate']>=start_date) &\
                                         (df_computed_images['img_qc_firstdate']<= end_date) )
        df_computed_images['images_qc_started'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_qc_started']))
        df_metrics_res['images_qc_started'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_qc_started']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_qc_started failed: %s', error_read)
    return True


def calcul_images_action_query(df_computed_images, df_metrics_res):
    """ Images with an action-query status (qc started) """
    try:
        df_computed_images['filter'] = (df_computed_images['img_qc_status'].str[:5].str.lower()=='query') &\
                                       (df_computed_images['img_qc_status_original'].str.lower()=='action-query')
        df_computed_images['images_action_query'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_action_query']))
        df_metrics_res['images_action_query'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_action_query']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_action_query failed: %s', error_read)
    return True


def calcul_images_qc_pending(df_computed_images, df_metrics_res):
    """ Images qc pending (qc started) """
    try:
        df_computed_images['filter'] = df_computed_images['img_qc_status'].str[:6].str.lower()=='receiv'
        df_computed_images['images_qc_pending'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_qc_pending']))
        df_metrics_res['images_qc_pending'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_qc_pending']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_qc_pending failed: %s', error_read)
    return True


def calcul_images_qc_pending_ecrf_complete(df_computed_images, df_metrics_res):
    """ Images qc pending with ecrf reconciliation status = complete """
    try:
        df_computed_images['filter'] = (df_computed_images['img_qc_status'].str[:6].str.lower()=='receiv') &\
                                       (df_computed_images['img_ecrf_reconciliation_status'].str.lower()=='complete')
        df_computed_images['images_qc_pending_ecrf_complete'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_qc_pending_ecrf_complete']))
        df_metrics_res['images_qc_pending_ecrf_complete'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_qc_pending_ecrf_complete']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_qc_pending with ecrf reconciliation complete failed: %s', error_read)
    return True

def calcul_images_qc_pending_between_2_3(df_computed_images, df_metrics_res):
    """ calcul_images_qc_pending_between_2_3 """
    try:
        two_business_days_ago = np.busday_offset(dt.date.today(), -2, roll='backward')
        three_business_days_ago = np.busday_offset(dt.date.today(), -3, roll='backward')

        # received additional not included
        df_computed_images['filter'] = (df_computed_images['img_qc_status'].str.lower()=='received') & \
                                        (df_computed_images['img_first_receiveddate']<two_business_days_ago) &\
                                        (df_computed_images['img_first_receiveddate']>= three_business_days_ago)
        df_computed_images['images_qc_pending_between_2_3'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_qc_pending_between_2_3']))
        df_metrics_res['images_qc_pending_between_2_3'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_qc_pending_between_2_3']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_qc_pending_between_2_3 failed: %s', error_read)
    return True


def calcul_images_qc_pending_more_3(df_computed_images, df_metrics_res):
    """ calcul_images_qc_pending_more_3 """
    try:
        three_business_days_ago = np.busday_offset(dt.date.today(), -3, roll='backward')

        # received additional not included
        df_computed_images['filter'] = (df_computed_images['img_qc_status'].str.lower()=='received') & \
                                       (df_computed_images['img_first_receiveddate']< three_business_days_ago)
        df_computed_images['images_qc_pending_more_3'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['images_qc_pending_more_3']))
        df_metrics_res['images_qc_pending_more_3'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_images['filter'], df_computed_images['images_qc_pending_more_3']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_qc_pending_more_3 failed: %s', error_read)
        return False
    return True


def calcul_reads_qced(df_computed_reads, df_metrics_res, start_date, end_date):
    """ calcul number of reads qc-ed during the period : incl. status done + qc_pending_verif"""
    try:
        df_computed_reads['filter'] = ((df_computed_reads['eval_qc_status'].str[:4].str.lower()=='done') |
                                       (df_computed_reads['eval_qc_status'].str.lower()=='qc_pending_verif')) &\
                                      (df_computed_reads['eval_qc_enddate']>=start_date) &\
                                      (df_computed_reads['eval_qc_enddate']<= end_date)

        df_computed_reads['reads_qced'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_qced']))
        df_metrics_res['reads_qced'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_qced']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads qc-ed during the period failed: %s', error_read)
        return False
    return True


def calcul_initial_reads(df_initial_reads, df_metrics_res):
    """ to complete the number of reads from qc enddate, the initial reads is added """
    try:
        # Grouper par 'project_code' et calculer la somme des colonnes 'nb1', 'nb2', 'nb3'
        grouped = df_initial_reads.groupby('project_code').sum()
        # Créer le dictionnaire initial_read_dict
        initial_read_dict = {}
        initial_primary_read_dict = {}
        initial_adj_read_dict = {}
        initial_gr_read_dict = {}
        for project_code, row in grouped.iterrows():
            initial_read_dict[project_code] = row['nb_primary_reads'] + row['nb_adjudications'] + row['nb_global_reviews']
            initial_primary_read_dict[project_code] = row['nb_primary_reads']
            initial_adj_read_dict[project_code] = row['nb_adjudications']
            initial_gr_read_dict[project_code] = row['nb_global_reviews']
        df_metrics_res['reads_from_initial_rereads'] = df_metrics_res['project_code'].map(initial_read_dict)
        df_metrics_res['reads_primary_done'] = df_metrics_res['project_code'].map(initial_primary_read_dict)
        df_metrics_res['reads_adj_done'] = df_metrics_res['project_code'].map(initial_adj_read_dict)
        df_metrics_res['reads_gr_done'] = df_metrics_res['project_code'].map(initial_gr_read_dict)

    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads from reread initial failed: %s', error_read)
        return False
    return True


def calcul_reads_primary_qced(df_computed_reads, df_metrics_res, start_date, end_date):
    """ calcul number of primary reads qc-ed during the period : incl. status done + qc_pending_verif
    --- d e p r e c i a t e d """
    try:
        df_computed_reads['filter'] = ((df_computed_reads['eval_qc_status'].str[:4].str.lower()=='done') | \
                                       (df_computed_reads['eval_qc_status'].str.lower()=='qc_pending_verif')) & \
                                      (df_computed_reads['eval_qc_enddate']>=start_date) &\
                                      (df_computed_reads['eval_qc_enddate']<= end_date) &\
                                      (df_computed_reads['eval_ir_type'].str.lower() != 'adj')

        df_computed_reads['reads_primary_qced'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_primary_qced']))
        df_metrics_res['reads_primary_qced'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_primary_qced']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads primary qc-ed during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_adj_qced(df_computed_reads, df_metrics_res, start_date, end_date):
    """ calcul number of adj qc-ed during the period : incl. status done + qc_pending_verif
    --- d e p r e c i a t e d """
    try:
        df_computed_reads['filter'] = ((df_computed_reads['eval_qc_status'].str[:4].str.lower()=='done') |
                                       (df_computed_reads['eval_qc_status'].str.lower()=='qc_pending_verif')) &\
                                      (df_computed_reads['eval_qc_enddate']>=start_date) &\
                                      (df_computed_reads['eval_qc_enddate']<= end_date) &\
                                      (df_computed_reads['eval_ir_type'].str.lower() == 'adj')

        df_computed_reads['reads_adj_qced'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_adj_qced']))
        df_metrics_res['reads_adj_qced'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_adj_qced']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of adj qc-ed during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_submitted_notread(df_computed_reads, df_metrics_res):
    """ calcul number of reads submitted not read during the period"""
    try:
        df_computed_reads['filter'] = df_computed_reads['eval_qc_status'].str[:4].str.lower()=='subm'
        df_computed_reads['submitted_notread'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['submitted_notread']))
        df_metrics_res['submitted_notread'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['submitted_notread']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads submitted not read during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_submitted_primary_notread(df_computed_reads, df_metrics_res):
    """ calcul number of primary reads submitted not read during the period"""
    try:
        df_computed_reads['filter'] = (df_computed_reads['eval_qc_status'].str[:4].str.lower()=='subm') &\
                                      (df_computed_reads['eval_ir_type'].str.lower() != 'adj')
        df_computed_reads['submitted_prim_notread'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['submitted_prim_notread']))
        df_metrics_res['submitted_prim_notread'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['submitted_prim_notread']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of primary reads submitted not read during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_submitted_adj_notread(df_computed_reads, df_metrics_res):
    """ calcul number of adjudications submitted not read during the period"""
    try:
        df_computed_reads['filter'] = (df_computed_reads['eval_qc_status'].str[:4].str.lower()=='subm') &\
                                      (df_computed_reads['eval_ir_type'].str.lower() == 'adj')
        df_computed_reads['submitted_adj_notread'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['submitted_adj_notread']))
        df_metrics_res['submitted_adj_notread'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['submitted_adj_notread']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of adjudications submitted not read during the period failed: %s', error_read)
        return False
    return True

def calcul_reads_submitted_pendingqc(df_computed_reads, df_metrics_res):
    """ calcul number of reads submitted and with a qc pending or qc pending gr status during the period"""
    try:
        df_computed_reads['filter'] = (df_computed_reads['eval_qc_status'].str.lower()=='qc_pending') | \
                                       (df_computed_reads['eval_qc_status'].str.lower()=='qc_pending_gr')
        df_computed_reads['reads_qc_pending'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_qc_pending']))
        df_metrics_res['reads_qc_pending'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_qc_pending']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads submitted and with a qc pending during the period failed: %s', error_read)
        return False
    return True

def calcul_reads_submitted_pendingqc_autoqc_ok(df_computed_reads, df_metrics_res):
    """ calcul number of reads submitted and with a qc pending and with eval auto qc = yes """
    try:
        # initialization because of multiple issues on eval auto qc
        df_computed_reads['reads_qc_pending_autoqcok'] = None
        df_computed_reads['filter'] = ((df_computed_reads['eval_qc_status'].str.lower()=='qc_pending') | \
                                       (df_computed_reads['eval_qc_status'].str.lower()=='qc_pending_gr')) & \
                                        (df_computed_reads['evalautoqc'].str.lower()=='yes')
        df_computed_reads['reads_qc_pending_autoqcok'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_qc_pending_autoqcok']))
        df_metrics_res['reads_qc_pending_autoqcok'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_qc_pending_autoqcok']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads submitted and with a qc pending and autoqc eval is ok during the period: %s', error_read)
        return False
    return True


def calcul_reads_submitted_primary_pendingqc(df_computed_reads, df_metrics_res):
    """ calcul number of primary reads submitted """
    try:
        df_computed_reads['filter'] = ((df_computed_reads['eval_qc_status'].str.lower()=='qc_pending') | \
                                       (df_computed_reads['eval_qc_status'].str.lower()=='qc_pending_gr')) & \
                                      (df_computed_reads['eval_ir_type'].str.lower() != 'adj')
        df_computed_reads['reads_primary_qc_pending'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_primary_qc_pending']))
        df_metrics_res['reads_primary_qc_pending'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_primary_qc_pending']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of primary reads submitted and with a qc pending : %s', error_read)
        return False
    return True

def calcul_reads_submitted_adj_pendingqc(df_computed_reads, df_metrics_res):
    """ calcul number of adjudications submitted and with a qc pending and with eval auto qc = yes """
    try:
        df_computed_reads['filter'] = ((df_computed_reads['eval_qc_status'].str.lower()=='qc_pending') | \
                                       (df_computed_reads['eval_qc_status'].str.lower()=='qc_pending_gr')) & \
                                      (df_computed_reads['eval_ir_type'].str.lower() == 'adj')
        df_computed_reads['reads_adj_qc_pending'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_adj_qc_pending']))
        df_metrics_res['reads_adj_qc_pending'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_adj_qc_pending']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of adjudications submitted and with a qc pending : %s', error_read)
        return False
    return True

def calcul_reads_submitted_query(df_computed_reads, df_metrics_res):
    """ calcul number of reads submitted and with a query open during the period"""
    try:
        df_computed_reads['filter'] = df_computed_reads['eval_qc_status'].str.lower()=='query'
        df_computed_reads['reads_query'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_query']))
        df_metrics_res['reads_query'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_query']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads submitted and with a query openduring the period failed: %s', error_read)
        return False
    return True


def calcul_reads_submitted_between_7_10(df_computed_reads, df_metrics_res):
    """ calcul number of reads submitted since 7-10wd during the period"""
    try:
        seven_business_days_ago = np.busday_offset(dt.date.today(), -7, roll='backward')
        ten_business_days_ago = np.busday_offset(dt.date.today(), -10, roll='backward')
        df_computed_reads['filter'] = (df_computed_reads['eval_qc_status'].str[:4].str.lower()=='subm') & \
                                        (df_computed_reads['eval_submission_date']<seven_business_days_ago) &\
                                        (df_computed_reads['eval_submission_date']>= ten_business_days_ago)
        df_computed_reads['reads_submitted_between_7_10'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_submitted_between_7_10']))
        df_metrics_res['reads_submitted_between_7_10'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_submitted_between_7_10']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads submitted since 7-10w dduring the period failed: %s', error_read)
        return False
    return True


def calcul_reads_submitted_more_10(df_computed_reads, df_metrics_res):
    """ calcul number of reads submitted since more than 10wdg during the period"""
    try:
        ten_business_days_ago = np.busday_offset(dt.date.today(), -10, roll='backward')
        df_computed_reads['filter'] = (df_computed_reads['eval_qc_status'].str[:4].str.lower()=='subm') & \
                                        (df_computed_reads['eval_submission_date']<ten_business_days_ago)
        df_computed_reads['reads_submitted_more_10'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_submitted_more_10']))
        df_metrics_res['reads_submitted_more_10'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_submitted_more_10']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads submitted since more than 10wd during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_notsubmitted(df_computed_reads, df_metrics_res):
    """ calcul number of reads not submitted during the period"""
    try:
        df_computed_reads['filter'] = df_computed_reads['eval_qc_status'].str[:8].str.lower()=='not subm'
        df_computed_reads['reads_not_submitted'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_not_submitted']))
        df_metrics_res['reads_not_submitted'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_not_submitted']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads not submitted during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_primary_notsubmitted(df_computed_reads, df_metrics_res):
    """ calcul number of reads not submitted during the period"""
    try:
        df_computed_reads['filter'] = (df_computed_reads['eval_qc_status'].str[:8].str.lower()=='not subm') & \
                                      (df_computed_reads['eval_ir_type'].str.lower() != 'adj')
        df_computed_reads['reads_primary_not_submitted'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_primary_not_submitted']))
        df_metrics_res['reads_primary_not_submitted'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_primary_not_submitted']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of primary reads not submitted during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_adj_notsubmitted(df_computed_reads, df_metrics_res):
    """ calcul number of reads not submitted during the period"""
    try:
        df_computed_reads['filter'] = (df_computed_reads['eval_qc_status'].str[:8].str.lower()=='not subm') & \
                                      (df_computed_reads['eval_ir_type'].str.lower() == 'adj')
        df_computed_reads['reads_adj_not_submitted'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_adj_not_submitted']))
        df_metrics_res['reads_adj_not_submitted'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_adj_not_submitted']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of adjudications not submitted during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_pendingqcverif(df_computed_reads, df_metrics_res):
    """ calcul number of reads pending qc verification during the period"""
    try:
        df_computed_reads['filter'] = df_computed_reads['eval_qc_status'].str.lower()=='qc_pending_verif'
        df_computed_reads['reads_qc_pending_verif'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_qc_pending_verif']))
        df_metrics_res['reads_qc_pending_verif'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_qc_pending_verif']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads pending qc verification during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_auto_qced(df_computed_reads, df_metrics_res, start_date, end_date):
    """ calcul number of reads auto-qced during the period"""
    try:
        df_computed_reads['filter'] = (df_computed_reads['eval_qc_status'].str.lower()=='done_auto') &\
                                      (df_computed_reads['eval_qc_enddate']>=start_date) &\
                                      (df_computed_reads['eval_qc_enddate']<=end_date)

        df_computed_reads['reads_autoqced'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_autoqced']))
        df_metrics_res['reads_autoqced'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_autoqced']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads auto-qced during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_auto_qced_screening(df_computed_reads, df_metrics_res):
    """ calcul number of reads autoqced whereas tp is a screening during the period"""
    try:
        df_computed_reads['filter'] = (df_computed_reads['eval_qc_status'].str.lower()=='done_auto') &\
                                      (df_computed_reads['timepoint_name'].str.lower()=='screening')

        df_computed_reads['reads_autoqced_screening'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_autoqced_screening']))
        df_metrics_res['reads_autoqced_screening'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_autoqced_screening']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads autoqced whereas tp is a screening during the period failed: %s', error_read)
        return False
    return True


def calcul_reads_pending_querycheck(df_computed_reads, df_metrics_res):
    """ calcul number of reads pending to a query rework verification during the period"""
    try:
        df_computed_reads['filter'] = df_computed_reads['eval_qc_status'].str.lower()=='qc_pending_query'

        df_computed_reads['reads_pending_querycheck'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_pending_querycheck']))
        df_metrics_res['reads_pending_querycheck'] = df_metrics_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_pending_querycheck']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_number of reads pending to a query rework verification during the period failed: %s', error_read)
        return False
    return True

def calculate_total_of_line_percentage(df_metrics_res, column_name, real_column_name, forecast_column_name, line, ratio_month):
    """ for columns with %, calculate the total. Specify ratio_month = True to consider where we are in the month """
    try:
        # check columns values are numericals
        if df_metrics_res[real_column_name].dtype.kind in 'biufc' and df_metrics_res[forecast_column_name].dtype.kind in 'biufc':
            if df_metrics_res.loc[line, forecast_column_name] != 0:
                df_metrics_res.loc[line, column_name] = df_metrics_res.loc[line, real_column_name] / df_metrics_res.loc[line, forecast_column_name]

                if ratio_month is True:
                    df_metrics_res.loc[line, column_name] = df_metrics_res.loc[line, column_name] / ratio_jour_mois()

    except (KeyError, ValueError, ZeroDivisionError) as error_type:
        medlog.logger.warning('Failed to calulate total percent for column %s - %s', column_name, error_type)
        return False
    return True

def calcul_images_qc_wig(df_computed_images, df_metrics_wig_res, start_wig_image_date, end_wig_image_date):
    """ calcul of the wig for images qc (within 3wd) """
    try:
        df_metrics_wig_res['imqc_start_date'] = start_wig_image_date
        df_metrics_wig_res['imqc_end_date'] = end_wig_image_date
        df_computed_images['filter'] = ((df_computed_images['img_patientstatus'].str[:4].str.lower()=='rand') | \
                                        (df_computed_images['img_patientstatus'].str[:4].str.lower()=='with')) & \
                                       ((df_computed_images['img_qc_status'].str[:4].str.lower()!='not req') | \
                                        (df_computed_images['img_qc_status'].str[:4].str.lower()!='miss')) &\
                                       (df_computed_images['timepoint_name'].str.lower()!='screening') &\
                                       (df_computed_images['img_first_receiveddate']>=start_wig_image_date) &\
                                       (df_computed_images['img_first_receiveddate']<end_wig_image_date)
        df_computed_images['imqc_received_during_period'] = df_computed_images.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['imqc_received_during_period']))
        df_metrics_wig_res['imqc_received_during_period'] = df_metrics_wig_res['project_code'].map(calcul_dict)
        del df_computed_images['filter'], df_computed_images['imqc_received_during_period']

        df_computed_images['filter2'] = ((df_computed_images['img_patientstatus'].str[:4].str.lower()=='rand') | \
                                        (df_computed_images['img_patientstatus'].str[:4].str.lower()=='with')) & \
                                       ((df_computed_images['img_qc_status'].str[:4].str.lower()=='done') | \
                                        (df_computed_images['img_qc_status'].str[:4].str.lower()!='quer')) &\
                                       (df_computed_images['timepoint_name'].str.lower()!='screening') &\
                                       (df_computed_images['img_first_receiveddate']>=start_wig_image_date) &\
                                       (df_computed_images['img_first_receiveddate']<end_wig_image_date) &\
                                       (df_computed_images['time_to_qc']<=3)
        df_computed_images['imqc_done_within_3wd_during_period'] = df_computed_images.groupby('project_code')['filter2'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_images['project_code'], df_computed_images['imqc_done_within_3wd_during_period']))
        df_metrics_wig_res['imqc_done_within_3wd_during_period'] = df_metrics_wig_res['project_code'].map(calcul_dict)
        df_metrics_wig_res['%_imqc_done_within_3wd_during_period']= (df_metrics_wig_res['imqc_done_within_3wd_during_period']/\
                                                                     df_metrics_wig_res['imqc_received_during_period']).round(2)

        del df_computed_images['filter2'], df_computed_images['imqc_done_within_3wd_during_period']

    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul wig on images qc within 3wd failed: %s', error_read)
        return False
    return True


def calcul_reads_qc_wig(df_computed_reads, df_metrics_wig_res, start_wig_reads_date, end_wig_reads_date):
    """ calcul of the wig for reads (within 10wd) """
    try:
        df_metrics_wig_res['reads_start_date'] = start_wig_reads_date
        df_metrics_wig_res['reads_end_date'] = end_wig_reads_date

        df_computed_reads['filter'] = (df_computed_reads['eval_submission_date']>=start_wig_reads_date) &\
                                    (df_computed_reads['eval_submission_date']<end_wig_reads_date)
        df_computed_reads['reads_submitted_during_period'] = df_computed_reads.groupby('project_code')['filter'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_submitted_during_period']))
        df_metrics_wig_res['reads_submitted_during_period'] = df_metrics_wig_res['project_code'].map(calcul_dict)

        del df_computed_reads['filter'], df_computed_reads['reads_submitted_during_period']

        df_computed_reads['filter2'] = ((df_computed_reads['eval_qc_status'].str[:4].str.lower() == 'done') |\
                                        (df_computed_reads['eval_qc_status'].str[:4].str.lower() == 'quer') |\
                                        (df_computed_reads['eval_qc_status'].str[:4].str.lower() == 'qc_p') ) &\
                                       (df_computed_reads['eval_submission_date']>=start_wig_reads_date) &\
                                       (df_computed_reads['eval_submission_date']<end_wig_reads_date) &\
                                       (df_computed_reads['time_to_read']<=10)
        df_computed_reads['reads_done_within_10wd_during_period'] = df_computed_reads.groupby('project_code')['filter2'].transform(sum).astype(int)
        calcul_dict = dict(zip(df_computed_reads['project_code'], df_computed_reads['reads_done_within_10wd_during_period']))
        df_metrics_wig_res['reads_done_within_10wd_during_period'] = df_metrics_wig_res['project_code'].map(calcul_dict)

        df_metrics_wig_res['%_reads_done_within_10wd_during_period'] = (df_metrics_wig_res['reads_done_within_10wd_during_period']/\
                                                                        df_metrics_wig_res['reads_submitted_during_period']).round(2)
        del df_computed_reads['filter2'], df_computed_reads['reads_done_within_10wd_during_period']
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul wig on reads qc within 10wd failed: %s', error_read)
        return False
    return True

def ratio_jour_mois():
    """ return the ratio considering today/nb days this month """
    # get current date
    this_day = dt.datetime.now()

    # get current day and month
    day_current = this_day.day
    month_current = this_day.month
    year_current = this_day.year

    # get nb days this month
    nb_days_in_month = calendar.monthrange(year_current, month_current)[1]

    # Calcul of ratio
    ratio = day_current / nb_days_in_month

    return ratio

def main():
    """ main function """
    print('imetrics_stats is not dedicated to be started outside of imetrics.py')

if __name__ == '__main__':
    main()
