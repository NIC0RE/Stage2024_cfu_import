""" test module for cfu_import_all """
import cfu_import_all as cfa

def test_start_all_cfu_extraction():
    """ overall test """
    # not yet a tes :-)
    assert cfa.start_all_cfu_extraction() is True
