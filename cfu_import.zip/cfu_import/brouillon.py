""" cfu_import all module is dedicated to read the project list, copy all cfu in working folder and run the process to extract data on each one"""

import os
from pathlib import Path
import shutil
import pandas as pd
from forex_python.converter import CurrencyRates
import medlog
import cfu_import as cfu

# import cfu_import_single_error_version as cfu

def copy_file_to_path(source_file_name, dest_folder):
    """ Copy file 'source_file_name' to new folder 'dest_folder' keeping file name
    Args:
    - source_file_name (str): complete path/file name
    - dest_folder (str): dest folder
    Returns:
    - None if copy succeed
    - else error message in case of exception
    """
    try:
        dest_file_path = dest_folder / os.path.basename(source_file_name)
        # check if source file exists
        if not os.path.exists(source_file_name):
            medlog.logger.error('Le fichier source  %s n existe pas', source_file_name)
            return None, ['Source file does not exist']

        # check if dest folder exists
        if not os.path.exists(dest_folder):
            os.makedirs(dest_folder)

        # Copy file
        shutil.copy2(source_file_name, dest_file_path)
        os.chmod(dest_file_path, 0o777)

    except PermissionError:
        medlog.logger.error('PermissionError: No permission to copy file %s to %s', source_file_name, dest_folder)
        return None, ['PermissionError']
    except FileNotFoundError:
        medlog.logger.error('FileNotFoundError: Source file %s not found', source_file_name)
        return None, ['FileNotFoundError']
    except IsADirectoryError:
        medlog.logger.error('IsADirectoryError: Destination %s is a directory', dest_folder)
        return None, ['IsADirectoryError']
    except OSError as error_os:
        medlog.logger.error('OSError: Unexpected error while copying file %s to folder %s: %s', source_file_name, dest_folder, error_os)
        return None, [f'OSError: {error_os}']
    return dest_file_path


def read_cfu_index_to_df(cfu_index_path):
    """ read the index to get list of projects and cfu files to process """
    df_cfu_index = None
    medlog.logger.info('Start reading cfu index from file')
    try:
        # no need to deal with NA values with this file
        df_cfu_index = pd.read_excel (cfu_index_path, sheet_name='0 - Settings & Macro',
                                    usecols=['Available ? ', 'Project code', 'Folder', 'FileName', 'Currency'], skiprows=5, header=0)
        df_cfu_index.columns = df_cfu_index.columns.str.lower()
        df_cfu_index.rename(columns={'project code':'project_code', 'available ? ': 'status'}, inplace=True)
        df_cfu_index = df_cfu_index[df_cfu_index['status'] == 'Ok']

    except pd.errors.EmptyDataError:
        medlog.logger.error('EmptyDataError: The file %s is empty', cfu_index_path)
    except pd.errors.ParserError:
        medlog.logger.error('ParserError: Error parsing the file %s', cfu_index_path)
    except FileNotFoundError:
        medlog.logger.error('FileNotFoundError: CFU index file %s not found', cfu_index_path)
    except ValueError as error_value:
        medlog.logger.error('ValueError: %s', error_value)
    except PermissionError:
        medlog.logger.error('PermissionError: No permission to read CFU index file %s', cfu_index_path)
    except AttributeError:
        medlog.logger.error('AttributeError: Attribute error in file %s', cfu_index_path)
    except KeyError:
        medlog.logger.error('KeyError: Key error in file %s', cfu_index_path)
    except IndexError:
        medlog.logger.error('IndexError: Index error in file %s', cfu_index_path)
    except TypeError:
        medlog.logger.error('TypeError: Type error in file %s', cfu_index_path)
    except OSError as error_os:
        medlog.logger.error('OSError: Unexpected error while reading CFU index file %s: %s', cfu_index_path, error_os)
    return df_cfu_index


def copy_cfu_from_index_to_working_folder(df_cfu_index, working_folder):
    """ Copy CFU files from index to working folder and update the DataFrame
    Args:
    - df_cfu_index (pd.DataFrame): DataFrame containing CFU index information
    - working_folder (Path): Path to the working folder
    Returns:
    - df_cfu_index (pd.DataFrame): Updated DataFrame with file paths
    """
    try:
        df_cfu_index['file_found'] = 'no'
        df_cfu_index['file_path'] = None
        df_cfu_index['file_loaded'] = 'no'
        df_cfu_index['load_error'] = None
        df_cfu_index['error_desc'] = None
        df_cfu_index['version_sheet_loaded'] = 'yes'
        df_cfu_index['last_month_validated'] = 'yes'

        for idx, row in df_cfu_index.iterrows():
            source_file = Path(row['folder']) / row['filename']
            try:
                dest_file = copy_file_to_path(source_file, working_folder)
                if dest_file:
                    df_cfu_index.at[idx, 'file_found'] = 'yes'
                    df_cfu_index.at[idx, 'file_path'] = dest_file
                else:
                    df_cfu_index.at[idx, 'status'] = 'failed copy'
                    df_cfu_index.at[idx, 'load_error'] = 'CopyError'
                    df_cfu_index.at[idx, 'error_desc'] = 'Failed to copy file'
            except PermissionError:
                medlog.logger.error('PermissionError: No permission to copy file %s to working folder', source_file)
                df_cfu_index.at[idx, 'status'] = 'restricted access - not Ok'
                df_cfu_index.at[idx, 'load_error'] = 'PermissionError'
                df_cfu_index.at[idx, 'error_desc'] = 'Permission to open the file was denied \n or file is already open'
            except FileNotFoundError:
                medlog.logger.error('FileNotFoundError: Source file %s not found', source_file)
                df_cfu_index.at[idx, 'status'] = 'not found - not Ok'
                df_cfu_index.at[idx, 'load_error'] = 'FileNotFoundError'
                df_cfu_index.at[idx, 'error_desc'] = 'File was not found \n check file path'
            except IsADirectoryError:
                medlog.logger.error('IsADirectoryError: Destination %s is a directory', working_folder)
                df_cfu_index.at[idx, 'status'] = 'failed copy - not Ok'
                df_cfu_index.at[idx, 'load_error'] = 'IsADirectoryError'
                df_cfu_index.at[idx, 'error_desc'] = 'File is in fact a directory'
            except OSError as error_os:
                medlog.logger.error('OSError: Unexpected error while copying file %s to folder %s: %s', source_file, working_folder, error_os)
                df_cfu_index.at[idx, 'status'] = 'failed copy - not Ok'
                df_cfu_index.at[idx, 'load_error'] = 'OSError'
                df_cfu_index.at[idx, 'error_desc'] = 'Unexpected OS specific error'

    except Exception as e:
        medlog.logger.error('Error during copying CFU files from index to working folder: %s', e)
        return None

    return df_cfu_index


# def extract_all_cfu_data_for_bi(df_cfu_index):
#     """ Loop through the DataFrame and extract data from each CFU file
#     Args:
#     - df_cfu_index (pd.DataFrame): DataFrame containing CFU index information
#     Returns:
#     - df_extract_for_bi (pd.DataFrame): Concatenated DataFrame with all extracted data
#     """
#     all_data = []
#     try:
#         for idx, row in df_cfu_index.iterrows():
#             medlog.logger.info('Processing row %d: %s', idx, row.to_dict())
#             errors = []
#             errors_messages = []
#             if row['file_found'] == 'yes':
#                 try:
#                     result = cfu.extract_cfu_data_for_bi(row['file_path'], export_csv=False)
#                     if result:
#                         final_merged_df, _ = result
#                         all_data.append(final_merged_df)
#                         df_cfu_index.at[idx, 'file_loaded'] = 'yes'
#                     else:
#                         df_cfu_index.at[idx, 'file_loaded'] = 'no'
#                         errors.append('UnknownError')
#                         # df_cfu_index.at[idx, 'load_error'] = 'UnknownError'
#                 except cfu.ProductCategoryNotFoundError as e:
#                     medlog.logger.error('ProductCategoryNotFoundError: %s', e)
#                     errors.append('ProductCategoryNotFoundError')
#                     errors_messages.append('Product category column was not found in the file / Maybe it exist but was named differently')
#                     # df_cfu_index.at[idx, 'load_error'] = 'ProductCategoryNotFoundError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'Product category column was not found in the file / Maybe it exist but was named differently'
#                 except cfu.DateNotFoundError as e:
#                     medlog.logger.error('DateNotFoundError: %s', e)
#                     errors.append('DateNotFoundError')
#                     errors_messages.append('Dates columns were not found in the file / Maybe they exists but were placed on the wrong row')
#                     # df_cfu_index.at[idx, 'load_error'] = 'DateNotFoundError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'Dates columns were not found in the file / Maybe they exists but were placed on the wrong row'
#                 except cfu.ActivityForecastNotFoundError as e:
#                     errors.append('ActivityForecastNotFoundError')
#                     errors_messages.append('ActivityForecast column was not found in the file / Maybe it exist but was named differently')
#                     medlog.logger.error('ActivityForecastNotFoundError: %s', e)
#                     # df_cfu_index.at[idx, 'load_error'] = 'ActivityForecastNotFoundError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'ActivityForecast column was not found in the file / Maybe it exist but was named differently'
#                 except cfu.FinaldfEmptyError as e:
#                     medlog.logger.error('FinaldfEmptyError: %s', e)
#                     errors.append('FinaldfEmptyError')
#                     errors_messages.append('The final (merged) dataframe is empty / or the fusion process failed')
#                     # df_cfu_index.at[idx, 'load_error'] = 'FinaldfEmptyError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'The final (merged) dataframe is empty / or the fusion process failed'
                    
#                 except pd.errors.EmptyDataError:
#                     medlog.logger.error('EmptyDataError: The file %s is empty', row['file_path'])
#                     errors.append('EmptyDataError')
#                     errors_messages.append('File seems to be empty')
#                     # df_cfu_index.at[idx, 'load_error'] = 'EmptyDataError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'File seems to be empty'
#                 except pd.errors.ParserError:
#                     medlog.logger.error('ParserError: Error parsing the file %s', row['file_path'])
#                     errors.append('ParserError')
#                     errors_messages.append('An error occured while parsing the File')
#                     # df_cfu_index.at[idx, 'load_error'] = 'ParserError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'An error occured while parsing the File'
#                 except FileNotFoundError:
#                     medlog.logger.error('FileNotFoundError: CFU file %s not found', row['file_path'])
#                     errors.append('FileNotFoundError')
#                     errors_messages.append('File was not found')
#                     # df_cfu_index.at[idx, 'load_error'] = 'FileNotFoundError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'File was not found'
#                 except ValueError as error_value:
#                     medlog.logger.error('ValueError: %s', error_value)
#                     errors.append(f'ValueError: {error_value}')
#                     errors_messages.append('File contains a problematic value / or a value was not recognized')
#                     # df_cfu_index.at[idx, 'load_error'] = 'ValueError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'File contains a problematic value / or a value was not recognized'
#                 except PermissionError:
#                     medlog.logger.error('PermissionError: No permission to read CFU file %s', row['file_path'])
#                     errors.append('PermissionError')
#                     errors_messages.append('Permission to open the file was denied / or file is already open')
#                     # df_cfu_index.at[idx, 'load_error'] = 'PermissionError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'Permission to open the file was denied / or file is already open'
#                 except AttributeError:
#                     medlog.logger.error('AttributeError: Attribute error in file %s', row['file_path'])
#                     errors.append('AttributeError')
#                     errors_messages.append('Wrong attribute was used')
#                     # df_cfu_index.at[idx, 'load_error'] = 'AttributeError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'Wrong attribute was used'
#                 except KeyError:
#                     medlog.logger.error('KeyError: Key error in file %s', row['file_path'])
#                     errors.append('KeyError')
#                     errors_messages.append('There was a problem involving keys : check again')
#                     # df_cfu_index.at[idx, 'load_error'] = 'KeyError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'There was a problem involving keys : check again'
#                 except IndexError:
#                     medlog.logger.error('IndexError: Index error in file %s', row['file_path'])
#                     errors.append('IndexError')
#                     errors_messages.append('There was a problem involving an index : check again')
#                     # df_cfu_index.at[idx, 'load_error'] = 'IndexError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'There was a problem involving an index : check again'
#                 except TypeError:
#                     medlog.logger.error('TypeError: Type error in file %s', row['file_path'])
#                     errors.append('TypeError')
#                     errors_messages.append('There was a problem involving an object or variable type : check again')
#                     # df_cfu_index.at[idx, 'load_error'] = 'TypeError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'There was a problem involving an object or variable type : check again'
#                 except OSError as error_os:
#                     medlog.logger.error('OSError: Unexpected error while reading CFU file %s: %s', row['file_path'], error_os)
#                     errors.append(f'OSError: {error_os}')
#                     errors_messages.append('Unexpected OS specific error')
#                     # df_cfu_index.at[idx, 'load_error'] = 'OSError'
#                     # df_cfu_index.at[idx, 'error_desc'] = 'Unexpected OS specific error'
#                 except Exception as e:
#                     medlog.logger.error('Unknown error during data extraction from CFU file %s: %s', row['file_path'], e)
#                     errors.append(str(e))
#                     # df_cfu_index.at[idx, 'load_error'] = str(e)
                    

#                 if errors:
#                     df_cfu_index.at[idx, 'file_loaded'] = 'no'
#                     df_cfu_index.at[idx, 'load_error'] = '; '.join(errors)
#                     df_cfu_index.at[idx, 'error_desc'] = '; '.join(errors_messages)
                    
#         if all_data:
#             df_extract_for_bi = pd.concat(all_data, ignore_index=True)
#             return df_extract_for_bi
#         else:
#             medlog.logger.error('No data extracted from CFU files')
#             return None

#     except Exception as e:
#         medlog.logger.error('Error during data extraction from CFU files: %s', e)
#         df_cfu_index.at[idx, 'load_error'] = str(e)
#         return None


def calculate_statistics(cfu_diagnostic_data):
    """Calculates statistics from the CFU diagnostic data."""
    nb_project = cfu_diagnostic_data.shape[0]
    nb_project_found = cfu_diagnostic_data[cfu_diagnostic_data['file_found'] == "yes"].shape[0]
    pct_project_found = (nb_project_found / nb_project) * 100 if nb_project > 0 else 0
    nb_project_loaded = cfu_diagnostic_data[cfu_diagnostic_data['file_loaded'] == "yes"].shape[0]
    pct_project_loaded = (nb_project_loaded / nb_project) * 100 if nb_project > 0 else 0
    nb_version_loaded = cfu_diagnostic_data[cfu_diagnostic_data['version_sheet_loaded'] == "yes"].shape[0]
    pct_version_loaded = (nb_version_loaded / nb_project) * 100 if nb_project > 0 else 0

    # Compter les erreurs spécifiques pour les colonnes manquantes
    nb_product_category_missing = cfu_diagnostic_data[cfu_diagnostic_data['load_error'].str.contains('Product category column not found', na=False)].shape[0]
    pct_project_with_product_category_missing = (nb_product_category_missing / nb_project) * 100 if nb_project > 0 else 0
    nb_activityforecast_missing = cfu_diagnostic_data[cfu_diagnostic_data['load_error'].str.contains('ActivityForecast not found', na=False)].shape[0]
    pct_project_with_activityforecast_missing = (nb_activityforecast_missing / nb_project) * 100 if nb_project > 0 else 0

    # Compter les erreurs inconnues
    nb_unknown_error = cfu_diagnostic_data[cfu_diagnostic_data['load_error'].str.contains('Unknown error', na=False)].shape[0]
    pct_project_with_unknown_error = (nb_unknown_error / nb_project) * 100 if nb_project > 0 else 0

    if cfu_diagnostic_data['load_error'].notna().any():
        common_error = cfu_diagnostic_data['load_error'].value_counts().idxmax()
    else:
        common_error = "None"

    # Créer un DataFrame avec les statistiques
    statistics_df = pd.DataFrame({
        'Nb project': [nb_project],
        'Nb project found': [nb_project_found],
        '% project found': [pct_project_found],
        'Nb project loaded': [nb_project_loaded],
        '% project loaded': [pct_project_loaded],
        'Nb version sheet loaded': [nb_version_loaded],
        '% version sheet loaded': [pct_version_loaded],
        'Nb product category missing': [nb_product_category_missing],
        '% project with product category missing': [pct_project_with_product_category_missing],
        'Nb activityforecast missing': [nb_activityforecast_missing],
        '% project with activityforecast missing': [pct_project_with_activityforecast_missing],
        'Nb unknown error': [nb_unknown_error],
        '% project with unknown error': [pct_project_with_unknown_error],
        'Most common error': [common_error]
    })

    return statistics_df

def convert_currency(amount, from_currency, to_currency):
    """
    Converts the given amount from one currency to another.

    Args:
        amount (float): The amount to be converted.
        from_currency (str): The current currency of the amount.
        to_currency (str): The target currency for conversion.

    Returns:
        float: The converted amount.
    """
    c = CurrencyRates()
    return c.convert(from_currency, to_currency, amount)

def calculate_statistics_from_bi(df_extract_for_bi):
    """
    Calculates the monthly statistics from the extracted data.

    Args:
        df_extract_for_bi (pd.DataFrame): DataFrame containing the extracted data.

    Returns:
        pd.DataFrame: DataFrame containing the monthly statistics.
    """
    # Convertir les dates en mois pour groupement
    df_extract_for_bi['Month'] = pd.to_datetime(df_extract_for_bi['Month_Validated']).dt.to_period('M')

    # Initialisation du dataframe pour les statistiques
    stats_data = []

    # Calcul des totaux mensuels
    for month in df_extract_for_bi['Month'].unique():
        df_month = df_extract_for_bi[df_extract_for_bi['Month'] == month]

        # Total des quantités pour le mois
        total_quantity = df_month['Quantity'].sum()
        
        # Total des activités prévues pour le mois
        total_activity_forecast = df_month[df_month['ActivityForecast'] == 'yes']['Quantity'].sum()

        # Total des revenus pour le mois en différentes devises
        total_revenue_euro = df_month['Revenue_Euro'].sum()
        total_revenue_dollar = df_month['Revenue_Dollar'].sum()
        total_revenue_yuan = df_month['Revenue_Yuan'].sum()

        # Conversion des montants en euros
        total_revenue_euro_converted = total_revenue_euro + convert_currency(total_revenue_dollar, 'USD', 'EUR') + convert_currency(total_revenue_yuan, 'CNY', 'EUR')
        
        # Conversion des montants en dollars
        total_revenue_dollar_converted = convert_currency(total_revenue_euro, 'EUR', 'USD') + total_revenue_dollar + convert_currency(total_revenue_yuan, 'CNY', 'USD')
        
        # Conversion des montants en yuan
        total_revenue_yuan_converted = convert_currency(total_revenue_euro, 'EUR', 'CNY') + convert_currency(total_revenue_dollar, 'USD', 'CNY') + total_revenue_yuan

        # Ajout des données calculées dans la liste
        stats_data.append({
            'Month': month.strftime('%b-%y'),
            'Total_amount_quantity': total_quantity,
            'Total_activity_forecast': total_activity_forecast,
            'Total_amount_revenus_euro': total_revenue_euro_converted,
            'Total_amount_revenus_dollar': total_revenue_dollar_converted,
            'Total_amount_revenus_yuan': total_revenue_yuan_converted
        })

    # Création du dataframe des statistiques
    df_stats_content = pd.DataFrame(stats_data)
    
    return df_stats_content

def extract_all_cfu_data_for_bi(df_cfu_index):
    """ Loop through the DataFrame and extract data from each CFU file
    Args:
    - df_cfu_index (pd.DataFrame): DataFrame containing CFU index information
    Returns:
    - df_extract_for_bi (pd.DataFrame): Concatenated DataFrame with all extracted data
    """
    all_data = []
    for idx, row in df_cfu_index.iterrows():
        medlog.logger.info('Processing row %d: %s', idx, row.to_dict())
        errors = []
        errors_messages = []
        if row['file_found'] == 'yes':
            try:
                result, error_msg, error_desc, precision = cfu.extract_cfu_data_for_bi(row['file_path'], export_csv=False)
                if result:
                    final_merged_df, _ = result
                    all_data.append(final_merged_df)
                    df_cfu_index.at[idx, 'file_loaded'] = 'yes'
                else:
                    df_cfu_index.at[idx, 'file_loaded'] = 'no'
                    df_cfu_index.at[idx, 'load_error'] = error_msg
                    df_cfu_index.at[idx, 'error_desc'] = error_desc

                    #errors.append('UnknownError')
                    # Signal_file_errors = cfu.Signal_file_errors()

                    # if Signal_file_errors == 'ProductCategoryNotFound_Error':
                    #     medlog.logger.error('ProductCategoryNotFoundError found')
                    #     errors.append('ProductCategoryNotFoundError')
                    #     errors_messages.append('Product category column was not found in the file / Maybe it exists but was named differently')
                    
                    # if Signal_file_errors == 'DateNotFound_Error':
                    #     medlog.logger.error('DateNotFoundError found')
                    #     errors.append('DateNotFoundError')
                    #     errors_messages.append('Dates columns were not found in the file / Maybe they exist but were placed on the wrong row')

                    # if Signal_file_errors == 'ActivityForecastNotFound_Error':
                    #     medlog.logger.error('ActivityForecastNotFoundError found')
                    #     errors.append('ActivityForecastNotFoundError')
                    #     errors_messages.append('ActivityForecast column was not found in the file / Maybe it exists but was named differently')
                    
                    # if Signal_file_errors == 'FinaldfEmpty_Error':
                    #     medlog.logger.error('FinaldfEmptyError found')
                    #     errors.append('FinaldfEmptyError')
                    #     errors_messages.append('The final (merged) dataframe is empty / or the fusion process failed')

            except cfu.ProductCategoryNotFoundError as e:
                medlog.logger.error('ProductCategoryNotFoundError: %s', e)
                errors.append('ProductCategoryNotFoundError')
                errors_messages.append('Product category column was not found in the file / Maybe it exists but was named differently')

            except cfu.DateNotFoundError as e:
                medlog.logger.error('DateNotFoundError: %s', e)
                errors.append('DateNotFoundError')
                errors_messages.append('Dates columns were not found in the file / Maybe they exist but were placed on the wrong row')

            except cfu.ActivityForecastNotFoundError as e:
                errors.append('ActivityForecastNotFoundError')
                errors_messages.append('ActivityForecast column was not found in the file / Maybe it exists but was named differently')
                medlog.logger.error('ActivityForecastNotFoundError: %s', e)

            except cfu.FinaldfEmptyError as e:
                medlog.logger.error('FinaldfEmptyError: %s', e)
                errors.append('FinaldfEmptyError')
                errors_messages.append('The final (merged) dataframe is empty / or the fusion process failed')

            except pd.errors.EmptyDataError:
                medlog.logger.error('EmptyDataError: The file %s is empty', row['file_path'])
                errors.append('EmptyDataError')
                errors_messages.append('File seems to be empty')

            except pd.errors.ParserError:
                medlog.logger.error('ParserError: Error parsing the file %s', row['file_path'])
                errors.append('ParserError')
                errors_messages.append('An error occurred while parsing the File')

            except FileNotFoundError:
                medlog.logger.error('FileNotFoundError: CFU file %s not found', row['file_path'])
                errors.append('FileNotFoundError')
                errors_messages.append('File was not found')

            except ValueError as error_value:
                medlog.logger.error('ValueError: %s', error_value)
                errors.append(f'ValueError: {error_value}')
                errors_messages.append('File contains a problematic value / or a value was not recognized')

            except PermissionError:
                medlog.logger.error('PermissionError: No permission to read CFU file %s', row['file_path'])
                errors.append('PermissionError')
                errors_messages.append('Permission to open the file was denied / or file is already open')

            except AttributeError:
                medlog.logger.error('AttributeError: Attribute error in file %s', row['file_path'])
                errors.append('AttributeError')
                errors_messages.append('Wrong attribute was used')

            except KeyError:
                medlog.logger.error('KeyError: Key error in file %s', row['file_path'])
                errors.append('KeyError')
                errors_messages.append('There was a problem involving keys: check again')

            except IndexError:
                medlog.logger.error('IndexError: Index error in file %s', row['file_path'])
                errors.append('IndexError')
                errors_messages.append('There was a problem involving an index: check again')

            except TypeError:
                medlog.logger.error('TypeError: Type error in file %s', row['file_path'])
                errors.append('TypeError')
                errors_messages.append('There was a problem involving an object or variable type: check again')

            except OSError as error_os:
                medlog.logger.error('OSError: Unexpected error while reading CFU file %s: %s', row['file_path'], error_os)
                errors.append(f'OSError: {error_os}')
                errors_messages.append('Unexpected OS specific error')

            except Exception as e:
                medlog.logger.error('Unexpected error during data extraction from CFU file %s: %s', row['file_path'], e)
                errors.append(str(e))
                errors_messages.append('Unexpected error occurred :' + str(e))

            if precision == "no":
                df_cfu_index.at[idx, 'file_found'] = 'no'
            if precision == "Version sheet not found":
                df_cfu_index.at[idx, 'version_sheet_loaded'] = 'no'
            if precision == "Last month not validated":
                df_cfu_index.at[idx, 'last_month_validated'] = 'no'

            if df_cfu_index.at[idx, 'load_error'] is not None:
                df_cfu_index.at[idx, 'file_loaded'] = 'no'
                df_cfu_index.at[idx, 'last_month_validated'] = 'could not verify'
                df_cfu_index.at[idx, 'version_sheet_loaded'] = 'could not verify'

            if errors:
                df_cfu_index.at[idx, 'file_loaded'] = 'no'
                df_cfu_index.at[idx, 'last_month_validated'] = 'no'
                df_cfu_index.at[idx, 'version_sheet_loaded'] = 'no'
                df_cfu_index.at[idx, 'load_error'] = '; '.join(errors)
                df_cfu_index.at[idx, 'error_desc'] = '; '.join(errors_messages)

    if all_data:
        df_extract_for_bi = pd.concat(all_data, ignore_index=True)
        return df_extract_for_bi
    else:
        medlog.logger.error('No data extracted from CFU files')
        return None
    

def start_all_cfu_extraction():
    """ main part of the cfu_import_all module """
    try:
        cfu.initialize_logger_for_cfu_import(Path('./log/cfu_import_log'))
        # cfu_index_path = Path('./tests/data/cfu_index.xlsx')
        cfu_index_path = Path('./tests/data/cfu_index_test.xlsx')
        working_folder = Path('./tests/working/')
        os.makedirs(working_folder, exist_ok=True)

        index_file_name = copy_file_to_path(cfu_index_path, working_folder)
        df_cfu_index = read_cfu_index_to_df(index_file_name)

        if df_cfu_index is None:
            return False

        df_cfu_index = copy_cfu_from_index_to_working_folder(df_cfu_index, working_folder)

        df_extract_for_bi = extract_all_cfu_data_for_bi(df_cfu_index)

        if df_extract_for_bi is not None:
            output_csv_path = working_folder / 'final_extracted_data.csv'
            df_extract_for_bi.to_csv(output_csv_path, index=False, sep=';')
            medlog.logger.info(" --> All CFU data has been successfully extracted and saved to %s", output_csv_path)
        else:
            medlog.logger.error("Failed to extract data from CFU files")
            
        
        diagnostic_csv_path = working_folder / 'cfu_diagnostic_data.csv'
        df_cfu_index.to_csv(diagnostic_csv_path, index=False, sep=';')
        medlog.logger.info(" --> Diagnostic data has been saved to %s", diagnostic_csv_path)

        statistics_df = calculate_statistics(df_cfu_index)
        statistics_df['% project found'] = statistics_df['% project found'].round(2)
        statistics_df['% project loaded'] = statistics_df['% project loaded'].round(2)
        statistics_df['% project with product category missing'] = statistics_df['% project with product category missing'].round(2)
        statistics_df['% project with activityforecast missing'] = statistics_df['% project with activityforecast missing'].round(2)

        statistics_csv_path = working_folder / 'cfu_statistic_process.csv'
        statistics_df.to_csv(statistics_csv_path, index=False, sep=';')
        medlog.logger.info(" --> File statistics have been saved to %s", diagnostic_csv_path)

        statistics_from_bi_df = calculate_statistics_from_bi(df_extract_for_bi)
        statistics_content_csv_path = working_folder / 'cfu_statistic_content.csv'
        statistics_from_bi_df.to_csv(statistics_content_csv_path, index=False, sep=';')
        medlog.logger.info(" --> Statistics content has been saved to %s", diagnostic_csv_path)

        return True

    except pd.errors.EmptyDataError:
        medlog.logger.error('EmptyDataError: The CFU index file is empty')
    except pd.errors.ParserError:
        medlog.logger.error('ParserError: Error parsing the CFU index file')
    except FileNotFoundError:
        medlog.logger.error('FileNotFoundError: The CFU index file not found')
    except ValueError as error_value:
        medlog.logger.error('ValueError: %s', error_value)
    except PermissionError:
        medlog.logger.error('PermissionError: No permission to access the CFU index file')
    except AttributeError:
        medlog.logger.error('AttributeError: Attribute error in the CFU index file')
    except KeyError:
        medlog.logger.error('KeyError: Key error in the CFU index file')
    except IndexError:
        medlog.logger.error('IndexError: Index error in the CFU index file')
    except TypeError:
        medlog.logger.error('TypeError: Type error in the CFU index file')
    except OSError as error_os:
        medlog.logger.error('OSError: Unexpected error while processing the CFU index file: %s', error_os)
    return False


if __name__ == '__main__':
    # TODO: later : manage arguments (at least debug/info, path to index file, working folder, path to result)
    # argument_prog_list = sys.argv[1:] ... if len(argument_prog_list) > 0: ...
    if start_all_cfu_extraction() is True:
        medlog.logger.info('start_all_cfu_extraction completed successfully')
    else:
        medlog.logger.info('start_all_cfu_extraction was not completed')
