""" cfu_import all module is dedicated to read the project list, copy all cfu in working folder and run the process to extract data on each one"""

import os
from pathlib import Path
import shutil
import pandas as pd
from forex_python.converter import CurrencyRates
import medlog
import cfu_import as cfu
import requests

# Taux de change approximatifs
APPROXIMATE_RATES = {
    ('EUR', 'USD'): 1.09,
    ('EUR', 'CNY'): 7.90,
    ('USD', 'EUR'): 0.92,
    ('USD', 'CNY'): 7.27,
    ('CNY', 'EUR'): 0.13,
    ('CNY', 'USD'): 0.14
}

# import cfu_import_single_error_version as cfu


def copy_file_to_path(source_file_name, dest_folder):
    """ Copy file 'source_file_name' to new folder 'dest_folder' keeping file name
    Args:
    - source_file_name (str): complete path/file name
    - dest_folder (str): dest folder
    Returns:
    - None if copy succeed
    - else error message in case of exception
    """
    try:
        dest_file_path = dest_folder / os.path.basename(source_file_name)
        # check if source file exists
        if not os.path.exists(source_file_name):
            medlog.logger.error(
                'Le fichier source  %s n existe pas', source_file_name)
            return None, ['Source file does not exist']

        # check if dest folder exists
        if not os.path.exists(dest_folder):
            os.makedirs(dest_folder)

        # Copy file
        shutil.copy2(source_file_name, dest_file_path)
        os.chmod(dest_file_path, 0o777)

    except PermissionError:
        medlog.logger.error(
            'PermissionError: No permission to copy file %s to %s', source_file_name, dest_folder)
        return None, ['PermissionError']
    except FileNotFoundError:
        medlog.logger.error(
            'FileNotFoundError: Source file %s not found', source_file_name)
        return None, ['FileNotFoundError']
    except IsADirectoryError:
        medlog.logger.error(
            'IsADirectoryError: Destination %s is a directory', dest_folder)
        return None, ['IsADirectoryError']
    except OSError as error_os:
        medlog.logger.error('OSError: Unexpected error while copying file %s to folder %s: %s',
                            source_file_name, dest_folder, error_os)
        return None, [f'OSError: {error_os}']
    return dest_file_path


def read_cfu_index_to_df(cfu_index_path):
    """ read the index to get list of projects and cfu files to process """
    df_cfu_index = None
    medlog.logger.info('Start reading cfu index from file')
    try:
        # no need to deal with NA values with this file
        df_cfu_index = pd.read_excel(cfu_index_path, sheet_name='0 - Settings & Macro',
                                     usecols=['Available ? ', 'Project code', 'Folder', 'FileName', 'Currency'], skiprows=5, header=0)
        df_cfu_index.columns = df_cfu_index.columns.str.lower()
        df_cfu_index.rename(
            columns={'project code': 'project_code', 'available ? ': 'status'}, inplace=True)
        df_cfu_index = df_cfu_index[df_cfu_index['status'] == 'Ok']

    except pd.errors.EmptyDataError:
        medlog.logger.error(
            'EmptyDataError: The file %s is empty', cfu_index_path)
    except pd.errors.ParserError:
        medlog.logger.error(
            'ParserError: Error parsing the file %s', cfu_index_path)
    except FileNotFoundError:
        medlog.logger.error(
            'FileNotFoundError: CFU index file %s not found', cfu_index_path)
    except ValueError as error_value:
        medlog.logger.error('ValueError: %s', error_value)
    except PermissionError:
        medlog.logger.error(
            'PermissionError: No permission to read CFU index file %s', cfu_index_path)
    except AttributeError:
        medlog.logger.error(
            'AttributeError: Attribute error in file %s', cfu_index_path)
    except KeyError:
        medlog.logger.error('KeyError: Key error in file %s', cfu_index_path)
    except IndexError:
        medlog.logger.error(
            'IndexError: Index error in file %s', cfu_index_path)
    except TypeError:
        medlog.logger.error('TypeError: Type error in file %s', cfu_index_path)
    except OSError as error_os:
        medlog.logger.error(
            'OSError: Unexpected error while reading CFU index file %s: %s', cfu_index_path, error_os)
    return df_cfu_index


def copy_cfu_from_index_to_working_folder(df_cfu_index, working_folder):
    """ Copy CFU files from index to working folder and update the DataFrame
    Args:
    - df_cfu_index (pd.DataFrame): DataFrame containing CFU index information
    - working_folder (Path): Path to the working folder
    Returns:
    - df_cfu_index (pd.DataFrame): Updated DataFrame with file paths
    """
    try:
        df_cfu_index['file_found'] = 'no'
        df_cfu_index['file_path'] = None
        df_cfu_index['file_loaded'] = 'no'
        df_cfu_index['load_error'] = None
        df_cfu_index['error_desc'] = None
        df_cfu_index['version_sheet_loaded'] = 'yes'
        df_cfu_index['last_month_validated'] = 'yes'

        for idx, row in df_cfu_index.iterrows():
            source_file = Path(row['folder']) / row['filename']
            try:
                dest_file = copy_file_to_path(source_file, working_folder)
                if dest_file:
                    df_cfu_index.at[idx, 'file_found'] = 'yes'
                    df_cfu_index.at[idx, 'file_path'] = dest_file
                else:
                    df_cfu_index.at[idx, 'status'] = 'failed copy'
                    df_cfu_index.at[idx, 'load_error'] = 'CopyError'
                    df_cfu_index.at[idx, 'error_desc'] = 'Failed to copy file'
            except PermissionError:
                medlog.logger.error(
                    'PermissionError: No permission to copy file %s to working folder', source_file)
                df_cfu_index.at[idx, 'status'] = 'restricted access - not Ok'
                df_cfu_index.at[idx, 'load_error'] = 'PermissionError'
                df_cfu_index.at[idx, 'error_desc'] = 'Permission to open the file was denied \n or file is already open'
            except FileNotFoundError:
                medlog.logger.error(
                    'FileNotFoundError: Source file %s not found', source_file)
                df_cfu_index.at[idx, 'status'] = 'not found - not Ok'
                df_cfu_index.at[idx, 'load_error'] = 'FileNotFoundError'
                df_cfu_index.at[idx,
                                'error_desc'] = 'File was not found \n check file path'
            except IsADirectoryError:
                medlog.logger.error(
                    'IsADirectoryError: Destination %s is a directory', working_folder)
                df_cfu_index.at[idx, 'status'] = 'failed copy - not Ok'
                df_cfu_index.at[idx, 'load_error'] = 'IsADirectoryError'
                df_cfu_index.at[idx,
                                'error_desc'] = 'File is in fact a directory'
            except OSError as error_os:
                medlog.logger.error(
                    'OSError: Unexpected error while copying file %s to folder %s: %s', source_file, working_folder, error_os)
                df_cfu_index.at[idx, 'status'] = 'failed copy - not Ok'
                df_cfu_index.at[idx, 'load_error'] = 'OSError'
                df_cfu_index.at[idx,
                                'error_desc'] = 'Unexpected OS specific error'

    except Exception as e:
        medlog.logger.error(
            'Error during copying CFU files from index to working folder: %s', e)
        return None

    return df_cfu_index


def merge_currency_to_bi_data(df_extract_for_bi, df_cfu_index):
    """Merge the currency information into the BI data."""
    # Rename the project_code column to match the BI data
    df_extract_for_bi.rename(
        columns={'Project_code': 'project_code'}, inplace=True)
    df_merged = pd.merge(df_extract_for_bi, df_cfu_index[[
                         'project_code', 'currency']], on='project_code', how='left')
    return df_merged


def calculate_statistics(cfu_diagnostic_data):
    """Calculates statistics from the CFU diagnostic data."""
    nb_project = cfu_diagnostic_data.shape[0]
    nb_project_found = cfu_diagnostic_data[cfu_diagnostic_data['file_found']
                                           == "yes"].shape[0]
    pct_project_found = (nb_project_found / nb_project) * \
        100 if nb_project > 0 else 0
    nb_project_loaded = cfu_diagnostic_data[cfu_diagnostic_data['file_loaded']
                                            == "yes"].shape[0]
    pct_project_loaded = (nb_project_loaded / nb_project) * \
        100 if nb_project > 0 else 0
    nb_version_loaded = cfu_diagnostic_data[cfu_diagnostic_data['version_sheet_loaded'] == "yes"].shape[0]
    pct_version_loaded = (nb_version_loaded / nb_project) * \
        100 if nb_project > 0 else 0
    nb_month_validated = cfu_diagnostic_data[cfu_diagnostic_data['last_month_validated'] == "yes"].shape[0]
    pct_month_validated = (nb_month_validated / nb_project) * \
        100 if nb_project > 0 else 0

    # Compter les erreurs spécifiques pour les colonnes manquantes
    nb_product_category_missing = cfu_diagnostic_data[cfu_diagnostic_data['load_error'].str.contains(
        'Product category column not found', na=False)].shape[0]
    pct_project_with_product_category_missing = (
        nb_product_category_missing / nb_project) * 100 if nb_project > 0 else 0
    nb_activityforecast_missing = cfu_diagnostic_data[cfu_diagnostic_data['load_error'].str.contains(
        'ActivityForecast not found', na=False)].shape[0]
    pct_project_with_activityforecast_missing = (
        nb_activityforecast_missing / nb_project) * 100 if nb_project > 0 else 0

    # Compter les erreurs inconnues
    nb_unknown_error = cfu_diagnostic_data[cfu_diagnostic_data['load_error'].str.contains(
        'Unknown error', na=False)].shape[0]
    pct_project_with_unknown_error = (
        nb_unknown_error / nb_project) * 100 if nb_project > 0 else 0

    if cfu_diagnostic_data['load_error'].notna().any():
        nb_error = cfu_diagnostic_data['load_error'].value_counts()
        common_error = nb_error.idxmax()
        nb_type_error = cfu_diagnostic_data['load_error'].nunique()
    else:
        nb_error = 0
        common_error = "None"
        nb_type_error = 0

    # Créer un DataFrame avec les statistiques
    statistics_df = pd.DataFrame({
        'Nb project': [nb_project],
        'Nb project found': [nb_project_found],
        '% project found': [pct_project_found],
        'Nb project loaded': [nb_project_loaded],
        '% project loaded': [pct_project_loaded],
        'Nb version sheet loaded': [nb_version_loaded],
        '% version sheet loaded': [pct_version_loaded],
        'Nb last month validated': [nb_month_validated],
        '% past month validated': [pct_month_validated],
        'Nb product category missing': [nb_product_category_missing],
        '% project with product category missing': [pct_project_with_product_category_missing],
        'Nb activityforecast missing': [nb_activityforecast_missing],
        '% project with activityforecast missing': [pct_project_with_activityforecast_missing],
        'Nb unknown error': [nb_unknown_error],
        '% project with unknown error': [pct_project_with_unknown_error],
        'Nb type of error': [nb_type_error],
        'Most common error': [common_error]
    })

    return statistics_df


def check_api_access():
    try:
        response = requests.get(
            "https://theforexapi.com/api/latest?base=EUR&symbols=USD")
        if response.status_code == 200:
            return True
    except requests.exceptions.RequestException as e:
        medlog.logger.error(
            'API access check failed: could not access online link for currency converter')
        medlog.logger.warning(
            'Since online converter access failed, approximate rates will be used for currency conversion')
    return False


def convert_currency(amount, from_currency, to_currency):
    """Convert currency using an online API. Retry on failure."""
    if from_currency == to_currency:
        return amount
    try:
        response = requests.get(
            f"https://theforexapi.com/api/latest?base={from_currency}&symbols={to_currency}")
        response.raise_for_status()
        rates = response.json()['rates']
        return amount * rates[to_currency]
    except requests.exceptions.RequestException as e:
        medlog.logger.error(
            'Error converting currency from %s to %s using API: %s', from_currency, to_currency, e)
        raise


def convert_currency_approx(amount, from_currency, to_currency):
    """Convert currency using approximate rates."""
    if from_currency == to_currency:
        return amount
    try:
        rate = APPROXIMATE_RATES[(from_currency, to_currency)]
        return amount * rate
    except KeyError:
        medlog.logger.error(
            'Approximate rate for %s to %s not found.', from_currency, to_currency)
        return amount  # Fallback to returning the original amount if no rate is found


def calculate_statistics_from_bi(df_extract_for_bi_with_currency):
    """
    Calculates the monthly statistics from the extracted data, including currency conversions.

    Args:
        df_extract_for_bi_with_currency (pd.DataFrame): DataFrame containing the extracted data with currency information.

    Returns:
        pd.DataFrame: DataFrame containing the monthly statistics.
    """

    # Convertir les dates en mois pour groupement
    try:
        df_extract_for_bi_with_currency['Month'] = pd.to_datetime(
            df_extract_for_bi_with_currency['Month'])
    except Exception as e:
        medlog.logger.error('Error while converting dates to months: %s', e)
        return None

    api_access = check_api_access()

    # Gestion des valeurs manquantes
    df_extract_for_bi_with_currency.fillna(
        {'Amount_quantity': 0, 'Quantity_forecast': 0, 'Amount_revenue': 0, 'currency': 'EUR'}, inplace=True)

    # Initialisation du dataframe pour les statistiques
    stats_data = []

    # Calcul des totaux mensuels
    try:
        for month in df_extract_for_bi_with_currency['Month'].dt.to_period('M').unique():
            df_month = df_extract_for_bi_with_currency[df_extract_for_bi_with_currency['Month'].dt.to_period(
                'M') == month]

            # Filtrer les activités spécifiques pour 'IM-IQC - Image Quality Control'
            df_images_qc = df_month[df_month['Code']
                                    == 'IM-IQC - Image Quality Control']
            df_reads = df_month[df_month['Code']
                                == 'IR-RMG - Reads management']
            df_sites = df_month[df_month['Code'] == 'SP-SMI - Site initiation']

            # Total des images QC pour le mois
            total_number_images_qc = df_images_qc['Quantity_forecast'].sum()
            total_number_reads = df_reads['Quantity_forecast'].sum()
            total_number_sites = df_sites['Quantity_forecast'].sum()

            # Calcul des revenus convertis
            total_revenue_euro = 0
            total_revenue_dollar = 0
            total_revenue_yuan = 0

            for _, row in df_month.iterrows():
                amount = row['Amount_revenue']
                currency = row['currency']
                try:
                    if api_access:
                        total_revenue_euro += convert_currency(amount, currency, 'EUR')
                        total_revenue_dollar += convert_currency(amount, currency, 'USD')
                        total_revenue_yuan += convert_currency(amount, currency, 'CNY')
                    else:
                        total_revenue_euro += convert_currency_approx(amount, currency, 'EUR')
                        total_revenue_dollar += convert_currency_approx(amount, currency, 'USD')
                        total_revenue_yuan += convert_currency_approx(amount, currency, 'CNY')
                except Exception as e:
                    medlog.logger.error(
                        'Error while converting currency: %s', e)
                    return None

            # Ajout des données calculées dans la liste
            stats_data.append({
                'Month': month.start_time,
                'Total_number_images_QC': total_number_images_qc,
                'Total_number_reads': total_number_reads,
                'Total_number_sites': total_number_sites,
                'Total_amount_revenus_euro': total_revenue_euro

                # USD and CNY
                # Not useful as of today, but if needed, it's here.
                # 'Total_amount_revenus_dollar': total_revenue_dollar,
                # 'Total_amount_revenus_yuan': total_revenue_yuan
            })
    except Exception as e:
        medlog.logger.error(
            'Error while calculating monthly statistics: %s', e)
        return None

    # Création du dataframe des statistiques
    df_stats_content = pd.DataFrame(stats_data)

    # Trier par mois
    df_stats_content.sort_values(by='Month', inplace=True)
    df_stats_content['Month'] = df_stats_content['Month'].dt.strftime(
        '%m/%d/%Y')

    return df_stats_content


def calculate_statistics_from_bi2(df_extract_for_bi_with_currency):
    """
    Calculates the monthly statistics from the extracted data, including currency conversions.

    Args:
        df_extract_for_bi_with_currency (pd.DataFrame): DataFrame containing the extracted data with currency information.

    Returns:
        pd.DataFrame: DataFrame containing the monthly statistics.
    """

    # Convertir les dates en mois pour groupement
    try:
        df_extract_for_bi_with_currency['Month'] = pd.to_datetime(
            df_extract_for_bi_with_currency['Month']).dt.to_period('M').dt.to_timestamp()
    except Exception as e:
        medlog.logger.error('Error while converting dates to months: %s', e)
        return None

    api_access = check_api_access()

    # Gestion des valeurs manquantes
    df_extract_for_bi_with_currency.fillna(
        {'Amount_quantity': 0, 'Quantity_forecast': 0, 'Amount_revenue': 0, 'currency': 'EUR'}, inplace=True)

    # Initialisation du dataframe pour les statistiques
    stats_data = []

    # Calcul des totaux mensuels
    try:
        for month in df_extract_for_bi_with_currency['Month'].dt.to_period('M').unique():
            start_date = month.start_time
            end_date = month.end_time

            df_month = df_extract_for_bi_with_currency[(df_extract_for_bi_with_currency['Month'] >= start_date) & (
                df_extract_for_bi_with_currency['Month'] <= end_date)]

            # Calcul des images QC started
            total_number_images_qc = calcul_images_qc_started(df_month, start_date, end_date)
            total_number_reads = calcul_reads_started(df_month, start_date, end_date)
            total_number_sites = calcul_sites_started(df_month, start_date, end_date)

            # Calcul des revenus convertis
            total_revenue_euro = 0
            total_revenue_dollar = 0
            total_revenue_yuan = 0

            for _, row in df_month.iterrows():
                amount = row['Amount_revenue']
                currency = row['currency']
                try:
                    if api_access:
                        total_revenue_euro += convert_currency(amount, currency, 'EUR')
                        total_revenue_dollar += convert_currency(amount, currency, 'USD')
                        total_revenue_yuan += convert_currency(amount, currency, 'CNY')
                    else:
                        total_revenue_euro += convert_currency_approx(amount, currency, 'EUR')
                        total_revenue_dollar += convert_currency_approx(amount, currency, 'USD')
                        total_revenue_yuan += convert_currency_approx(amount, currency, 'CNY')
                except Exception as e:
                    medlog.logger.error(
                        'Error while converting currency: %s', e)
                    return None

            # Ajout des données calculées dans la liste
            stats_data.append({
                'Month': start_date,
                'Total_number_images_QC': total_number_images_qc,
                'Total_number_reads': total_number_reads,
                'Total_number_sites': total_number_sites,
                'Total_amount_revenus_euro': total_revenue_euro

                # USD and CNY
                # Not useful as of today, but if needed, it's here.
                # 'Total_amount_revenus_dollar': total_revenue_dollar,
                # 'Total_amount_revenus_yuan': total_revenue_yuan
            })
    except Exception as e:
        medlog.logger.error(
            'Error while calculating monthly statistics: %s', e)
        return None

    # Création du dataframe des statistiques
    df_stats_content = pd.DataFrame(stats_data)

    # Convertir la colonne 'Month' en type datetime
    df_stats_content['Month'] = pd.to_datetime(df_stats_content['Month'])

    # Trier par mois
    df_stats_content.sort_values(by='Month', inplace=True)

    # Formater les dates en chaînes de caractères après le tri
    df_stats_content['Month'] = df_stats_content['Month'].dt.strftime(
        '%m/%d/%Y')

    return df_stats_content


def calcul_images_qc_started(df, start_date, end_date):
    """Calculate total quantity forecast for 'IM-IQC - Image Quality Control' within a date range."""
    try:
        df_filtered = df[(df['Code'] == 'IM-IQC - Image Quality Control') &
                         (df['Month'] >= start_date) &
                         (df['Month'] <= end_date)]
        total_number_images_qc = df_filtered['Quantity_forecast'].sum()
        return total_number_images_qc
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_images_qc_started failed: %s', error_read)
        return 0

def calcul_reads_started(df, start_date, end_date):
    """Calculate total quantity forecast for 'IR-RMG - Reads management' within a date range."""
    try:
        df_filtered = df[(df['Code'] == 'IR-RMG - Reads management') &
                         (df['Month'] >= start_date) &
                         (df['Month'] <= end_date)]
        total_number_images_qc = df_filtered['Quantity_forecast'].sum()
        return total_number_images_qc
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_reads_started failed: %s', error_read)
        return 0
    
def calcul_sites_started(df, start_date, end_date):
    """Calculate total quantity forecast for 'SP-SMI - Site initiation' within a date range."""
    try:
        df_filtered = df[(df['Code'] == 'SP-SMI - Site initiation') &
                         (df['Month'] >= start_date) &
                         (df['Month'] <= end_date)]
        total_number_images_qc = df_filtered['Quantity_forecast'].sum()
        return total_number_images_qc
    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError) as error_read:
        medlog.logger.error('calcul_sites_started failed: %s', error_read)
        return 0


def extract_all_cfu_data_for_bi(df_cfu_index):
    """ Loop through the DataFrame and extract data from each CFU file
    Args:
    - df_cfu_index (pd.DataFrame): DataFrame containing CFU index information
    Returns:
    - df_extract_for_bi (pd.DataFrame): Concatenated DataFrame with all extracted data
    """
    all_data = []
    for idx, row in df_cfu_index.iterrows():
        medlog.logger.info('Processing row %d: %s', idx, row.to_dict())
        errors = []
        errors_messages = []
        if row['file_found'] == 'yes':
            try:
                result, error_msg, error_desc, precision = cfu.extract_cfu_data_for_bi(
                    row['file_path'], export_csv=False)
                if result:
                    final_merged_df, _ = result
                    all_data.append(final_merged_df)
                    df_cfu_index.at[idx, 'file_loaded'] = 'yes'
                else:
                    df_cfu_index.at[idx, 'file_loaded'] = 'no'
                    df_cfu_index.at[idx, 'load_error'] = error_msg
                    df_cfu_index.at[idx, 'error_desc'] = error_desc

            except cfu.ProductCategoryNotFoundError as e:
                medlog.logger.error('ProductCategoryNotFoundError: %s', e)
                errors.append('ProductCategoryNotFoundError')
                errors_messages.append(
                    'Product category column was not found in the file / Maybe it exists but was named differently')

            except cfu.DateNotFoundError as e:
                medlog.logger.error('DateNotFoundError: %s', e)
                errors.append('DateNotFoundError')
                errors_messages.append(
                    'Dates columns were not found in the file / Maybe they exist but were placed on the wrong row')

            except cfu.ActivityForecastNotFoundError as e:
                errors.append('ActivityForecastNotFoundError')
                errors_messages.append(
                    'ActivityForecast column was not found in the file / Maybe it exists but was named differently')
                medlog.logger.error('ActivityForecastNotFoundError: %s', e)

            except cfu.FinaldfEmptyError as e:
                medlog.logger.error('FinaldfEmptyError: %s', e)
                errors.append('FinaldfEmptyError')
                errors_messages.append(
                    'The final (merged) dataframe is empty / or the fusion process failed')

            except pd.errors.EmptyDataError:
                medlog.logger.error(
                    'EmptyDataError: The file %s is empty', row['file_path'])
                errors.append('EmptyDataError')
                errors_messages.append('File seems to be empty')

            except pd.errors.ParserError:
                medlog.logger.error(
                    'ParserError: Error parsing the file %s', row['file_path'])
                errors.append('ParserError')
                errors_messages.append(
                    'An error occurred while parsing the File')

            except FileNotFoundError:
                medlog.logger.error(
                    'FileNotFoundError: CFU file %s not found', row['file_path'])
                errors.append('FileNotFoundError')
                errors_messages.append('File was not found')

            except ValueError as error_value:
                medlog.logger.error('ValueError: %s', error_value)
                errors.append(f'ValueError: {error_value}')
                errors_messages.append(
                    'File contains a problematic value / or a value was not recognized')

            except PermissionError:
                medlog.logger.error(
                    'PermissionError: No permission to read CFU file %s', row['file_path'])
                errors.append('PermissionError')
                errors_messages.append(
                    'Permission to open the file was denied / or file is already open')

            except AttributeError:
                medlog.logger.error(
                    'AttributeError: Attribute error in file %s', row['file_path'])
                errors.append('AttributeError')
                errors_messages.append('Wrong attribute was used')

            except KeyError:
                medlog.logger.error(
                    'KeyError: Key error in file %s', row['file_path'])
                errors.append('KeyError')
                errors_messages.append(
                    'There was a problem involving keys: check again')

            except IndexError:
                medlog.logger.error(
                    'IndexError: Index error in file %s', row['file_path'])
                errors.append('IndexError')
                errors_messages.append(
                    'There was a problem involving an index: check again')

            except TypeError:
                medlog.logger.error(
                    'TypeError: Type error in file %s', row['file_path'])
                errors.append('TypeError')
                errors_messages.append(
                    'There was a problem involving an object or variable type: check again')

            except OSError as error_os:
                medlog.logger.error(
                    'OSError: Unexpected error while reading CFU file %s: %s', row['file_path'], error_os)
                errors.append(f'OSError: {error_os}')
                errors_messages.append('Unexpected OS specific error')

            except Exception as e:
                medlog.logger.error(
                    'Unexpected error during data extraction from CFU file %s: %s', row['file_path'], e)
                errors.append(str(e))
                errors_messages.append('Unexpected error occurred :' + str(e))

            if precision == "no":
                df_cfu_index.at[idx, 'file_found'] = 'no'
            if precision == "Version sheet not found":
                df_cfu_index.at[idx, 'version_sheet_loaded'] = 'no'
                df_cfu_index.at[idx, 'last_month_validated'] = 'no'
            if precision == "Last month not validated":
                df_cfu_index.at[idx, 'last_month_validated'] = 'no'

            # if df_cfu_index.at[idx, 'load_error'] is not None:
            #     df_cfu_index.at[idx, 'file_loaded'] = 'no'
            #     df_cfu_index.at[idx, 'last_month_validated'] = 'could not verify'
            #     df_cfu_index.at[idx, 'version_sheet_loaded'] = 'could not verify'

            if errors:
                df_cfu_index.at[idx, 'file_loaded'] = 'no'
                df_cfu_index.at[idx, 'last_month_validated'] = 'no'
                df_cfu_index.at[idx, 'version_sheet_loaded'] = 'no'
                df_cfu_index.at[idx, 'load_error'] = '; '.join(errors)
                df_cfu_index.at[idx, 'error_desc'] = '; '.join(errors_messages)

    if all_data:
        df_extract_for_bi = pd.concat(all_data, ignore_index=True)
        return df_extract_for_bi
    else:
        medlog.logger.error('No data extracted from CFU files')
        return None


def start_all_cfu_extraction():
    """ main part of the cfu_import_all module """
    try:
        cfu.initialize_logger_for_cfu_import(Path('./log/cfu_import_log'))
        cfu_index_path = Path('./tests/data/cfu_index.xlsx')
        # cfu_index_path = Path('./tests/data/cfu_index_test.xlsx')
        working_folder = Path('./tests/working/')
        os.makedirs(working_folder, exist_ok=True)

        index_file_name = copy_file_to_path(cfu_index_path, working_folder)
        df_cfu_index = read_cfu_index_to_df(index_file_name)

        if df_cfu_index is None:
            return False

        df_cfu_index = copy_cfu_from_index_to_working_folder(
            df_cfu_index, working_folder)

        df_extract_for_bi = extract_all_cfu_data_for_bi(df_cfu_index)

        if df_extract_for_bi is not None:
            output_csv_path = working_folder / 'final_extracted_data.csv'
            df_extract_for_bi.to_csv(output_csv_path, index=False, sep=',')
            medlog.logger.info(
                " --> All CFU data has been successfully extracted and saved to %s", output_csv_path)
        else:
            medlog.logger.error("Failed to extract data from CFU files")

        diagnostic_csv_path = working_folder / 'cfu_diagnostic_data.csv'
        df_cfu_index.to_csv(diagnostic_csv_path, index=False, sep=',')
        medlog.logger.info(
            " --> Diagnostic data has been saved to %s", diagnostic_csv_path)

        statistics_df = calculate_statistics(df_cfu_index)
        statistics_df['% project found'] = statistics_df['% project found'].round(2)
        statistics_df['% project loaded'] = statistics_df['% project loaded'].round(2)
        statistics_df['% project with product category missing'] = statistics_df['% project with product category missing'].round(2)
        statistics_df['% project with activityforecast missing'] = statistics_df['% project with activityforecast missing'].round(2)
        statistics_df['% version sheet loaded'] = statistics_df['% version sheet loaded'].round(2)
        statistics_df['% past month validated'] = statistics_df['% past month validated'].round(2)

        statistics_csv_path = working_folder / 'cfu_statistic_process.csv'
        statistics_df.to_csv(statistics_csv_path, index=False, sep=',')
        medlog.logger.info(
            " --> File statistics have been saved to %s", diagnostic_csv_path)

        df_extract_for_bi_with_currency = merge_currency_to_bi_data(
            df_extract_for_bi, df_cfu_index)

        # statistics_from_bi_df = calculate_statistics_from_bi(df_extract_for_bi_with_currency)
        statistics_from_bi_df = calculate_statistics_from_bi2(df_extract_for_bi_with_currency)
        
        #Rounding just in case, but it should not be necessary for those three
        statistics_from_bi_df['Total_number_images_QC'] = statistics_from_bi_df['Total_number_images_QC'].round(2)
        statistics_from_bi_df['Total_number_reads'] = statistics_from_bi_df['Total_number_reads'].round(2)
        statistics_from_bi_df['Total_number_sites'] = statistics_from_bi_df['Total_number_sites'].round(2)

        statistics_from_bi_df['Total_amount_revenus_euro'] = statistics_from_bi_df['Total_amount_revenus_euro'].round(2)
        
        # USD and CNY
        #Not useful as of today, but if needed, it's here.
        # statistics_from_bi_df['Total_amount_revenus_dollar'] = statistics_from_bi_df['Total_amount_revenus_dollar'].round(2)
        # statistics_from_bi_df['Total_amount_revenus_yuan'] = statistics_from_bi_df['Total_amount_revenus_yuan'].round(2)

        statistics_content_csv_path = working_folder / 'cfu_statistic_content.csv'
        statistics_from_bi_df.to_csv(
            statistics_content_csv_path, index=False, sep=',')
        medlog.logger.info(
            " --> Statistics content has been saved to %s", diagnostic_csv_path)

        return True

    except pd.errors.EmptyDataError:
        medlog.logger.error('EmptyDataError: The CFU index file is empty')
    except pd.errors.ParserError:
        medlog.logger.error('ParserError: Error parsing the CFU index file')
    except FileNotFoundError:
        medlog.logger.error('FileNotFoundError: The CFU index file not found')
    except ValueError as error_value:
        medlog.logger.error('ValueError: %s', error_value)
    except PermissionError:
        medlog.logger.error(
            'PermissionError: No permission to access the CFU index file')
    except AttributeError:
        medlog.logger.error(
            'AttributeError: Attribute error in the CFU index file')
    except KeyError:
        medlog.logger.error('KeyError: Key error in the CFU index file')
    except IndexError:
        medlog.logger.error('IndexError: Index error in the CFU index file')
    except TypeError:
        medlog.logger.error('TypeError: Type error in the CFU index file')
    except OSError as error_os:
        medlog.logger.error(
            'OSError: Unexpected error while processing the CFU index file: %s', error_os)
    return False


if __name__ == '__main__':
    # TODO: later : manage arguments (at least debug/info, path to index file, working folder, path to result)
    # argument_prog_list = sys.argv[1:] ... if len(argument_prog_list) > 0: ...
    if start_all_cfu_extraction() is True:
        medlog.logger.info('start_all_cfu_extraction completed successfully')
    else:
        medlog.logger.info('start_all_cfu_extraction was not completed')
