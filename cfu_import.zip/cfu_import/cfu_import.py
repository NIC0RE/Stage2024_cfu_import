"""
    Ce programme permet de charger un fichier Excel, de localiser la cellule 
    contenant "Product category" et de détecter les colonnes de dates dans le format 
    "MMM-YY" (par exemple, Aug-23 pour août 2023). Il utilise le module pandas 
    pour manipuler les données et les expressions régulières pour identifier 
    les colonnes de dates. Les recherches sont effectuées uniquement dans les feuilles
    "Qty Forecast" et "Revenus Forecast".

    Main function is extract_cfu_data_for_bi(filename)
"""

__authors__ = "MEDIAN Technologies"
__copyright__ = "MEDIAN Technologies"
__date__ = "2024-06-28"
__version__= "01.01"

import sys
from datetime import datetime
import os
from pathlib import Path
import pandas as pd
import medlog
from datetime import datetime, timedelta

class ProductCategoryNotFoundError(Exception):
    pass

class DateNotFoundError(Exception):
    pass

class ActivityForecastNotFoundError(Exception):
    pass

class FinaldfEmptyError(Exception):
    pass

class SheetNotFoundError(Exception):
    pass

ProductCategoryNotFound_Error = False
DateNotFound_Error = False
ActivityForecastNotFound_Error = False
FinaldfEmpty_Error = False

def get_product_category_position(df_cfu):
    """
    Find the cell containing "Product category" in the DataFrame.
    
    Parameters:
    df (DataFrame): The pandas DataFrame to look for the value in.
    
    Returns:
    tuple: The coordinates (row, column) of the cell containing "Product category" if found, otherwise None.
    """
    try:
        for row in df_cfu.index:
            for col in df_cfu.columns:
                # if isinstance(df.at[row, col], str) and df.at[row, col].strip().lower() == 'unit type':
                if isinstance(df_cfu.at[row, col], str) and df_cfu.at[row, col].strip().lower() == 'product category':
                    return (row, col), "", ""
        # ProductCategoryNotFound_Error = True
        # raise ProductCategoryNotFoundError("Product category column not found")
        return None, "Product category column not found", "Product category column was not found in the file / Maybe it exists but was named differently"
        
    except (pd.errors.EmptyDataError, pd.errors.ParserError, ValueError, KeyError, IndexError, TypeError, OSError) as error_read:
        medlog.logger.error('get_product_category_position failed (%s)', error_read)
        return None, error_read, "An error occurred while trying to find the Product category column in the file" 

def get_date_columns(df_cfu, product_category_row):
    """
    Finds columns matching the date format "MMM-YY" in the same row as "Product category".
    
    Parameters:
    df_cfu (DataFrame): The pandas DataFrame in which to search for date columns.
    product_category_row (int): The index of the row containing "Product category".
    
    Returns:
    list: A list of tuples containing column names and dates in "MMM-YY" format.
    """
    date_columns = []
    try:
        for col in df_cfu.columns:
            value = df_cfu.at[product_category_row, col]
            # print(f"Checking cell at row {product_category_row}, column {col}: value = {value} (type = {type(value)})")  # Debug print
            if isinstance(value, datetime):
                date_str = value.strftime('%b-%y')
                date_columns.append((col, date_str))

    except (pd.errors.EmptyDataError, pd.errors.ParserError, ValueError, KeyError, IndexError, TypeError, OSError) as error_read:
        medlog.logger.error('get_date_columns failed (%s)', error_read)
        return None, error_read, "An error occurred while trying to find the date columns in the file"

    if len(date_columns) != 0:
        return date_columns, "", ""
    # raise DateNotFoundError("Dates columns not found")
    return None, "Dates columns not found", "Dates columns were not found in the file / Maybe they exist but were placed on the wrong row"

def get_activity_forecast(df_cfu):
    """
    Find the cell containing "ActivityForecast" in the DataFrame.
    
    Parameters:
    df (DataFrame): The pandas DataFrame to look for the value in.
    
    Returns:
    tuple: The coordinates (row, column) of the cell containing "Product category" if found, otherwise None.
    """
    try:
        for row in df_cfu.index:
            for col in df_cfu.columns:
                if isinstance(df_cfu.at[row, col], str) and df_cfu.at[row, col].strip().lower() == 'activityforecast':
                    print('La colonne ActivityForecast a été trouvée !')
                    return (row, col),"",""
    except (pd.errors.EmptyDataError, pd.errors.ParserError, ValueError, KeyError, IndexError, TypeError, OSError) as error_read:
        medlog.logger.error('get_activity_forecast failed (%s)', error_read)
    return None, "ActivityForecast not found", "ActivityForecast column was not found in the file / Maybe it exists but was named differently"


def find_column_name_by_content(df_cfu, content):
    """
    Finds the name of the column containing the specified content in the DataFrame.
    
    Parameters:
    df (DataFrame): The pandas DataFrame to search for content in.
    content (str): The content to search for in the DataFrame.
    
    Returns:
    str: The name of the column containing the specified content, or None if not found.
    """
    try:
        for col in df_cfu.columns:
            if df_cfu[col].astype(str).str.contains(content, case=False).any():
                return col
    except (pd.errors.EmptyDataError, pd.errors.ParserError, ValueError, KeyError, IndexError, TypeError, OSError) as error_read:
        medlog.logger.error('find_column_name_by_content failed (%s)', error_read)
    return None


def concatenate_product_category_and_activity_forecast(df_cfu):
    """
    Concatenates the 'Product category' and 'ActivityForecast' columns into a DataFrame.

    Parameters:
    df (DataFrame): The pandas DataFrame containing the columns to concatenate.

    Returns:
    DataFrame: The DataFrame with a new column 'Product category - ActivityForecast'.
    """
    try:
        product_category_column = find_column_name_by_content(df_cfu, 'Product category')
        activity_forecast_column = find_column_name_by_content(df_cfu, 'ActivityForecast')

        if product_category_column:
            if activity_forecast_column:
                # Remplir les valeurs manquantes dans la colonne 'ActivityForecast' avec 'yes'
                # df_cfu[activity_forecast_column] = df_cfu[activity_forecast_column].fillna('yes', inplace=True)
                df_cfu[activity_forecast_column].fillna('no', inplace=True)
                # Concaténer les valeurs de "Product category" et "ActivityForecast"
                df_cfu[product_category_column] = df_cfu[product_category_column] + ' - ' + df_cfu[activity_forecast_column]
            else:
                medlog.logger.error('Columns ActivityForecast not found in dataframe')
                # ActivityForecastNotFound_Error = True
                # raise ActivityForecastNotFoundError("ActivityForecast column not found")
                return None, "ActivityForecast column not found", "ActivityForecast column was not found in the file / Maybe it exists but was named differently"
        else:
            medlog.logger.error('Columns Product category not found in dataframe')
            # ProductCategoryNotFound_Error = True
            # raise ProductCategoryNotFoundError("Product category column not found")
            #raise KeyError("Columns 'Product category' and/or 'ActivityForecast' ne sont pas présentes dans le DataFrame.")
            return None, "Product category column not found", "Product category column was not found in the file / Maybe it exists but was named differently"

    except (pd.errors.EmptyDataError, pd.errors.ParserError, ValueError, KeyError, IndexError, TypeError, OSError) as error_read:
        medlog.logger.error('concatenate_product_category_and_activity_forecast failed (%s)', error_read)
        return None, error_read, "An error occurred while trying to concatenate the columns 'Product category' and 'ActivityForecast'"

    return df_cfu, "", ""


def clean_dataframe(df_cfu, product_category_col, date_columns):
    """
    Cleans the DataFrame by removing columns that are not of interest.
    
    Parameters:
    df (DataFrame): The pandas DataFrame to clean.
    product_category_col (str): The name of the "Product category" column.
    date_columns(list): The list of date column names.
    
    Returns:
    DataFrame: A cleaned DataFrame with only the columns of interest.
    """
    # Trouver les indices des colonnes
    try:
        product_category_index = df_cfu.columns.get_loc(product_category_col)
        date_indices = [df_cfu.columns.get_loc(col) for col in date_columns]

        if not date_indices:
            medlog.logger.error('clean_dataframe failed. No date columns found.(%s)', product_category_col)
            return df_cfu[[product_category_col]]

        # Indices des colonnes d'intérêt
        first_date_index = min(date_indices)
        last_date_index = max(date_indices)

        # Garder les colonnes "Product category" et les colonnes de la première à la dernière date
        columns_of_interest = df_cfu.columns[product_category_index:product_category_index+2].tolist() +\
            df_cfu.columns[first_date_index:last_date_index+1].tolist()
        cleaned_df = df_cfu[columns_of_interest]

    except (pd.errors.EmptyDataError, pd.errors.ParserError, ValueError, KeyError, IndexError, TypeError, OSError) as error_read:
        medlog.logger.error('clean_dataframe failed (%s)', error_read)
        return None

    return cleaned_df


def create_new_dataframe_revenus_forecast(cleaned_df, project_name, date_columns):
    """
    Creates a new Revenue Forecast DataFrame from a cleaned DataFrame.
    Args:
        cleaned_df (pd.DataFrame): Cleaned DataFrame containing the data to transform.
        project_name (str): Name of the project to add in the 'Project_code' column.
        date_columns (list of tuples): List of tuples containing date columns and their corresponding values.

    Returns:
        pd.DataFrame: New DataFrame containing revenue forecasts, with columns 'Project_code', 'Month', 'Code', and 'Amount'.
    """
    try:
        melted_df = cleaned_df.melt(id_vars=cleaned_df.columns[0], value_vars=[col for col, _ in date_columns],
                                var_name='Month', value_name='Amount')

        melted_df = melted_df[melted_df[melted_df.columns[0]] != 'Product category']

        melted_df['Month'] = melted_df['Month'].apply(lambda x: dict(date_columns)[x])
        melted_df['Project_code'] = project_name

        melted_df['Month'] = pd.to_datetime(melted_df['Month'], format='%b-%y', errors='coerce')
        melted_df = melted_df.sort_values(by='Month').reset_index(drop=True)

        new_df = melted_df.groupby(['Project_code', 'Month', melted_df.columns[0]], as_index=False)['Amount'].sum()
        new_df.rename(columns={melted_df.columns[0]: 'Code'}, inplace=True)

        new_df = new_df[new_df['Amount'] != 0]

    except (pd.errors.EmptyDataError, pd.errors.ParserError, ValueError, KeyError, IndexError, TypeError, OSError) as error_read:
        medlog.logger.error('create_new_dataframe_revenus_forecast failed (%s)', error_read)
        return None
    return new_df


def create_new_dataframe_qty_forecast(cleaned_df, project_name, date_columns):
    """
    Creates a new Quantity Forecast DataFrame from a cleaned DataFrame.

    Args:
        cleaned_df (pd.DataFrame): Cleaned DataFrame containing the data to transform.
        project_name (str): Name of the project to add in the 'Project_code' column.
        date_columns (list of tuples): List of tuples containing date columns and their corresponding values.

    Returns:
        pd.DataFrame: New DataFrame containing the quantity forecasts, with the columns 'Project_code', 'Month', 'Code', and 'Amount'.
    """
    try:
        melted_df = cleaned_df.melt(id_vars=cleaned_df.columns[0], value_vars=[col for col, _ in date_columns],
                                var_name='Month', value_name='Amount')

        melted_df = melted_df[melted_df[melted_df.columns[0]] != 'Product category']

        melted_df['Month'] = melted_df['Month'].apply(lambda x: dict(date_columns)[x])
        melted_df['Project_code'] = project_name

        melted_df['Month'] = pd.to_datetime(melted_df['Month'], format='%b-%y', errors='coerce')
        melted_df = melted_df.sort_values(by='Month').reset_index(drop=True)


        new_df = melted_df.groupby(['Project_code', 'Month', melted_df.columns[0]], as_index=False)['Amount'].sum()
        new_df.rename(columns={melted_df.columns[0]: 'Code'}, inplace=True)

        new_df = new_df[new_df['Amount'] != 0]

    except (pd.errors.EmptyDataError, pd.errors.ParserError, ValueError, KeyError, IndexError, TypeError, OSError) as error_read:
        medlog.logger.error('create_new_dataframe_qty_forecast failed (%s)', error_read)
        return None
    return new_df


def create_new_dataframe_qty_forecast_filtered(cleaned_df, project_name, date_columns):
    """
    Creates a new filtered Quantity Forecast DataFrame from a cleaned DataFrame.

    Args:
        cleaned_df (pd.DataFrame): Cleaned DataFrame containing the data to transform.
        project_name (str): Name of the project to add in the 'Project_code' column.
        date_columns (list of tuples): List of tuples containing date columns and their corresponding values.

    Returns:
        pd.DataFrame: New df containing the filtered quantity forecasts, with the columns 'Project_code', 'Month', 'Code' and 'Quantity_forecast'.
    """
    try:
        # Fusionner les colonnes de date
        melted_df = cleaned_df.melt(id_vars=cleaned_df.columns[0], value_vars=[col for col, _ in date_columns],
                                    var_name='Month', value_name='Quantity_forecast')

        # Retirer les lignes contenant "Product category"
        melted_df = melted_df[~melted_df[melted_df.columns[0]].str.contains('Product category', case=False, na=False)]

        # Convertir les noms de mois en format de date
        melted_df['Month'] = melted_df['Month'].apply(lambda x: dict(date_columns)[x])
        melted_df['Project_code'] = project_name

        # Convertir les mois en objets datetime
        melted_df['Month'] = pd.to_datetime(melted_df['Month'], format='%b-%y', errors='coerce')
        melted_df = melted_df.sort_values(by='Month').reset_index(drop=True)

        # Filtrer les lignes où IncludeInSum est "yes"
        # filtered_df = melted_df[melted_df['Code'] == 'yes']
        filtered_df = melted_df[melted_df[melted_df.columns[0]].str.contains('yes', case=False, na=False)]

        # Grouper par code de projet, mois et première colonne pour calculer la somme des montants
        new_df = filtered_df.groupby(['Project_code', 'Month', filtered_df.columns[0]], as_index=False)['Quantity_forecast'].sum()
        new_df.rename(columns={filtered_df.columns[0]: 'Code'}, inplace=True)

        # Retirer les lignes avec montant égal à 0
        new_df = new_df[new_df['Quantity_forecast'] != 0]

    except (pd.errors.EmptyDataError, pd.errors.ParserError, ValueError, KeyError, IndexError, TypeError, OSError) as error_read:
        medlog.logger.error('create_new_dataframe_qty_forecast_filtered failed (%s)', error_read)
        return None
    return new_df


def initialize_dataframes_from_excel(file_path):
    """
    Loads specific sheets from the specified Excel file into a dictionary of pandas DataFrames.
    
    Parameters:
    file_path (str): The path of the Excel file to load.
    
    Returns:
    dict: A dictionary of pandas DataFrames containing data from specific sheets of the Excel file.
    """
    sheets_to_load = ["Qty Forecast", "Revenus Forecast"]
    try:
        # Open the Excel file to get the sheet names
        excel_file = pd.ExcelFile(file_path)
        available_sheets = excel_file.sheet_names

        # Check if all required sheets are present
        missing_sheets = [sheet for sheet in sheets_to_load if sheet not in available_sheets]
        if missing_sheets:
            raise SheetNotFoundError(f"Missing sheets in the Excel file: {', '.join(missing_sheets)}")

        # Load the required sheets
        df_dict_from_excel = pd.read_excel(file_path, sheet_name=sheets_to_load)

    except FileNotFoundError as e:
        medlog.logger.error('FileNotFoundError: The file %s was not found (%s)', file_path, e)
        return None, "File not found while trying to initialise dataframe", "Failed to read excel file / Make sure the file is in the correct folder"
    except pd.errors.EmptyDataError as e:
        medlog.logger.error('EmptyDataError: The file %s is empty (%s)', file_path, e)
        return None, "Empty file while trying to initialise dataframe", "Failed to read excel file / Make sure the file sheets are named correctly"
    except pd.errors.ParserError as e:
        medlog.logger.error('ParserError: There was an error parsing the file %s (%s)', file_path, e)
        return None, "Error parsing file while trying to initialise dataframe", "Failed to read excel file / Probably due to incorrect format"
    except ValueError as e:
        medlog.logger.error('ValueError: There was a value error in the file %s (%s)', file_path, e)
        return None, "Value error while trying to initialise dataframe", "Failed to read excel file / The program was not able to find the file at all"
    except PermissionError as e:
        medlog.logger.error('PermissionError: No permission to read the file %s (%s)', file_path, e)
        return None, "Permission error while trying to initialise dataframe", "Failed to read excel file / Make sure the file is not open"
    except AttributeError as e:
        medlog.logger.error('AttributeError: Attribute error in the file %s (%s)', file_path, e)
        return None, "Attribute error while trying to initialise dataframe", "Failed to read excel file / Make sure the file is not corrupted"
    except KeyError as e:
        medlog.logger.error('KeyError: %s', e)
        return None, "Key error while trying to initialise dataframe", "Failed to read excel file / Make sure the file is not corrupted"
    except IndexError as e:
        medlog.logger.error('IndexError: Index error in the file %s (%s)', file_path, e)
        return None, "Index error while trying to initialise dataframe", "Failed to read excel file / Make sure the file sheets are named correctly"
    except TypeError as e:
        medlog.logger.error('TypeError: Type error in the file %s (%s)', file_path, e)
        return None, "Type error while trying to initialise dataframe", "Failed to read excel file / Make sure the file is an excel file"
    except OSError as e:
        medlog.logger.error('OSError: Unexpected OS error while reading the file %s (%s)', file_path, e)
        return None, "OS error while trying to initialise dataframe", "Failed to read excel file / OSerror could not be identified"
    except SheetNotFoundError as e:
        medlog.logger.error('SheetNotFoundError: Sheet %s was not found in the file', missing_sheets)
        return None, f"Sheet {missing_sheets} not found while trying to initialise dataframe", "Failed to read excel file / Make sure the file sheets are named correctly"
    except Exception as e:
        medlog.logger.error('UnexpectedError: An unexpected error occurred while reading the file %s (%s)', file_path, e)
        if str(e) == "Can't find workbook in OLE2 compound document":
            return None, str(e), "Failed to access excel file / The file is protected and needs high autorization to be opened"
        return None, f"Unexpected error while trying to initialise dataframe {file_path} : {e}", ""

    medlog.logger.debug('Read of CFU file %s : ok', file_path)
    return df_dict_from_excel, "", ""


def process_sheets(df_dict_from_excel, file_path):
    """
    Process each sheet in the given dictionary of DataFrames to identify and handle quantity and revenue forecasts.

    Args:
        df_dict (dict): Dictionary wher        if 'df_new_qty_forecast' in df_res_dict:
            final_merged_df, final_merged_df_outer = merge_dataframes(df_res_dict['df_new_qty_forecast'], being processed.

    Returns:
        tuple: Contains dataframe for qtty forecast, revenue forecast, new quantity forecast, new filtered quantity forecast and new revenue forecast
    """
    # Initialisation des DataFrames pour chaque feuille spécifique
    df_qty_forecast = None
    df_revenus_forecast = None
    df_new_qty_forecast = None
    df_new_qty_forecast_filtered = None
    df_new_revenue_forecast = None

    for sheet_name, df_from_sheet in df_dict_from_excel.items():
        try:
            product_category_location, error_msg_product, error_desc_product = get_product_category_position(df_from_sheet)
            if sheet_name == "Qty Forecast":
                activity_forecast_location, error_msg_activity, error_desc_activity = get_activity_forecast(df_from_sheet)
            
            if product_category_location is None:
                medlog.logger.debug('Product Category column NOT found in sheet %s', sheet_name)
                medlog.logger.error('Product Category column not found in dataframe %s', file_path)
                if sheet_name == "Qty Forecast":
                    medlog.logger.error('ActivityForecast column not found in dataframe %s', file_path)
                    return None, str(error_msg_product + " ; " + error_msg_activity), str(error_desc_product + " ; " + error_desc_activity)
                else:
                    return None, str(error_msg_product), str(error_desc_product)
            
            if sheet_name == "Qty Forecast" and activity_forecast_location is None:
                medlog.logger.debug('ActivityForecast NOT found in sheet %s', sheet_name)
                medlog.logger.error('Columns ActivityForecast not found in dataframe %s', file_path)
                return None, str(error_msg_activity), str(error_desc_activity)
            
            if activity_forecast_location is not None:
                medlog.logger.debug('ActivityForecast found in sheet %s at: %s', sheet_name, activity_forecast_location)
                # print(f'\033[93mActivityForecast found in sheet "{sheet_name}" at: {activity_forecast_location}\033[0m')
                activity_forecast_row, activity_forecast_col = activity_forecast_location
                activity_forecast_column_name = activity_forecast_col
                print(df_from_sheet[activity_forecast_column_name][5:15])

            if sheet_name == "Qty Forecast" and product_category_location is not None and activity_forecast_location is not None:
                medlog.logger.debug('Product category found in sheet %s at: %s', sheet_name, product_category_location)
                # print(f'\033[93mProduct category found in sheet "{sheet_name}" at: {product_category_location}\033[0m')

                product_category_row, product_category_col = product_category_location
                product_category_column_name = product_category_col
                medlog.logger.debug('Product category column name: %s', product_category_column_name)
                # print(f'Product category column name: {product_category_column_name}')

                date_columns, error_msg_date, error_desc_date = get_date_columns(df_from_sheet, product_category_row)

                if date_columns is None:
                    return None, str(error_msg_date), str(error_desc_date)
                
                if date_columns is not None:
                    date_columns_names = [col[0] for col in date_columns]
                    date_columns_display = [col[1] for col in date_columns]
                    medlog.logger.debug('Date columns found in sheet %s : %s', sheet_name, date_columns_names)
                    medlog.logger.debug('Date columns display: %s', date_columns_display)
                    # print(f'\033[93mDate columns found in sheet "{sheet_name}": {date_columns_names}\033[0m')
                    # print(f'Date columns display: {date_columns_display}')
                # else:
                    #  medlog.logger.debug('No date columns found in sheet: %s', sheet_name)
                    # print(f'No date columns found in sheet "{sheet_name}".')
                    df_qty_forecast = df_from_sheet
                    df_new_qty_forecast, df_new_qty_forecast_filtered, error_msg_concatenate, error_desc_concatenate = create_qty_forecast_dfs(df_from_sheet, product_category_column_name, date_columns, file_path)

            if sheet_name == "Revenus Forecast" and product_category_location is not None:
                medlog.logger.debug('Product category found in sheet %s at: %s', sheet_name, product_category_location)
                product_category_row, product_category_col = product_category_location
                product_category_column_name = product_category_col
                medlog.logger.debug('Product category column name: %s', product_category_column_name)
                # print(f'Product category column name: {product_category_column_name}')
                date_columns, error_msg_date, error_desc_date = get_date_columns(df_from_sheet, product_category_row)

                if date_columns is None:
                    medlog.logger.error('Date Columns not found in dataframe %s', file_path)
                    return None, str(error_msg_date), str(error_desc_date)

                if date_columns is not None:
                    date_columns_names = [col[0] for col in date_columns]
                    date_columns_display = [col[1] for col in date_columns]
                    medlog.logger.debug('Date columns found in sheet %s : %s', sheet_name, date_columns_names)
                    medlog.logger.debug('Date columns display: %s', date_columns_display)
                    df_revenus_forecast = df_from_sheet
                    df_new_revenue_forecast, error_revenue_msg = create_revenue_forecast_df(df_from_sheet, product_category_column_name, date_columns, file_path)
                # else:
                    #     medlog.logger.warning('Product category not found in sheet: %s', sheet_name)
                    #     # print(f'\033[91mProduct category not found in sheet "{sheet_name}".\033[0m')

        except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError, OSError) as error_read:
            medlog.logger.error('Failed to process sheet %s (%s)', sheet_name, error_read)
            return None, str(error_read), "An error occurred while processing the sheet"

    dataframes = {'df_qty_forecast': df_qty_forecast, 'df_revenues_forecast': df_revenus_forecast,
                  'df_new_qty_forecast': df_new_qty_forecast, 'df_new_qty_forecast_filtered': df_new_qty_forecast_filtered,
                  'df_new_revenue_forecast' : df_new_revenue_forecast
                 }
    return dataframes, str(error_msg_concatenate), str(error_desc_concatenate)


def create_qty_forecast_dfs(df, product_category_column_name, date_columns, file_path):
    """
    Create new DataFrames for quantity forecasts by cleaning and transforming the given DataFrame.

    Args:
        df (pd.DataFrame): DataFrame containing raw data.
        product_category_column_name (str): Name of the product category column.
        date_columns (list of tuples): List of tuples containing date columns and their respective display formats.
        file_path (str): Path to the original file being processed.

    Returns:
        tuple: Contains new quantity forecast DataFrame and new filtered quantity forecast DataFrame.
    """
    try:
        df_cleaned_qty_forecast = clean_dataframe(df, product_category_column_name, [col[0] for col in date_columns])
        df_new_qty_forecast = create_new_dataframe_qty_forecast(df_cleaned_qty_forecast, file_path, date_columns)
        df_concatenated, error_msg_concatenate, error_desc_concatenate = concatenate_product_category_and_activity_forecast(df)
        df_cleaned_filtered_qty_forecast = clean_dataframe(df_concatenated, product_category_column_name, [col[0] for col in date_columns])
        df_new_qty_forecast_filtered = create_new_dataframe_qty_forecast_filtered(df_cleaned_filtered_qty_forecast, file_path, date_columns)
    except (IndexError, TypeError) as error_read:
        medlog.logger.error('Failed creating quantity forecast DataFrames %s - %s (%s)', product_category_column_name, file_path, error_read)
        return None, error_read, "", ""
    return df_new_qty_forecast, df_new_qty_forecast_filtered, str(error_msg_concatenate), str(error_desc_concatenate)


def create_revenue_forecast_df(df, product_category_column_name, date_columns, file_path):
    """
    Create new DataFrames for revenue forecasts by cleaning and transforming the given DataFrame.

    Args:
        df (pd.DataFrame): DataFrame containing raw data.
        product_category_column_name (str): Name of the product category column.
        date_columns (list of tuples): List of tuples containing date columns and their respective display formats.
        file_path (str): Path to the original file being processed.

    Returns:
        tuple: Contains new revenue forecast DataFrame only.
    """
    try:
        df_cleaned_revenus_forecast = clean_dataframe(df, product_category_column_name, [col[0] for col in date_columns])
        df_new_revenue_forecast = create_new_dataframe_revenus_forecast(df_cleaned_revenus_forecast, file_path, date_columns)

    except (IndexError, TypeError) as error_read:
        medlog.logger.error('Error creating revenue forecast DataFrame %s - %s (%s)', product_category_column_name, file_path, error_read)
        return None, error_read
    return df_new_revenue_forecast, ""


def merge_dataframes(new_qty_forecast_df, new_qty_forecast_df_filtered, new_revenue_forecast_df):
    """
    Merge the given DataFrames for quantity and revenue forecasts into a final DataFrame.

    Args:
        new_qty_forecast_df (pd.DataFrame): DataFrame containing new quantity forecasts.
        new_qty_forecast_df_filtered (pd.DataFrame): DataFrame containing new filtered quantity forecasts.
        new_revenue_forecast_df (pd.DataFrame): DataFrame containing new revenue forecasts.

    Returns:
        tuple: Contains the final merged DataFrame and the outer merged DataFrame.
    """
    try:
        new_qty_forecast_df_filtered['Code'] = new_qty_forecast_df_filtered['Code'].str.replace(r' - yes| - no', '', regex=True)

        merged_df = pd.merge(
            new_qty_forecast_df,
            new_qty_forecast_df_filtered,
            on=['Project_code', 'Month', 'Code'],
            suffixes=('', '_filtered')
        )

        final_merged_df = pd.merge(
            merged_df,
            new_revenue_forecast_df,
            on=['Project_code', 'Month', 'Code'],
            suffixes=('', '_revenue')
        )

        final_merged_df.rename(columns={'Amount': 'Amount_quantity'}, inplace=True)
        final_merged_df['Amount_quantity'] = pd.to_numeric(final_merged_df['Amount_quantity'], errors='coerce')
        final_merged_df['Amount_revenue'] = pd.to_numeric(final_merged_df['Amount_revenue'], errors='coerce')
        final_merged_df['Amount_revenue'] = final_merged_df['Amount_revenue'].round(2)

        merged_df_outer = pd.merge(
            new_qty_forecast_df,
            new_qty_forecast_df_filtered,
            on=['Project_code', 'Month', 'Code'],
            suffixes=('', '_filtered'),
            how='outer'
        )

        final_merged_df_outer = pd.merge(
            merged_df_outer,
            new_revenue_forecast_df,
            on=['Project_code', 'Month', 'Code'],
            suffixes=('', '_revenue'),
            how='outer'
        )

        final_merged_df_outer.rename(columns={'Amount': 'Amount_quantity'}, inplace=True)
        final_merged_df_outer['Amount_quantity'] = pd.to_numeric(final_merged_df_outer['Amount_quantity'], errors='coerce')
        final_merged_df_outer['Amount_revenue'] = pd.to_numeric(final_merged_df_outer['Amount_revenue'], errors='coerce')
        final_merged_df_outer['Amount_revenue'] = final_merged_df_outer['Amount_revenue'].round(2)
        final_merged_df_outer = final_merged_df_outer.fillna('0')

    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError, OSError) as error_read:
        medlog.logger.error('Merge of result dataframe for 1 cfu has failed (%s)', error_read)
        return None, None

    return final_merged_df, final_merged_df_outer


def export_to_csv(final_merged_df, final_merged_df_outer, original_file_path="Project_file_example"):
    """
    Export the final merged DataFrame to CSV files.

    Args:
        final_merged_df (pd.DataFrame): Final merged DataFrame.
        final_merged_df_outer (pd.DataFrame): Outer merged DataFrame.
        original_file_path (str): Path to the original file for naming the output files.

    Returns:
        None
    """
    try:
        base_name = os.path.splitext(os.path.basename(original_file_path))[0]
        output_csv_path = f'{base_name}_final_merged_data.csv'
        final_merged_df.to_csv(output_csv_path, index=False, sep=";")

        output_csv_path_complete = f'{base_name}_final_merged_data_complete.csv'
        final_merged_df_outer.to_csv(output_csv_path_complete, index=False, sep=";")
        medlog.logger.debug('Final DataFrames have been successfully exported to %s and %s', output_csv_path, output_csv_path_complete)

        if final_merged_df.empty :
            FinaldfEmpty_Error = True
            raise FinaldfEmptyError("Final dataframe is empty") 


    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError, OSError) as error_merge:
        medlog.logger.error('Merge of result dataframe for 1 cfu has failed (%s)', error_merge)
        return False
    return True


def initialize_logger_for_cfu_import(log_path):
    """ Initialize the logger """
    try:
        os.makedirs(log_path.parent, exist_ok = True)
        medlog.initialize_logger(str(log_path), str(log_path) + '_error', medlog.logging.INFO, ['html'], 'cfu_import')
        # medlog.initialize_logger(str(log_path), str(log_path) + '_error', medlog.logging.DEBUG, ['html'], 'cfu_import')
        medlog.logger.info("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    except (PermissionError, NotADirectoryError, OSError) as error_os:
        print("Issue in creating log folder. Current folder will be used as log path (%s)", error_os)
        log_path = Path('./cfu_import_log')
    return True

def extract_version_history(file_path):
    """
    Extract version history from the 'version' sheet of the Excel file.

    Parameters:
    file_path (str): The path to the Excel file.

    Returns:
    pd.DataFrame: A DataFrame containing the version history.
    """
    try:

        xls = pd.ExcelFile(file_path)

        # Vérifier les noms de feuilles possibles
        possible_sheets = ['Version', 'Version ']
        sheet_name = None

        for sheet in possible_sheets:
            if sheet in xls.sheet_names:
                sheet_name = sheet
                break

        if sheet_name is None:
            medlog.logger.error("'Version' sheet was not found in the dataframe %s. Check directly in the file.",file_path)
            return None, "Sheet not found", "'Version' sheet was not found in the current file.",""

        usecols = "B:F,H:AA"
        df_version = pd.read_excel(xls, sheet_name=sheet_name, skiprows=6, usecols=usecols)

        if df_version.shape[1] < 24:
            medlog.logger.error('The sheet does not contain enough columns.')
            return None, "Version sheet error", "The sheet does not contain enough columns."

        # Define the new column names, assuming they are known
        new_columns = [
            'Histo_Date', 'Histo_Version', 'Histo_Description', 'Histo_Author', 'Histo_Modified', 'Month_Validated', 'Quart_Forecast_Value', 'Quart_Difference', 'Quart_Rational', 'Quart_Comment', 'Budget_Forecast_Value', 'Budget_Difference', 'Budget_Rational', 'Budget_Comments', 'Final_Difference_Value', 'Final_Rational', 'Final_Comments', 'FAE_Total_Amount', 'FAE_Quote_Number', 'FAE_Quote_Status', 'FAE_Quote_Request_Date', 'FAE_Formal_Approval_Sponsor', 'FAE_Formal_Approval_Median', 'FAE_Estimated_Date_Fix', 'FAE_Additional_Comments'            
        ]

        if len(new_columns) != df_version.shape[1]:
            medlog.logger.error('Mismatch between the number of columns and new column names.')
            return None, "Version sheet error", "Mismatch between the number of columns and new column names.",""

        df_version.columns = new_columns
        if not df_version.empty:
            today = datetime.today()
            first_day_of_current_month = datetime(today.year, today.month, 1)
            last_month = first_day_of_current_month - timedelta(days=30)
            first_day_of_last_month = datetime(last_month.year, last_month.month, 1)
            last_month_str = first_day_of_last_month.strftime("%d-%b-%y")
            if (df_version['Month_Validated'] == last_month_str).any():
                return df_version, "", "", ""
            return df_version, "", "", "not_validated"
        else:
            medlog.logger.error('Empty version history DataFrame')
            return None, "Version sheet's data extraction failed", "The version sheet is empty or incomplete, either way the data could not be read",""
    
    except FileNotFoundError:
        medlog.logger.error('The file was not found: %s', file_path)
        return None, "File not found", f"The file {file_path} was not found.", ""
    
    except pd.errors.EmptyDataError:
        medlog.logger.error('No data found in the sheet.')
        return None, "Empty sheet", "No data found in the sheet.", ""
    
    except pd.errors.ParserError:
        medlog.logger.error('Error parsing the sheet.')
        return None, "Parsing error", "Error parsing the sheet.",""

    except ValueError as ve:
        medlog.logger.error('Value error: %s', ve)
        return None, "Value error", str(ve),""
    
    except KeyError as ke:
        medlog.logger.error('Key error: %s', ke)
        return None, "Key error", str(ke),""

    except IndexError as ie:
        medlog.logger.error('Index error: %s', ie)
        return None, "Index error", str(ie),""

    except TypeError as te:
        medlog.logger.error('Type error: %s', te)
        return None, "Type error", str(te),""
    
    except Exception as e:
        medlog.logger.error('Failed to extract version history: %s', e)
        return None, "Unknown error", "Something went wrong while trying to read and extract version sheet's data.",""

def export_version_history_to_csv(version_history_df, original_file_path="Project_file_example"):
    """
    Export the version history DataFrame to a CSV file.

    Args:
        version_history_df (pd.DataFrame): DataFrame containing version history.
        original_file_path (str): Path to the original file for naming the output file.

    Returns:
        bool: True if the export was successful, False otherwise.
    """
    try:
        base_name = os.path.splitext(os.path.basename(original_file_path))[0]
        output_csv_path = f'{base_name}_version_history.csv'
        version_history_df.to_csv(output_csv_path, index=False, sep=";")
        medlog.logger.debug('Version history DataFrame has been successfully exported to %s', output_csv_path)

        if version_history_df.empty:
            raise ValueError("Version history DataFrame is empty")

    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError, OSError) as error_export:
        medlog.logger.error('Export of version history DataFrame has failed: %s', error_export)
        return False
    return True

def extract_cfu_data_for_bi(file_path, export_csv=True):
    """
    Main function to extract CFU data from different tabs and format for BI usage

    Args:
        file_path (str): Path to the file to be processed.
        export_csv (bool): Whether to export the results to CSV files. Default is True.

    Returns:
        tuple: Contains the final merged DataFrame and the outer merged DataFrame.
    """
    try:
        medlog.logger.info("1 - Read cfu file %s", file_path)
        df_dict_from_excel, error_init, error_init_desc = initialize_dataframes_from_excel(file_path)
        if df_dict_from_excel is None:
            return None, error_init, error_init_desc, "no"
        
        medlog.logger.info("2 - Process dataframe from this cfu")
        df_res_dict, error_msg, error_desc =  process_sheets(df_dict_from_excel, file_path)
        version_history_df, error_ver, error_ver_desc, month_validation = extract_version_history(file_path)
        if df_res_dict is None:
            if version_history_df is None:
                return None, error_msg, error_desc, "Version sheet not found"
            return None, error_msg, error_desc, ""
        medlog.logger.info("3 - Merge dataframes")
        final_merged_df, final_merged_df_outer = merge_dataframes(df_res_dict['df_new_qty_forecast'],
                                                                df_res_dict['df_new_qty_forecast_filtered'],
                                                                df_res_dict['df_new_revenue_forecast'])
        if final_merged_df is None or final_merged_df_outer is None:
            return None, "Internal error" , "Internal error during merge", ""

        project_code = os.path.splitext(os.path.basename(file_path))[0]
        medlog.logger.debug("%s - Project code extracted: %s", file_path, project_code)

        final_merged_df['Project_code'] = project_code
        final_merged_df_outer['Project_code'] = project_code

        if export_csv:
            export_to_csv(final_merged_df, final_merged_df_outer, file_path)
            if export_to_csv(final_merged_df, final_merged_df_outer, file_path) is True:
                medlog.logger.info(" --> %s - Dataframes were exported into CSV files", file_path)
                medlog.logger.info(" Check %s_final_merged_data_complete.csv file to get more accurate information", project_code)
            else:
                medlog.logger.error("Failed to export Dataframes into CSV files")
                return None, "Export error" , "An error occured during csv export", ""
        
        medlog.logger.info("4 - Extract data from version sheet")
        if version_history_df is None:
            return None, error_ver, error_ver_desc, "Version sheet not found"
        elif month_validation == "not_validated":
            medlog.logger.warning("The version sheet has not been validated for the last month")
            return (final_merged_df, final_merged_df_outer), "", "", "Last month not validated"

        if export_csv:
            export_version_history_to_csv(version_history_df, file_path)
            if export_version_history_to_csv(version_history_df, file_path) is True:
                medlog.logger.info(" --> Version history exported successfully into CSV file.")
            else:
                medlog.logger.error("Failed to export version history.")
                return None, "Export error" , "An error occured during csv export", ""

        medlog.logger.info("End - function extract_cfu_data_for_bi successfully completed")
        return (final_merged_df, final_merged_df_outer), "", "", ""

    except (pd.errors.EmptyDataError, pd.errors.ParserError, FileNotFoundError, ValueError, PermissionError,
            AttributeError, KeyError, IndexError, TypeError, OSError) as error_global:
        medlog.logger.error('extract_cfu_data_for_bi failed (%s)', error_global)
        return None, "Unknown error", "An unknown error occurred during the process", ""


if __name__ == '__main__':
    argument_prog_list = sys.argv[1:]
    initialize_logger_for_cfu_import(Path('./log/cfu_import_log'))

    if len(argument_prog_list) > 0:
        extract_cfu_data_for_bi(argument_prog_list)
    else:
        # argument = './tests/data/BO29554-ROCH_CostFollowUp.xlsx'
        argument = './tests/data/HS-10296-302-JHSO-Cost_Follow_Up.xlsx'
        if extract_cfu_data_for_bi(argument) is True:
            medlog.logger.info('iMetrics completed successfully')
        else:
            medlog.logger.info('iMetrics failed. More details should be available in log file')
